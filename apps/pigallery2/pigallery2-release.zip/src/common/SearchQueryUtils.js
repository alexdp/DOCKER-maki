"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchQueryUtils = void 0;
const SearchQueryDTO_1 = require("./entities/SearchQueryDTO");
const SearchQueryParser_1 = require("./SearchQueryParser");
const Utils_1 = require("./Utils");
exports.SearchQueryUtils = {
    negate: (query) => {
        query = Utils_1.Utils.clone(query);
        switch (query.type) {
            case SearchQueryDTO_1.SearchQueryTypes.AND:
                query.type = SearchQueryDTO_1.SearchQueryTypes.OR;
                query.list = query.list.map((q) => exports.SearchQueryUtils.negate(q));
                return query;
            case SearchQueryDTO_1.SearchQueryTypes.OR:
                query.type = SearchQueryDTO_1.SearchQueryTypes.AND;
                query.list = query.list.map((q) => exports.SearchQueryUtils.negate(q));
                return query;
            case SearchQueryDTO_1.SearchQueryTypes.orientation:
                query.landscape = !query.landscape;
                return query;
            case SearchQueryDTO_1.SearchQueryTypes.from_date:
            case SearchQueryDTO_1.SearchQueryTypes.to_date:
            case SearchQueryDTO_1.SearchQueryTypes.min_rating:
            case SearchQueryDTO_1.SearchQueryTypes.max_rating:
            case SearchQueryDTO_1.SearchQueryTypes.min_resolution:
            case SearchQueryDTO_1.SearchQueryTypes.max_resolution:
            case SearchQueryDTO_1.SearchQueryTypes.distance:
            case SearchQueryDTO_1.SearchQueryTypes.any_text:
            case SearchQueryDTO_1.SearchQueryTypes.person:
            case SearchQueryDTO_1.SearchQueryTypes.position:
            case SearchQueryDTO_1.SearchQueryTypes.keyword:
            case SearchQueryDTO_1.SearchQueryTypes.caption:
            case SearchQueryDTO_1.SearchQueryTypes.file_name:
            case SearchQueryDTO_1.SearchQueryTypes.directory:
                query.negate = !query.negate;
                return query;
            case SearchQueryDTO_1.SearchQueryTypes.SOME_OF:
                throw new Error('Some of not supported');
            default:
                throw new Error('Unknown type' + (query).type);
        }
    },
    sortQuery(queryIN) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const canonicalize = (value) => {
            if (Array.isArray(value)) {
                return value.map((v) => canonicalize(v));
            }
            if (value && typeof value === 'object') {
                const out = {};
                const keys = Object.keys(value).sort();
                for (const k of keys) {
                    const v = canonicalize(value[k]);
                    if (v !== undefined) {
                        out[k] = v;
                    }
                }
                return out;
            }
            return value;
        };
        if (!queryIN || (queryIN).type === undefined) {
            return queryIN;
        }
        if (queryIN.type === SearchQueryDTO_1.SearchQueryTypes.AND ||
            queryIN.type === SearchQueryDTO_1.SearchQueryTypes.OR ||
            queryIN.type === SearchQueryDTO_1.SearchQueryTypes.SOME_OF) {
            const ql = queryIN;
            const children = (ql.list || []).map((c) => exports.SearchQueryUtils.sortQuery(c));
            const withKeys = children.map((c) => ({ key: JSON.stringify(c), value: c }));
            withKeys.sort((a, b) => a.key.localeCompare(b.key));
            if (queryIN.type === SearchQueryDTO_1.SearchQueryTypes.SOME_OF) {
                const so = queryIN;
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                const res = { type: queryIN.type };
                if (so.min !== undefined) {
                    res.min = so.min;
                }
                res.list = withKeys.map((kv) => kv.value);
                return canonicalize(res);
            }
            else {
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                const res = { type: queryIN.type };
                res.list = withKeys.map((kv) => kv.value);
                return canonicalize(res);
            }
        }
        return canonicalize(queryIN);
    },
    stringifyForComparison(queryIN) {
        return JSON.stringify(exports.SearchQueryUtils.sortQuery(queryIN));
    },
    isQueryEmpty(query) {
        return !query ||
            query.type === undefined ||
            (query.type === SearchQueryDTO_1.SearchQueryTypes.any_text && !query.text);
    },
    // Recursively strip negate:false so that optional false flags do not break validation
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    stripFalseNegate: (val) => {
        if (Array.isArray(val)) {
            return val.map((v) => exports.SearchQueryUtils.stripFalseNegate(v));
        }
        if (val && typeof val === 'object') {
            const out = {};
            for (const k of Object.keys(val)) {
                const v = exports.SearchQueryUtils.stripFalseNegate(val[k]);
                if (k === 'negate' && v === false) {
                    // drop negate:false
                    continue;
                }
                // keep everything else, including negate:true and undefined-handled by equalsFilter
                out[k] = v;
            }
            return out;
        }
        return val;
    },
    validateSearchQuery(query, what = 'SearchQuery') {
        if (!query) {
            return;
        }
        const sp = new SearchQueryParser_1.SearchQueryParser();
        try {
            const parsed = sp.parse(sp.stringify(query));
            const normParsed = exports.SearchQueryUtils.stripFalseNegate(parsed);
            const normQuery = exports.SearchQueryUtils.stripFalseNegate(query);
            if (!Utils_1.Utils.equalsFilter(normParsed, normQuery)) {
                throw new Error(`${what} is not valid. Expected: ${JSON.stringify(parsed)} to equal: ${JSON.stringify(query)}`);
            }
        }
        catch (e) {
            if (e && e.message && e.message.startsWith(what)) {
                throw e;
            }
            throw new Error(`${what} is not valid. ${e?.message ?? e}`);
        }
    }
};

//# sourceMappingURL=SearchQueryUtils.js.map
