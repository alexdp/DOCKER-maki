"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Config = void 0;
const ExtensionConfigWrapper_1 = require("../../../backend/model/extension/ExtensionConfigWrapper");
const PrivateConfigClass_1 = require("./PrivateConfigClass");
const node_1 = require("typeconfig/node");
const ProjectPath_1 = require("../../../backend/ProjectPath");
// we need to know the location of the extensions to load the full config (including the extensions)
const pre = node_1.ConfigClassBuilder.attachPrivateInterface(new PrivateConfigClass_1.PrivateConfigClass());
try {
    pre.loadSync({ preventSaving: true });
}
catch (e) { /* empty */
}
// load extension paths before full config load
ProjectPath_1.ProjectPath.init(pre);
exports.Config = ExtensionConfigWrapper_1.ExtensionConfigWrapper.originalSync(true);
// set actual config
ProjectPath_1.ProjectPath.init(exports.Config);

//# sourceMappingURL=Config.js.map
