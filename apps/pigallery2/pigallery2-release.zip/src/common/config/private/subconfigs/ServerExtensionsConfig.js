"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServerExtensionsConfig = exports.ServerExtensionsEntryConfig = void 0;
const tslib_1 = require("tslib");
/* eslint-disable @typescript-eslint/no-inferrable-types */
const common_1 = require("typeconfig/common");
const ClientConfig_1 = require("../../public/ClientConfig");
const GenericConfigType_1 = require("typeconfig/src/GenericConfigType");
if (typeof $localize === 'undefined') {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    global.$localize = (s) => s;
}
let ServerExtensionsEntryConfig = class ServerExtensionsEntryConfig {
    constructor(path = '') {
        this.enabled = true;
        this.path = '';
        this.path = path;
    }
};
exports.ServerExtensionsEntryConfig = ServerExtensionsEntryConfig;
tslib_1.__decorate([
    (0, common_1.ConfigProperty)({
        tags: {
            name: $localize `Enabled`,
            priority: ClientConfig_1.ConfigPriority.advanced,
        },
    }),
    tslib_1.__metadata("design:type", Boolean)
], ServerExtensionsEntryConfig.prototype, "enabled", void 0);
tslib_1.__decorate([
    (0, common_1.ConfigProperty)({
        readonly: true,
        tags: {
            name: $localize `Extension folder`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
        },
        description: $localize `Sub-folder of the given extension.`,
    }),
    tslib_1.__metadata("design:type", String)
], ServerExtensionsEntryConfig.prototype, "path", void 0);
tslib_1.__decorate([
    (0, common_1.ConfigProperty)({
        type: GenericConfigType_1.GenericConfigType,
        tags: {
            name: $localize `Config`,
            priority: ClientConfig_1.ConfigPriority.advanced
        }
    }),
    tslib_1.__metadata("design:type", GenericConfigType_1.GenericConfigType)
], ServerExtensionsEntryConfig.prototype, "configs", void 0);
exports.ServerExtensionsEntryConfig = ServerExtensionsEntryConfig = tslib_1.__decorate([
    (0, common_1.SubConfigClass)({ softReadonly: true }),
    tslib_1.__metadata("design:paramtypes", [String])
], ServerExtensionsEntryConfig);
let ServerExtensionsConfig = class ServerExtensionsConfig extends ClientConfig_1.ClientExtensionsConfig {
    constructor() {
        super(...arguments);
        this.repositoryUrl = 'https://raw.githubusercontent.com/bpatrik/pigallery2/master/extension/REPOSITORY.md';
        this.folder = 'extensions';
        this.extensions = new common_1.ConfigMap();
        this.cleanUpUnusedTables = true;
    }
};
exports.ServerExtensionsConfig = ServerExtensionsConfig;
tslib_1.__decorate([
    (0, common_1.ConfigProperty)({
        tags: {
            name: $localize `Repository url`,
            priority: ClientConfig_1.ConfigPriority.underTheHood
        },
        description: $localize `Repository url that points to a list of extensions in .md format.`,
    }),
    tslib_1.__metadata("design:type", String)
], ServerExtensionsConfig.prototype, "repositoryUrl", void 0);
tslib_1.__decorate([
    (0, common_1.ConfigProperty)({
        tags: {
            name: $localize `Extension folder`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            dockerSensitive: true,
            uiResetNeeded: { server: true },
        },
        description: $localize `Folder where the app stores all extensions. Individual extensions live in their own sub-folders.`,
    }),
    tslib_1.__metadata("design:type", String)
], ServerExtensionsConfig.prototype, "folder", void 0);
tslib_1.__decorate([
    (0, common_1.ConfigProperty)({
        type: common_1.ConfigMap,
        tags: {
            name: $localize `Installed extensions`,
            uiIcon: 'ionList',
            priority: ClientConfig_1.ConfigPriority.advanced
        }
    }),
    tslib_1.__metadata("design:type", Object)
], ServerExtensionsConfig.prototype, "extensions", void 0);
tslib_1.__decorate([
    (0, common_1.ConfigProperty)({
        tags: {
            name: $localize `Clean up unused tables`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
        },
        description: $localize `Automatically removes all tables from the DB that are not used anymore.`,
    }),
    tslib_1.__metadata("design:type", Boolean)
], ServerExtensionsConfig.prototype, "cleanUpUnusedTables", void 0);
exports.ServerExtensionsConfig = ServerExtensionsConfig = tslib_1.__decorate([
    (0, common_1.SubConfigClass)({ softReadonly: true })
], ServerExtensionsConfig);

//# sourceMappingURL=ServerExtensionsConfig.js.map
