"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchQueryParser = exports.defaultQueryKeywords = void 0;
const SearchQueryDTO_1 = require("./entities/SearchQueryDTO");
const Utils_1 = require("./Utils");
exports.defaultQueryKeywords = {
    NSomeOf: 'of',
    and: 'and',
    or: 'or',
    from: 'after',
    to: 'before',
    maxRating: 'max-rating',
    minRating: 'min-rating',
    maxPersonCount: 'max-persons',
    minPersonCount: 'min-persons',
    maxResolution: 'max-resolution',
    minResolution: 'min-resolution',
    kmFrom: 'km-from',
    orientation: 'orientation',
    landscape: 'landscape',
    portrait: 'portrait',
    years_ago: '%d-years-ago',
    months_ago: '%d-months-ago',
    weeks_ago: '%d-weeks-ago',
    days_ago: '%d-days-ago',
    every_year: 'every-year',
    every_month: 'every-month',
    every_week: 'every-week',
    lastNDays: 'last-%d-days',
    sameDay: 'same-day',
    any_text: 'any-text',
    keyword: 'keyword',
    caption: 'caption',
    directory: 'directory',
    file_name: 'file-name',
    person: 'person',
    position: 'position',
    someOf: 'some-of',
};
class SearchQueryParser {
    constructor(keywords = exports.defaultQueryKeywords) {
        this.keywords = keywords;
    }
    static stringifyText(text, matchType = SearchQueryDTO_1.TextSearchQueryMatchTypes.like) {
        if (matchType === SearchQueryDTO_1.TextSearchQueryMatchTypes.exact_match) {
            return '"' + text + '"';
        }
        if (text.indexOf(' ') !== -1) {
            return '(' + text + ')';
        }
        return text;
    }
    static stringifyDate(time) {
        const date = new Date(time);
        // simplify date with yeah only if its first of jan
        if (date.getMonth() === 0 && date.getDate() === 1) {
            return date.getFullYear().toString();
        }
        return this.stringifyText(date.toISOString().substring(0, 10));
    }
    static parseDate(text) {
        if (text.charAt(0) === '"' || text.charAt(0) === '(') {
            text = text.substring(1);
        }
        if (text.charAt(text.length - 1) === '"' ||
            text.charAt(text.length - 1) === ')') {
            text = text.substring(0, text.length - 1);
        }
        // it is the year only
        if (text.length === 4) {
            return Date.UTC(parseInt(text, 10), 0, 1, 0, 0, 0, 0);
        }
        let timestamp = null;
        // Parsing ISO string
        try {
            const parts = text.split('-').map((t) => parseInt(t, 10));
            if (parts && parts.length === 2) {
                timestamp = Date.UTC(parts[0], parts[1] - 1, 1, 0, 0, 0, 0); // Note: months are 0-based
            }
            if (parts && parts.length === 3) {
                timestamp = Date.UTC(parts[0], parts[1] - 1, parts[2], 0, 0, 0, 0); // Note: months are 0-based
            }
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
        }
        catch (e) {
            // ignoring errors
        }
        // If it could not parse as ISO string, try our luck with Date.parse
        // https://stackoverflow.com/questions/2587345/why-does-date-parse-give-incorrect-results
        if (timestamp === null) {
            timestamp = Date.parse(text);
        }
        if (isNaN(timestamp) || timestamp === null) {
            throw new Error('Cannot parse date: ' + text);
        }
        return timestamp;
    }
    static humanToRegexpStr(str) {
        return str.replace(/%d/g, '\\d*');
    }
    parse(str, implicitAND = true) {
        str = str
            .replace(/\s\s+/g, ' ') // remove double spaces
            .replace(/:\s+/g, ':')
            .trim();
        const intFromRegexp = (str) => {
            const numSTR = new RegExp(/\d+/).exec(str);
            if (!numSTR) {
                return 0;
            }
            return parseInt(numSTR[0], 10);
        };
        if (str.charAt(0) === '(' && str.charAt(str.length - 1) === ')') {
            str = str.slice(1, str.length - 1);
        }
        const fistSpace = (start = 0) => {
            const bracketIn = [];
            let quotationMark = false;
            for (let i = start; i < str.length; ++i) {
                if (str.charAt(i) === '"') {
                    quotationMark = !quotationMark;
                    continue;
                }
                if (str.charAt(i) === '(') {
                    bracketIn.push(i);
                    continue;
                }
                if (str.charAt(i) === ')') {
                    bracketIn.pop();
                    continue;
                }
                if (quotationMark === false &&
                    bracketIn.length === 0 &&
                    str.charAt(i) === ' ') {
                    return i;
                }
            }
            return str.length - 1;
        };
        // tokenize
        const tokenEnd = fistSpace();
        if (tokenEnd !== str.length - 1) {
            if (str.startsWith(' ' + this.keywords.and, tokenEnd)) {
                const rest = this.parse(str.slice(tokenEnd + (' ' + this.keywords.and).length), implicitAND);
                return {
                    type: SearchQueryDTO_1.SearchQueryTypes.AND,
                    list: [
                        this.parse(str.slice(0, tokenEnd), implicitAND), // trim brackets
                        ...(rest.type === SearchQueryDTO_1.SearchQueryTypes.AND
                            ? rest.list
                            : [rest]),
                    ],
                };
            }
            else if (str.startsWith(' ' + this.keywords.or, tokenEnd)) {
                const rest = this.parse(str.slice(tokenEnd + (' ' + this.keywords.or).length), implicitAND);
                return {
                    type: SearchQueryDTO_1.SearchQueryTypes.OR,
                    list: [
                        this.parse(str.slice(0, tokenEnd), implicitAND), // trim brackets
                        ...(rest.type === SearchQueryDTO_1.SearchQueryTypes.OR
                            ? rest.list
                            : [rest]),
                    ],
                };
            }
            else {
                // Relation cannot be detected
                const t = implicitAND === true
                    ? SearchQueryDTO_1.SearchQueryTypes.AND
                    : SearchQueryDTO_1.SearchQueryTypes.UNKNOWN_RELATION;
                const rest = this.parse(str.slice(tokenEnd), implicitAND);
                return {
                    type: t,
                    list: [
                        this.parse(str.slice(0, tokenEnd), implicitAND), // trim brackets
                        ...(rest.type === t ? rest.list : [rest]),
                    ],
                };
            }
        }
        if (str.startsWith(this.keywords.someOf + ':') ||
            new RegExp('^\\d*-' + this.keywords.NSomeOf + ':').test(str)) {
            const prefix = str.startsWith(this.keywords.someOf + ':')
                ? this.keywords.someOf + ':'
                : new RegExp('^\\d*-' + this.keywords.NSomeOf + ':').exec(str)[0];
            let tmpList = this.parse(str.slice(prefix.length + 1, -1), false); // trim brackets
            const unfoldList = (q) => {
                if (q.list) {
                    if (q.type === SearchQueryDTO_1.SearchQueryTypes.UNKNOWN_RELATION) {
                        return q.list.map((e) => unfoldList(e)).flat(); // flatten array
                    }
                    else {
                        q.list.forEach((e) => unfoldList(e));
                    }
                }
                return [q];
            };
            tmpList = unfoldList(tmpList);
            const ret = {
                type: SearchQueryDTO_1.SearchQueryTypes.SOME_OF,
                list: tmpList,
            };
            if (new RegExp('^\\d*-' + this.keywords.NSomeOf + ':').test(str)) {
                ret.min = parseInt(new RegExp(/^\d*/).exec(str)[0], 10);
            }
            return ret;
        }
        const kwStartsWith = (s, kw) => {
            return s.startsWith(kw + ':') || s.startsWith(kw + '!:');
        };
        if (kwStartsWith(str, this.keywords.from)) {
            return {
                type: SearchQueryDTO_1.SearchQueryTypes.from_date,
                value: SearchQueryParser.parseDate(str.substring(str.indexOf(':') + 1)),
                ...(str.startsWith(this.keywords.from + '!:') && { negate: true }), // only add if the value is true
            };
        }
        if (kwStartsWith(str, this.keywords.to)) {
            return {
                type: SearchQueryDTO_1.SearchQueryTypes.to_date,
                value: SearchQueryParser.parseDate(str.substring(str.indexOf(':') + 1)),
                ...(str.startsWith(this.keywords.to + '!:') && { negate: true }), // only add if the value is true
            };
        }
        const addValueRangeParser = (matcher, type) => {
            if (kwStartsWith(str, matcher)) {
                return {
                    type: type,
                    value: parseInt(str.substring(str.indexOf(':') + 1), 10),
                    ...(str.startsWith(matcher + '!:') && { negate: true }), // only add if the value is true
                };
            }
        };
        const range = addValueRangeParser(this.keywords.minRating, SearchQueryDTO_1.SearchQueryTypes.min_rating) ||
            addValueRangeParser(this.keywords.maxRating, SearchQueryDTO_1.SearchQueryTypes.max_rating) ||
            addValueRangeParser(this.keywords.minResolution, SearchQueryDTO_1.SearchQueryTypes.min_resolution) ||
            addValueRangeParser(this.keywords.maxResolution, SearchQueryDTO_1.SearchQueryTypes.max_resolution) ||
            addValueRangeParser(this.keywords.minPersonCount, SearchQueryDTO_1.SearchQueryTypes.min_person_count) ||
            addValueRangeParser(this.keywords.maxPersonCount, SearchQueryDTO_1.SearchQueryTypes.max_person_count);
        if (range) {
            return range;
        }
        if (new RegExp('^\\d*-' + this.keywords.kmFrom + '!?:').test(str)) {
            let from = str.slice(new RegExp('^\\d*-' + this.keywords.kmFrom + '!?:').exec(str)[0].length);
            if ((from.charAt(0) === '(' && from.charAt(from.length - 1) === ')') ||
                (from.charAt(0) === '"' && from.charAt(from.length - 1) === '"')) {
                from = from.slice(1, from.length - 1);
            }
            // Check if the from part matches coordinate pattern (number, number)
            const coordMatch = from.match(/^\s*(-?\d+\.?\d*)\s*,\s*(-?\d+\.?\d*)\s*$/);
            if (coordMatch) {
                // It's a coordinate pair
                const latitude = parseFloat(coordMatch[1]);
                const longitude = parseFloat(coordMatch[2]);
                return {
                    type: SearchQueryDTO_1.SearchQueryTypes.distance,
                    distance: intFromRegexp(str),
                    from: {
                        GPSData: {
                            latitude,
                            longitude
                        }
                    },
                    // only add negate if the value is true
                    ...(new RegExp('^\\d*-' + this.keywords.kmFrom + '!:').test(str) && {
                        negate: true,
                    }),
                };
            }
            // If not coordinates, treat as location text
            return {
                type: SearchQueryDTO_1.SearchQueryTypes.distance,
                distance: intFromRegexp(str),
                from: { text: from },
                // only add negate if the value is true
                ...(new RegExp('^\\d*-' + this.keywords.kmFrom + '!:').test(str) && {
                    negate: true,
                }),
            };
        }
        if (str.startsWith(this.keywords.orientation + ':')) {
            return {
                type: SearchQueryDTO_1.SearchQueryTypes.orientation,
                landscape: str.slice((this.keywords.orientation + ':').length) ===
                    this.keywords.landscape,
            };
        }
        if (kwStartsWith(str, this.keywords.sameDay) ||
            new RegExp('^' + SearchQueryParser.humanToRegexpStr(this.keywords.lastNDays) + '!?:').test(str)) {
            const freqStr = str.indexOf('!:') === -1 ? str.slice(str.indexOf(':') + 1) : str.slice(str.indexOf('!:') + 2);
            let freq = null;
            let ago;
            if (freqStr == this.keywords.every_week) {
                freq = SearchQueryDTO_1.DatePatternFrequency.every_week;
            }
            else if (freqStr == this.keywords.every_month) {
                freq = SearchQueryDTO_1.DatePatternFrequency.every_month;
            }
            else if (freqStr == this.keywords.every_year) {
                freq = SearchQueryDTO_1.DatePatternFrequency.every_year;
            }
            else if (new RegExp('^' + SearchQueryParser.humanToRegexpStr(this.keywords.days_ago) + '$').test(freqStr)) {
                freq = SearchQueryDTO_1.DatePatternFrequency.days_ago;
                ago = intFromRegexp(freqStr);
            }
            else if (new RegExp('^' + SearchQueryParser.humanToRegexpStr(this.keywords.weeks_ago) + '$').test(freqStr)) {
                freq = SearchQueryDTO_1.DatePatternFrequency.weeks_ago;
                ago = intFromRegexp(freqStr);
            }
            else if (new RegExp('^' + SearchQueryParser.humanToRegexpStr(this.keywords.months_ago) + '$').test(freqStr)) {
                freq = SearchQueryDTO_1.DatePatternFrequency.months_ago;
                ago = intFromRegexp(freqStr);
            }
            else if (new RegExp('^' + SearchQueryParser.humanToRegexpStr(this.keywords.years_ago) + '$').test(freqStr)) {
                freq = SearchQueryDTO_1.DatePatternFrequency.years_ago;
                ago = intFromRegexp(freqStr);
            }
            if (freq) {
                return {
                    type: SearchQueryDTO_1.SearchQueryTypes.date_pattern,
                    daysLength: kwStartsWith(str, this.keywords.sameDay) ? 0 : intFromRegexp(str),
                    frequency: freq,
                    ...((new RegExp('^' + SearchQueryParser.humanToRegexpStr(this.keywords.lastNDays) + '!:').test(str) ||
                        str.startsWith(this.keywords.sameDay + '!:')) && {
                        negate: true
                    }),
                    ...(!isNaN(ago) && { agoNumber: ago })
                };
            }
        }
        // parse text search
        const tmp = SearchQueryDTO_1.TextSearchQueryTypes.map((type) => ({
            key: this.keywords[SearchQueryDTO_1.SearchQueryTypes[type]] + ':',
            queryTemplate: { type, text: '' },
        })).concat(SearchQueryDTO_1.TextSearchQueryTypes.map((type) => ({
            key: this.keywords[SearchQueryDTO_1.SearchQueryTypes[type]] + '!:',
            queryTemplate: { type, text: '', negate: true },
        })));
        for (const typeTmp of tmp) {
            if (str.startsWith(typeTmp.key)) {
                const ret = Utils_1.Utils.clone(typeTmp.queryTemplate);
                // exact match
                if (str.charAt(typeTmp.key.length) === '"' &&
                    str.charAt(str.length - 1) === '"') {
                    ret.text = str.slice(typeTmp.key.length + 1, str.length - 1);
                    ret.matchType = SearchQueryDTO_1.TextSearchQueryMatchTypes.exact_match;
                    // like match
                }
                else if (str.charAt(typeTmp.key.length) === '(' &&
                    str.charAt(str.length - 1) === ')') {
                    ret.text = str.slice(typeTmp.key.length + 1, str.length - 1);
                }
                else {
                    ret.text = str.slice(typeTmp.key.length);
                }
                return ret;
            }
        }
        return { type: SearchQueryDTO_1.SearchQueryTypes.any_text, text: str };
    }
    stringify(query) {
        const ret = this.stringifyOnEntry(query);
        if (ret.charAt(0) === '(' && ret.charAt(ret.length - 1) === ')') {
            return ret.slice(1, ret.length - 1);
        }
        return ret;
    }
    stringifyOnEntry(query) {
        if (!query || !query.type) {
            return '';
        }
        const colon = query.negate === true ? '!:' : ':';
        switch (query.type) {
            case SearchQueryDTO_1.SearchQueryTypes.AND:
                return ('(' +
                    query.list
                        .map((q) => this.stringifyOnEntry(q))
                        .join(' ' + this.keywords.and + ' ') +
                    ')');
            case SearchQueryDTO_1.SearchQueryTypes.OR:
                return ('(' +
                    query.list
                        .map((q) => this.stringifyOnEntry(q))
                        .join(' ' + this.keywords.or + ' ') +
                    ')');
            case SearchQueryDTO_1.SearchQueryTypes.SOME_OF:
                if (query.min) {
                    return (query.min +
                        '-' +
                        this.keywords.NSomeOf +
                        ':(' +
                        query.list
                            .map((q) => this.stringifyOnEntry(q))
                            .join(' ') +
                        ')');
                }
                return (this.keywords.someOf +
                    ':(' +
                    query.list
                        .map((q) => this.stringifyOnEntry(q))
                        .join(' ') +
                    ')');
            case SearchQueryDTO_1.SearchQueryTypes.from_date:
                if (!query.value) {
                    return '';
                }
                return (this.keywords.from +
                    colon +
                    SearchQueryParser.stringifyDate(query.value));
            case SearchQueryDTO_1.SearchQueryTypes.to_date:
                if (!query.value) {
                    return '';
                }
                return (this.keywords.to +
                    colon +
                    SearchQueryParser.stringifyDate(query.value));
            case SearchQueryDTO_1.SearchQueryTypes.min_rating:
                return (this.keywords.minRating +
                    colon +
                    (isNaN(query.value)
                        ? ''
                        : query.value));
            case SearchQueryDTO_1.SearchQueryTypes.max_rating:
                return (this.keywords.maxRating +
                    colon +
                    (isNaN(query.value)
                        ? ''
                        : query.value));
            case SearchQueryDTO_1.SearchQueryTypes.min_person_count:
                return (this.keywords.minPersonCount +
                    colon +
                    (isNaN(query.value)
                        ? ''
                        : query.value));
            case SearchQueryDTO_1.SearchQueryTypes.max_person_count:
                return (this.keywords.maxPersonCount +
                    colon +
                    (isNaN(query.value)
                        ? ''
                        : query.value));
            case SearchQueryDTO_1.SearchQueryTypes.min_resolution:
                return (this.keywords.minResolution +
                    colon +
                    (isNaN(query.value)
                        ? ''
                        : query.value));
            case SearchQueryDTO_1.SearchQueryTypes.max_resolution:
                return (this.keywords.maxResolution +
                    colon +
                    (isNaN(query.value)
                        ? ''
                        : query.value));
            case SearchQueryDTO_1.SearchQueryTypes.distance: {
                const distanceQuery = query;
                const text = distanceQuery.from.text;
                const coords = distanceQuery.from.GPSData;
                let locationStr = '';
                if (text) {
                    // If we have location text, use that
                    locationStr = text;
                }
                else if (coords && coords.latitude != null && coords.longitude != null) {
                    // If we only have coordinates, use them
                    locationStr = `${coords.latitude.toFixed(6)}, ${coords.longitude.toFixed(6)}`;
                }
                // Add brackets if the location string contains spaces
                if (locationStr.indexOf(' ') !== -1) {
                    locationStr = `(${locationStr})`;
                }
                return `${distanceQuery.distance}-${this.keywords.kmFrom}${colon}${locationStr}`;
            }
            case SearchQueryDTO_1.SearchQueryTypes.orientation:
                return (this.keywords.orientation +
                    ':' +
                    (query.landscape
                        ? this.keywords.landscape
                        : this.keywords.portrait));
            case SearchQueryDTO_1.SearchQueryTypes.date_pattern: {
                const q = query;
                q.daysLength = q.daysLength || 0;
                let strBuilder = '';
                if (q.daysLength <= 0) {
                    strBuilder += this.keywords.sameDay;
                }
                else {
                    strBuilder += this.keywords.lastNDays.replace(/%d/g, q.daysLength.toString());
                }
                if (q.negate === true) {
                    strBuilder += '!';
                }
                strBuilder += ':';
                switch (q.frequency) {
                    case SearchQueryDTO_1.DatePatternFrequency.every_week:
                        strBuilder += this.keywords.every_week;
                        break;
                    case SearchQueryDTO_1.DatePatternFrequency.every_month:
                        strBuilder += this.keywords.every_month;
                        break;
                    case SearchQueryDTO_1.DatePatternFrequency.every_year:
                        strBuilder += this.keywords.every_year;
                        break;
                    case SearchQueryDTO_1.DatePatternFrequency.days_ago:
                        strBuilder += this.keywords.days_ago.replace(/%d/g, (q.agoNumber || 0).toString());
                        break;
                    case SearchQueryDTO_1.DatePatternFrequency.weeks_ago:
                        strBuilder += this.keywords.weeks_ago.replace(/%d/g, (q.agoNumber || 0).toString());
                        break;
                    case SearchQueryDTO_1.DatePatternFrequency.months_ago:
                        strBuilder += this.keywords.months_ago.replace(/%d/g, (q.agoNumber || 0).toString());
                        break;
                    case SearchQueryDTO_1.DatePatternFrequency.years_ago:
                        strBuilder += this.keywords.years_ago.replace(/%d/g, (q.agoNumber || 0).toString());
                        break;
                }
                return strBuilder;
            }
            case SearchQueryDTO_1.SearchQueryTypes.any_text:
                if (!query.negate) {
                    return SearchQueryParser.stringifyText(query.text, query.matchType);
                }
                else {
                    return (this.keywords[SearchQueryDTO_1.SearchQueryTypes[query.type]] +
                        colon +
                        SearchQueryParser.stringifyText(query.text, query.matchType));
                }
            case SearchQueryDTO_1.SearchQueryTypes.person:
            case SearchQueryDTO_1.SearchQueryTypes.position:
            case SearchQueryDTO_1.SearchQueryTypes.keyword:
            case SearchQueryDTO_1.SearchQueryTypes.caption:
            case SearchQueryDTO_1.SearchQueryTypes.file_name:
            case SearchQueryDTO_1.SearchQueryTypes.directory:
                if (!query.text) {
                    return '';
                }
                return (this.keywords[SearchQueryDTO_1.SearchQueryTypes[query.type]] +
                    colon +
                    SearchQueryParser.stringifyText(query.text, query.matchType));
            default:
                throw new Error('Unknown type: ' + query.type);
        }
    }
}
exports.SearchQueryParser = SearchQueryParser;

//# sourceMappingURL=SearchQueryParser.js.map
