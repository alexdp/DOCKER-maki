"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JobScheduleDTOUtils = exports.JobTriggerType = void 0;
var JobTriggerType;
(function (JobTriggerType) {
    JobTriggerType[JobTriggerType["never"] = 1] = "never";
    JobTriggerType[JobTriggerType["scheduled"] = 2] = "scheduled";
    JobTriggerType[JobTriggerType["periodic"] = 3] = "periodic";
    JobTriggerType[JobTriggerType["after"] = 4] = "after";
})(JobTriggerType || (exports.JobTriggerType = JobTriggerType = {}));
exports.JobScheduleDTOUtils = {
    getNextDayOfTheWeek: (refDate, dayOfWeek) => {
        const date = new Date(refDate);
        date.setDate(refDate.getDate() + ((dayOfWeek + 1 + 7 - refDate.getDay()) % 7));
        if (date.getDay() === refDate.getDay()) {
            return new Date(refDate);
        }
        date.setUTCHours(0, 0, 0, 0);
        return date;
    },
    nextValidDate: (date, h, m, dayDiff) => {
        date.setUTCSeconds(0);
        date.setUTCMilliseconds(0);
        if (date.getUTCHours() < h ||
            (date.getUTCHours() === h && date.getUTCMinutes() < m)) {
            date.setUTCHours(h);
            date.setUTCMinutes(m);
        }
        else {
            date.setTime(date.getTime() + dayDiff);
            date.setUTCHours(h);
            date.setUTCMinutes(m);
        }
        return date;
    },
    getNextRunningDate: (refDate, schedule) => {
        switch (schedule.trigger.type) {
            case JobTriggerType.scheduled:
                return new Date(schedule.trigger.time);
            case JobTriggerType.periodic:
                const hour = Math.min(23, Math.floor(schedule.trigger.atTime / 60));
                const minute = schedule.trigger.atTime % 60;
                if (schedule.trigger.periodicity <= 6) {
                    // Between Monday and Sunday
                    const nextRunDate = exports.JobScheduleDTOUtils.getNextDayOfTheWeek(refDate, schedule.trigger.periodicity);
                    return exports.JobScheduleDTOUtils.nextValidDate(nextRunDate, hour, minute, 7 * 24 * 60 * 60 * 1000);
                }
                // every day
                return exports.JobScheduleDTOUtils.nextValidDate(new Date(refDate), hour, minute, 24 * 60 * 60 * 1000);
        }
        return null;
    },
};

//# sourceMappingURL=JobScheduleDTO.js.map
