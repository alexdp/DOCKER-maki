"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRoles = void 0;
var UserRoles;
(function (UserRoles) {
    UserRoles[UserRoles["LimitedGuest"] = 1] = "LimitedGuest";
    UserRoles[UserRoles["Guest"] = 2] = "Guest";
    UserRoles[UserRoles["User"] = 3] = "User";
    UserRoles[UserRoles["Admin"] = 4] = "Admin";
    UserRoles[UserRoles["Developer"] = 5] = "Developer";
})(UserRoles || (exports.UserRoles = UserRoles = {}));

//# sourceMappingURL=UserDTO.js.map
