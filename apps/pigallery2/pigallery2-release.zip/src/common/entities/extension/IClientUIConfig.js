"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

//# sourceMappingURL=IClientUIConfig.js.map
