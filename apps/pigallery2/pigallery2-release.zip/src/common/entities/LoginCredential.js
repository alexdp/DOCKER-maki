"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginCredential = void 0;
class LoginCredential {
    constructor(username = '', password = '', rememberMe = true) {
        this.username = username;
        this.password = password;
        this.rememberMe = rememberMe;
    }
}
exports.LoginCredential = LoginCredential;

//# sourceMappingURL=LoginCredential.js.map
