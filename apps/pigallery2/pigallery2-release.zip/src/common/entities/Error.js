"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorDTO = exports.ErrorCodes = void 0;
var ErrorCodes;
(function (ErrorCodes) {
    ErrorCodes[ErrorCodes["NOT_AUTHENTICATED"] = 1] = "NOT_AUTHENTICATED";
    ErrorCodes[ErrorCodes["ALREADY_AUTHENTICATED"] = 2] = "ALREADY_AUTHENTICATED";
    ErrorCodes[ErrorCodes["NOT_AUTHORISED"] = 3] = "NOT_AUTHORISED";
    ErrorCodes[ErrorCodes["PERMISSION_DENIED"] = 4] = "PERMISSION_DENIED";
    ErrorCodes[ErrorCodes["CREDENTIAL_NOT_FOUND"] = 5] = "CREDENTIAL_NOT_FOUND";
    ErrorCodes[ErrorCodes["USER_CREATION_ERROR"] = 20] = "USER_CREATION_ERROR";
    ErrorCodes[ErrorCodes["GENERAL_ERROR"] = 31] = "GENERAL_ERROR";
    ErrorCodes[ErrorCodes["THUMBNAIL_GENERATION_ERROR"] = 32] = "THUMBNAIL_GENERATION_ERROR";
    ErrorCodes[ErrorCodes["PHOTO_GENERATION_ERROR"] = 33] = "PHOTO_GENERATION_ERROR";
    ErrorCodes[ErrorCodes["PERSON_ERROR"] = 34] = "PERSON_ERROR";
    ErrorCodes[ErrorCodes["METAFILE_ERROR"] = 35] = "METAFILE_ERROR";
    ErrorCodes[ErrorCodes["SERVER_ERROR"] = 36] = "SERVER_ERROR";
    ErrorCodes[ErrorCodes["USER_MANAGEMENT_DISABLED"] = 40] = "USER_MANAGEMENT_DISABLED";
    ErrorCodes[ErrorCodes["INPUT_ERROR"] = 50] = "INPUT_ERROR";
    ErrorCodes[ErrorCodes["PATH_ERROR"] = 51] = "PATH_ERROR";
    ErrorCodes[ErrorCodes["SETTINGS_ERROR"] = 60] = "SETTINGS_ERROR";
    ErrorCodes[ErrorCodes["TASK_ERROR"] = 61] = "TASK_ERROR";
    ErrorCodes[ErrorCodes["JOB_ERROR"] = 62] = "JOB_ERROR";
    ErrorCodes[ErrorCodes["LocationLookUp_ERROR"] = 63] = "LocationLookUp_ERROR";
    ErrorCodes[ErrorCodes["ALBUM_ERROR"] = 70] = "ALBUM_ERROR";
})(ErrorCodes || (exports.ErrorCodes = ErrorCodes = {}));
class ErrorDTO {
    constructor(code, message, details, req) {
        this.code = code;
        this.message = message;
        this.details = details;
        this.request = { method: '', url: '' };
        this.detailsStr =
            (this.details ? this.details.toString() : '') || ErrorCodes[code];
        if (req) {
            this.request = {
                method: req.method,
                url: req.url,
            };
        }
    }
    toString() {
        return '[' + ErrorCodes[this.code] + '] ' + this.message + this.detailsStr;
    }
}
exports.ErrorDTO = ErrorDTO;

//# sourceMappingURL=Error.js.map
