"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

//# sourceMappingURL=MDFileDTO.js.map
