"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LRU = exports.Utils = void 0;
const HTMLCharCodes_1 = require("./HTMLCharCodes");
class Utils {
    static GUID() {
        const s4 = () => Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
        return s4() + s4() + '-' + s4() + s4();
    }
    static chunkArrays(arr, chunkSize) {
        const R = [];
        for (let i = 0; i < arr.length; i += chunkSize) {
            R.push(arr.slice(i, i + chunkSize));
        }
        return R;
    }
    static wait(time) {
        return new Promise((resolve) => {
            setTimeout(resolve, time);
        });
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static removeNullOrEmptyObj(obj) {
        if (typeof obj !== 'object' || obj == null) {
            return obj;
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        if (obj._____removeNullOrEmptyObjvisiting) {
            throw new Error('Recursive call detected');
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        obj._____removeNullOrEmptyObjvisiting = true;
        const keys = Object.keys(obj);
        for (const key of keys) {
            if (obj[key] !== null && typeof obj[key] === 'object') {
                if (Utils.removeNullOrEmptyObj(obj[key])) {
                    if (Object.keys(obj[key]).length === 0) {
                        delete obj[key];
                    }
                }
            }
            else if (obj[key] === null || obj[key] === undefined) {
                delete obj[key];
            }
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        delete obj._____removeNullOrEmptyObjvisiting;
        return obj;
    }
    static clone(object) {
        return JSON.parse(JSON.stringify(object));
    }
    static shallowClone(object) {
        const c = {};
        for (const e of Object.entries(object)) {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            c[e[0]] = e[1];
        }
        return c;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static zeroPrefix(number, length) {
        if (!isNaN(number)) {
            const zerosToAdd = Math.max(length - String(number).length, 0);
            return '0'.repeat(zerosToAdd) + number;
        }
        else {
            return '0'.repeat(number);
        }
    }
    /**
     * Checks if the two input (let them be objects or arrays or just primitives) are equal
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static equalsFilter(object, filter, skipProp = []) {
        if (typeof filter !== 'object' || filter == null) {
            return object === filter;
        }
        if (!object) {
            return false;
        }
        if (Array.isArray(object) && object.length !== filter.length) {
            return false;
        }
        const keys = Object.keys(filter);
        for (const key of keys) {
            if (skipProp.includes(key)) {
                continue;
            }
            if (typeof filter[key] === 'object') {
                if (Utils.equalsFilter(object[key], filter[key], skipProp) === false) {
                    return false;
                }
            }
            else if (object[key] !== filter[key]) {
                return false;
            }
        }
        return true;
    }
    static toIsoString(d) {
        if (!(d instanceof Date)) {
            d = new Date(d);
        }
        return d.getUTCFullYear() + '-' + d.getUTCMonth() + '-' + d.getUTCDate();
    }
    static toIsoTimestampString(YYYYMMDD, hhmmss) {
        if (YYYYMMDD && hhmmss) {
            // Regular expression to match YYYYMMDD format
            const dateRegex = /^(\d{4})(\d{2})(\d{2})$/;
            // Regular expression to match hhmmss+/-ohom format
            const timeRegex = /^(\d{2})(\d{2})(\d{2})([+-]\d{2})?(\d{2})?$/;
            const [, year, month, day] = YYYYMMDD.match(dateRegex);
            const [, hour, minute, second, offsetHour, offsetMinute] = hhmmss.match(timeRegex);
            const isoTimestamp = `${year}-${month}-${day}T${hour}:${minute}:${second}`;
            if (offsetHour && offsetMinute) {
                return isoTimestamp + `${offsetHour}:${offsetMinute}`;
            }
            else {
                return isoTimestamp;
            }
        }
        else {
            return undefined;
        }
    }
    static makeUTCMidnight(d, offset) {
        if (!(d instanceof Date)) {
            d = new Date(d);
        }
        d = new Date(new Date(d).toISOString().substring(0, 19) + (offset ? offset : '+00:00'));
        d.setUTCHours(0);
        d.setUTCMinutes(0);
        d.setUTCSeconds(0);
        d.setUTCMilliseconds(0);
        return d;
    }
    static getUTCFullYear(d, offset) {
        if (!(d instanceof Date)) {
            d = new Date(d);
        }
        return new Date(new Date(d).toISOString().substring(0, 19) + (offset ? offset : '+00:00')).getUTCFullYear();
    }
    static getFullYear(d, offset) {
        if (!(d instanceof Date)) {
            d = new Date(d);
        }
        return new Date(new Date(d).toISOString().substring(0, 19) + (offset ? offset : '')).getFullYear();
    }
    //function to convert timestamp into milliseconds taking offset into account
    static timestampToMS(timestamp, offset) {
        if (!timestamp) {
            return undefined;
        }
        //replace : with - in the yyyy-mm-dd part of the timestamp.
        let formattedTimestamp = timestamp.substring(0, 9).replaceAll(':', '-') + timestamp.substring(9, timestamp.length);
        if (formattedTimestamp.indexOf('Z') > 0) { //replace Z (and what comes after the Z) with offset
            formattedTimestamp = formattedTimestamp.substring(0, formattedTimestamp.indexOf('Z')) + (offset ? offset : '+00:00');
        }
        else if (formattedTimestamp.indexOf('+') > 0 || timestamp.substring(9, timestamp.length).indexOf('-') > 0) { //don't do anything
        }
        else { //add offset
            formattedTimestamp = formattedTimestamp + (offset ? offset : '+00:00');
        }
        //parse into MS and return
        return Date.parse(formattedTimestamp);
    }
    static splitTimestampAndOffset(timestamp) {
        if (!timestamp) {
            return [undefined, undefined];
        }
        //                                 |---------------------TIMESTAMP WITH OPTIONAL MILLISECONDS--------------------||-OPTIONAL TZONE--|
        //                                 |YYYY           MM           DD            HH         MM         SS (MS optio)||(timezone offset)|
        const timestampWithOffsetRegex = /^(\d{4}[-.: ]\d{2}[-.: ]\d{2}[-.: T]\d{2}[-.: ]\d{2}[-.: ]\d{2}(?:\.\d+)?)([+-]\d{2}:\d{2})?$/;
        const match = timestamp.match(timestampWithOffsetRegex);
        if (match) {
            return [match[1], match[2]]; //match[0] is the full string, not interested in that.
        }
        else {
            return [undefined, undefined];
        }
    }
    //function to calculate offset from exif.exif.gpsTimeStamp or exif.gps.GPSDateStamp + exif.gps.GPSTimestamp
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static getTimeOffsetByGPSStamp(timestamp, gpsTimeStamp, gps) {
        let UTCTimestamp = gpsTimeStamp;
        if (!UTCTimestamp &&
            gps &&
            gps.GPSDateStamp &&
            gps.GPSTimeStamp) { //else use exif.gps.GPS*Stamp if available
            //GPS timestamp is always UTC (+00:00)
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            UTCTimestamp = gps.GPSDateStamp.replaceAll(':', '-') + ' ' + gps.GPSTimeStamp.map((num) => Utils.zeroPrefix(num, 2)).join(':');
        }
        if (UTCTimestamp && timestamp) {
            //offset in minutes is the difference between gps timestamp, and given timestamp
            //to calculate this correctly, we have to work with the same offset
            const offsetMinutes = Math.round((Utils.timestampToMS(timestamp, '+00:00') - Utils.timestampToMS(UTCTimestamp, '+00:00')) / 1000 / 60);
            return Utils.getOffsetString(offsetMinutes);
        }
        else {
            return undefined;
        }
    }
    static getOffsetString(offsetMinutes) {
        if (-720 <= offsetMinutes && offsetMinutes <= 840) {
            //valid offset is within -12 and +14 hrs (https://en.wikipedia.org/wiki/List_of_UTC_offsets)
            return (offsetMinutes < 0 ? '-' : '+') + //leading +/-
                Utils.zeroPrefix(Math.trunc(Math.abs(offsetMinutes) / 60), 2) + ':' + //zeropadded hours and ':'
                Utils.zeroPrefix((Math.abs(offsetMinutes) % 60), 2); //zeropadded minutes
        }
        else {
            return undefined;
        }
    }
    static getOffsetMinutes(offsetString) {
        const regex = /^([+-](0[0-9]|1[0-4]):[0-5][0-9])$/; //checks if offset is between -14:00 and +14:00.
        //-12:00 is the lowest valid UTC-offset, but we allow down to -14 for efficiency
        if (regex.test(offsetString)) {
            const hhmm = offsetString.split(':');
            const hours = parseInt(hhmm[0]);
            return hours < 0 ? ((hours * 60) - parseInt(hhmm[1])) : ((hours * 60) + parseInt(hhmm[1]));
        }
        else {
            return undefined;
        }
    }
    //Get the MS of the creationDate, adjusted for  the offset. Effectively getting the MS value as if the photo did not contain an offset.
    //One can consider this "Local" time of the photo. Starting point is UTC, as MetadataLoader loads timestamps with unknown timestamps as UTC.
    static getLocalTimeMS(creationDate, creationDateOffset) {
        const offsetMinutes = Utils.getOffsetMinutes(creationDateOffset);
        return creationDate + (offsetMinutes ? (offsetMinutes * 60000) : 0);
    }
    //Like getLocalTimeMS, but only if localTime is true, otherwise just returns creationDate (global time)
    static getTimeMS(creationDate, creationDateOffset, localTime) {
        if (localTime) {
            return Utils.getLocalTimeMS(creationDate, creationDateOffset);
        }
        else {
            return creationDate;
        }
    }
    static isLeapYear(year) {
        return (0 == year % 4) && (0 != year % 100) || (0 == year % 400);
    }
    static isDateFromLeapYear(date) {
        return Utils.isLeapYear(date.getFullYear());
    }
    // Get Day of Year
    static getDayOfYear(date) {
        //Day-number at the start of Jan to Dec. A month baseline
        const dayCount = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        const mn = date.getMonth();
        let dayOfYear = dayCount[mn] + date.getDate(); //add the date to the month baseline
        if (mn > 1 && Utils.isLeapYear((date.getFullYear()))) {
            dayOfYear++; //Add an extra day for march to december (mn>1) on leap years
        }
        return dayOfYear;
    }
    //Adding months to a date differently from standard JS
    //this function makes sure that if date is the 31st and you add a month, you will get the last day of the next month
    //so adding or subtracting a month from 31st of march will give 30th of april or 28th of february respectively (29th on leap years).
    static addMonthToDate(date, numMonths) {
        const result = new Date(date);
        const expectedMonth = ((date.getMonth() + numMonths) % 12 + 12) % 12; //inner %12 + 12 makes correct handling of negative months
        result.setMonth(result.getMonth() + numMonths);
        if (result.getMonth() !== expectedMonth) {
            result.setDate(0);
        }
        return result;
    }
    static renderDataSize(size) {
        const postFixes = ['B', 'KB', 'MB', 'GB', 'TB'];
        let index = 0;
        while (size > 1000 && index < postFixes.length - 1) {
            size /= 1000;
            index++;
        }
        return size.toFixed(2) + postFixes[index];
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static getUnique(arr) {
        return arr.filter((value, index, arr) => arr.indexOf(value) === index);
    }
    static createRange(from, to) {
        const arr = new Array(to - from + 1);
        let c = to - from + 1;
        while (c--) {
            arr[c] = to--;
        }
        return arr;
    }
    static canonizePath(path) {
        return path
            .replace(new RegExp('\\\\', 'g'), '/')
            .replace(new RegExp('/+', 'g'), '/');
    }
    static concatUrls(...args) {
        let url = '';
        for (const item of args) {
            if (item === '' || typeof item === 'undefined') {
                continue;
            }
            const part = item.replace(new RegExp('\\\\', 'g'), '/');
            if (part === '/' || part === './') {
                continue;
            }
            url += part + '/';
        }
        url = url.replace(/(https?:\/\/)|(\/){2,}/g, '$1$2');
        if (url.trim() === '') {
            url = './';
        }
        return url.substring(0, url.length - 1);
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static updateKeys(targetObject, sourceObject) {
        Object.keys(sourceObject).forEach((key) => {
            if (typeof targetObject[key] === 'undefined') {
                return;
            }
            if (typeof targetObject[key] === 'object') {
                Utils.updateKeys(targetObject[key], sourceObject[key]);
            }
            else {
                targetObject[key] = sourceObject[key];
            }
        });
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static setKeys(targetObject, sourceObject) {
        Object.keys(sourceObject).forEach((key) => {
            if (typeof targetObject[key] === 'object') {
                Utils.setKeys(targetObject[key], sourceObject[key]);
            }
            else {
                targetObject[key] = sourceObject[key];
            }
        });
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static setKeysForced(targetObject, sourceObject) {
        Object.keys(sourceObject).forEach((key) => {
            if (typeof sourceObject[key] === 'object') {
                if (typeof targetObject[key] === 'undefined') {
                    targetObject[key] = {};
                }
                Utils.setKeysForced(targetObject[key], sourceObject[key]);
            }
            else {
                targetObject[key] = sourceObject[key];
            }
        });
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static isValidEnumInt(EnumType, value) {
        return typeof EnumType[value] === 'string';
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static enumToArray(EnumType) {
        const arr = [];
        for (const enumMember in EnumType) {
            // eslint-disable-next-line no-prototype-builtins
            if (!EnumType.hasOwnProperty(enumMember)) {
                continue;
            }
            const key = parseInt(enumMember, 10);
            if (key >= 0) {
                arr.push({ key, value: EnumType[enumMember] });
            }
        }
        return arr;
    }
    static findClosest(num, arr) {
        let curr = arr[0];
        let diff = Math.abs(num - curr);
        arr.forEach((value) => {
            const newDiff = Math.abs(num - value);
            if (newDiff < diff) {
                diff = newDiff;
                curr = value;
            }
        });
        return curr;
    }
    static findClosestinSorted(num, arr) {
        let curr = arr[0];
        let diff = Math.abs(num - curr);
        for (const item of arr) {
            const newDiff = Math.abs(num - item);
            if (newDiff > diff) {
                break;
            }
            diff = newDiff;
            curr = item;
        }
        return curr;
    }
    static asciiToUTF8(text) {
        if (text) {
            // Check for corrupted IPTC data - very long strings with binary content indicate corruption
            // The specific corruption we observed: 25k+ chars with mix of high-ASCII and control chars
            if (text.length > 1000) {
                // Count characters that are likely binary corruption (high-ASCII and control chars)
                const printableAscii = text.replace(/[^\x20-\x7E]/g, '').length;
                const nonPrintableRatio = (text.length - printableAscii) / text.length;
                // If more than 30% are non-printable ASCII, it's likely corrupted binary data
                if (nonPrintableRatio > 0.3) {
                    return undefined;
                }
            }
            return Buffer.from(text, 'ascii').toString('utf-8');
        }
        else {
            return text;
        }
    }
    static decodeHTMLChars(text) {
        if (text) {
            const newtext = text.replace(/&#([0-9]{1,3});/gi, function (match, numStr) {
                return String.fromCharCode(parseInt(numStr, 10));
            });
            return newtext.replace(/&[^;]+;/g, function (match) {
                const char = HTMLCharCodes_1.HTMLChar[match];
                return char ? char : match;
            });
        }
        else {
            return text;
        }
    }
    static isUInt32(value, max = 4294967295) {
        value = parseInt('' + value, 10);
        return !isNaN(value) && value >= 0 && value <= max;
    }
    static isInt32(value) {
        value = parseFloat('' + value);
        return !isNaN(value) && value >= -2147483648 && value <= 2147483647;
    }
    static isFloat32(value) {
        const E = Math.pow(10, 38);
        const nE = Math.pow(10, -38);
        return (!isNaN(value) &&
            ((value >= -3.402823466 * E && value <= -1.175494351 * nE) ||
                (value <= 3.402823466 * E && value >= 1.175494351 * nE)));
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static getAnyX(num, arr, start = 0) {
        if (num <= 0 || num > arr.length || start >= arr.length) {
            return [];
        }
        if (num <= 1) {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            return arr.slice(start).map((e) => [e]);
        }
        if (num === arr.length - start) {
            return [arr.slice(start)];
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const ret = [];
        for (let i = start; i < arr.length; ++i) {
            Utils.getAnyX(num - 1, arr, i + 1).forEach((a) => {
                a.push(arr[i]);
                ret.push(a);
            });
        }
        return ret;
    }
    static xmpExifGpsCoordinateToDecimalDegrees(text) {
        if (!text) {
            return undefined;
        }
        const parts = text.match(/^([0-9]+),([0-9.]+)([EWNS])$/);
        const degrees = parseInt(parts[1], 10);
        const minutes = parseFloat(parts[2]);
        const sign = (parts[3] === 'N' || parts[3] === 'E') ? 1 : -1;
        return (sign * (degrees + (minutes / 60.0)));
    }
    static sortableFilename(filename) {
        const lastDot = filename.lastIndexOf('.');
        // Avoid 0 as well as -1 to prevent empty names for extensionless dot-files
        if (lastDot > 0) {
            return filename.substring(0, lastDot);
        }
        // Fallback to the full name
        return filename;
    }
}
exports.Utils = Utils;
class LRU {
    constructor(size) {
        this.size = size;
        this.data = {};
    }
    set(key, value) {
        this.data[key] = { usage: Date.now(), value };
        if (Object.keys(this.data).length > this.size) {
            let oldestK = key;
            let oldest = this.data[oldestK].usage;
            for (const k in this.data) {
                if (this.data[k].usage < oldest) {
                    oldestK = k;
                    oldest = this.data[oldestK].usage;
                }
            }
            delete this.data[oldestK];
        }
    }
    get(key) {
        if (!this.data[key]) {
            return;
        }
        return this.data[key].value;
    }
}
exports.LRU = LRU;

//# sourceMappingURL=Utils.js.map
