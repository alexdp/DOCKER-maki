"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProjectPath = exports.ProjectPathClass = void 0;
const path = require("path");
const fs = require("fs");
class ProjectPathClass {
    init(cfg) {
        this.cfg = cfg;
        this.reset();
    }
    normalizeRelative(pathStr) {
        return path.join(pathStr, path.sep);
    }
    getAbsolutePath(pathStr) {
        return path.isAbsolute(pathStr) ? pathStr : path.join(this.Root, pathStr);
    }
    getRelativePathToImages(pathStr) {
        return path.relative(this.ImageFolder, pathStr);
    }
    reset() {
        this.Root = path.join(__dirname, '/../../');
        this.FrontendFolder = path.join(this.Root, 'dist');
        this.ImageFolder = this.getAbsolutePath(this.cfg.Media.folder);
        this.TempFolder = this.getAbsolutePath(this.cfg.Media.tempFolder);
        this.TranscodedFolder = path.join(this.TempFolder, 'tc');
        this.FacesFolder = path.join(this.TempFolder, 'f');
        this.DBFolder = this.getAbsolutePath(this.cfg.Database.dbFolder);
        this.ExtensionFolder = this.getAbsolutePath(this.cfg.Extensions.folder);
        // create thumbnail folder if not exist
        if (!fs.existsSync(this.TempFolder)) {
            fs.mkdirSync(this.TempFolder);
        }
    }
}
exports.ProjectPathClass = ProjectPathClass;
exports.ProjectPath = new ProjectPathClass();

//# sourceMappingURL=ProjectPath.js.map
