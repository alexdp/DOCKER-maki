"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PersonEntry = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const PersonJunctionTable_1 = require("./PersonJunctionTable");
const EntityUtils_1 = require("../EntityUtils");
const ProjectedPersonCacheEntity_1 = require("./ProjectedPersonCacheEntity");
let PersonEntry = class PersonEntry {
};
exports.PersonEntry = PersonEntry;
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.PrimaryGeneratedColumn)({ unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], PersonEntry.prototype, "id", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({
        charset: EntityUtils_1.columnCharsetCS.charset,
        collation: EntityUtils_1.columnCharsetCS.collation,
    }),
    tslib_1.__metadata("design:type", String)
], PersonEntry.prototype, "name", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({ default: false }),
    tslib_1.__metadata("design:type", Boolean)
], PersonEntry.prototype, "isFavourite", void 0);
tslib_1.__decorate([
    (0, typeorm_1.OneToMany)(() => PersonJunctionTable_1.PersonJunctionTable, (junctionTable) => junctionTable.person),
    tslib_1.__metadata("design:type", Array)
], PersonEntry.prototype, "faces", void 0);
tslib_1.__decorate([
    (0, typeorm_1.OneToOne)(() => ProjectedPersonCacheEntity_1.ProjectedPersonCacheEntity, (ppc) => ppc.person),
    tslib_1.__metadata("design:type", ProjectedPersonCacheEntity_1.ProjectedPersonCacheEntity)
], PersonEntry.prototype, "cache", void 0);
exports.PersonEntry = PersonEntry = tslib_1.__decorate([
    (0, typeorm_1.Entity)(),
    (0, typeorm_1.Unique)(['name'])
], PersonEntry);

//# sourceMappingURL=PersonEntry.js.map
