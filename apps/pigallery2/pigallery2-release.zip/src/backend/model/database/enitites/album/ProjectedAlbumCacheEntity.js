"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProjectedAlbumCacheEntity = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const MediaEntity_1 = require("../MediaEntity");
const AlbumBaseEntity_1 = require("./AlbumBaseEntity");
let ProjectedAlbumCacheEntity = class ProjectedAlbumCacheEntity {
};
exports.ProjectedAlbumCacheEntity = ProjectedAlbumCacheEntity;
tslib_1.__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], ProjectedAlbumCacheEntity.prototype, "id", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, select: false }) // don't select it, we only use it to get the right cache for the given context
    ,
    tslib_1.__metadata("design:type", String)
], ProjectedAlbumCacheEntity.prototype, "projectionKey", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.ManyToOne)(() => AlbumBaseEntity_1.AlbumBaseEntity, {
        onDelete: 'CASCADE',
        nullable: false
    }),
    tslib_1.__metadata("design:type", AlbumBaseEntity_1.AlbumBaseEntity)
], ProjectedAlbumCacheEntity.prototype, "album", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('int', { unsigned: true, default: 0 }),
    tslib_1.__metadata("design:type", Number)
], ProjectedAlbumCacheEntity.prototype, "itemCount", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('bigint', { nullable: true, transformer: { from: (v) => v == null ? null : parseInt(v, 10), to: (v) => v } }),
    tslib_1.__metadata("design:type", Number)
], ProjectedAlbumCacheEntity.prototype, "oldestMedia", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('bigint', { nullable: true, transformer: { from: (v) => v == null ? null : parseInt(v, 10), to: (v) => v } }),
    tslib_1.__metadata("design:type", Number)
], ProjectedAlbumCacheEntity.prototype, "youngestMedia", void 0);
tslib_1.__decorate([
    (0, typeorm_1.ManyToOne)(() => MediaEntity_1.MediaEntity, { onDelete: 'SET NULL', nullable: true }),
    tslib_1.__metadata("design:type", MediaEntity_1.MediaEntity)
], ProjectedAlbumCacheEntity.prototype, "cover", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    tslib_1.__metadata("design:type", Boolean)
], ProjectedAlbumCacheEntity.prototype, "valid", void 0);
exports.ProjectedAlbumCacheEntity = ProjectedAlbumCacheEntity = tslib_1.__decorate([
    (0, typeorm_1.Entity)(),
    (0, typeorm_1.Unique)(['projectionKey', 'album'])
], ProjectedAlbumCacheEntity);

//# sourceMappingURL=ProjectedAlbumCacheEntity.js.map
