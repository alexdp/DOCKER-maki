"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProjectedPersonCacheEntity = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const PersonEntry_1 = require("./PersonEntry");
const PersonJunctionTable_1 = require("./PersonJunctionTable");
// Projection-aware cache for persons, analogous to ProjectedDirectoryCacheEntity
// Stores per-projection aggregates for a given person
let ProjectedPersonCacheEntity = class ProjectedPersonCacheEntity {
};
exports.ProjectedPersonCacheEntity = ProjectedPersonCacheEntity;
tslib_1.__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], ProjectedPersonCacheEntity.prototype, "id", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, select: false }) // not needed in payloads; used to select the right cache per session
    ,
    tslib_1.__metadata("design:type", String)
], ProjectedPersonCacheEntity.prototype, "projectionKey", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.ManyToOne)(() => PersonEntry_1.PersonEntry, {
        onDelete: 'CASCADE',
        nullable: false,
    }),
    tslib_1.__metadata("design:type", PersonEntry_1.PersonEntry)
], ProjectedPersonCacheEntity.prototype, "person", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('int', { unsigned: true, default: 0 }),
    tslib_1.__metadata("design:type", Number)
], ProjectedPersonCacheEntity.prototype, "count", void 0);
tslib_1.__decorate([
    (0, typeorm_1.ManyToOne)(() => PersonJunctionTable_1.PersonJunctionTable, {
        onDelete: 'SET NULL',
        nullable: true,
    }),
    tslib_1.__metadata("design:type", PersonJunctionTable_1.PersonJunctionTable)
], ProjectedPersonCacheEntity.prototype, "sampleRegion", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    tslib_1.__metadata("design:type", Boolean)
], ProjectedPersonCacheEntity.prototype, "valid", void 0);
exports.ProjectedPersonCacheEntity = ProjectedPersonCacheEntity = tslib_1.__decorate([
    (0, typeorm_1.Entity)(),
    (0, typeorm_1.Unique)(['projectionKey', 'person'])
], ProjectedPersonCacheEntity);

//# sourceMappingURL=ProjectedPersonCacheEntity.js.map
