"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumBaseEntity = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const EntityUtils_1 = require("../EntityUtils");
const ProjectedAlbumCacheEntity_1 = require("./ProjectedAlbumCacheEntity");
let AlbumBaseEntity = class AlbumBaseEntity {
};
exports.AlbumBaseEntity = AlbumBaseEntity;
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.PrimaryGeneratedColumn)({ unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], AlbumBaseEntity.prototype, "id", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)(EntityUtils_1.columnCharsetCS),
    tslib_1.__metadata("design:type", String)
], AlbumBaseEntity.prototype, "name", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({ default: false }),
    tslib_1.__metadata("design:type", Boolean)
], AlbumBaseEntity.prototype, "locked", void 0);
tslib_1.__decorate([
    (0, typeorm_1.OneToOne)(() => ProjectedAlbumCacheEntity_1.ProjectedAlbumCacheEntity, (c) => c.album),
    tslib_1.__metadata("design:type", ProjectedAlbumCacheEntity_1.ProjectedAlbumCacheEntity)
], AlbumBaseEntity.prototype, "cache", void 0);
exports.AlbumBaseEntity = AlbumBaseEntity = tslib_1.__decorate([
    (0, typeorm_1.Entity)(),
    (0, typeorm_1.TableInheritance)({ column: { type: 'varchar', name: 'type', length: 24 } })
], AlbumBaseEntity);

//# sourceMappingURL=AlbumBaseEntity.js.map
