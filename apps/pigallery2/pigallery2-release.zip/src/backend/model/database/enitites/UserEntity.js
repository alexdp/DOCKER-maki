"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserEntity = void 0;
const tslib_1 = require("tslib");
const UserDTO_1 = require("../../../../common/entities/UserDTO");
const typeorm_1 = require("typeorm");
let UserEntity = class UserEntity {
};
exports.UserEntity = UserEntity;
tslib_1.__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    tslib_1.__metadata("design:type", Number)
], UserEntity.prototype, "id", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)(),
    tslib_1.__metadata("design:type", String)
], UserEntity.prototype, "name", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)(),
    tslib_1.__metadata("design:type", String)
], UserEntity.prototype, "password", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('smallint'),
    tslib_1.__metadata("design:type", Number)
], UserEntity.prototype, "role", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    tslib_1.__metadata("design:type", Boolean)
], UserEntity.prototype, "overrideAllowBlockList", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({
        type: 'text',
        nullable: true,
        transformer: {
            from: (val) => {
                return val ? JSON.parse(val) : null;
            },
            to: (val) => {
                return val ? JSON.stringify(val) : null;
            },
        },
    }),
    tslib_1.__metadata("design:type", Object)
], UserEntity.prototype, "allowQuery", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({
        type: 'text',
        nullable: true,
        transformer: {
            from: (val) => {
                return val ? JSON.parse(val) : null;
            },
            to: (val) => {
                return val ? JSON.stringify(val) : null;
            },
        },
    }),
    tslib_1.__metadata("design:type", Object)
], UserEntity.prototype, "blockQuery", void 0);
exports.UserEntity = UserEntity = tslib_1.__decorate([
    (0, typeorm_1.Entity)(),
    (0, typeorm_1.Unique)(['name'])
], UserEntity);

//# sourceMappingURL=UserEntity.js.map
