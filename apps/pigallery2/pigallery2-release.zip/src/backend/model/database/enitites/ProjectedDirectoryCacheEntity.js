"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProjectedDirectoryCacheEntity = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const MediaEntity_1 = require("./MediaEntity");
const DirectoryEntity_1 = require("./DirectoryEntity");
let ProjectedDirectoryCacheEntity = class ProjectedDirectoryCacheEntity {
};
exports.ProjectedDirectoryCacheEntity = ProjectedDirectoryCacheEntity;
tslib_1.__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], ProjectedDirectoryCacheEntity.prototype, "id", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, select: false }) // don't select it, we only use it to get the right cache for the given context
    ,
    tslib_1.__metadata("design:type", String)
], ProjectedDirectoryCacheEntity.prototype, "projectionKey", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.ManyToOne)(() => DirectoryEntity_1.DirectoryEntity, {
        onDelete: 'CASCADE',
        nullable: false
    }),
    tslib_1.__metadata("design:type", DirectoryEntity_1.DirectoryEntity)
], ProjectedDirectoryCacheEntity.prototype, "directory", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('int', { unsigned: true, default: 0 }),
    tslib_1.__metadata("design:type", Number)
], ProjectedDirectoryCacheEntity.prototype, "mediaCount", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('int', { unsigned: true, default: 0 }),
    tslib_1.__metadata("design:type", Number)
], ProjectedDirectoryCacheEntity.prototype, "recursiveMediaCount", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('bigint', { nullable: true, transformer: { from: (v) => v == null ? null : parseInt(v, 10), to: (v) => v } }),
    tslib_1.__metadata("design:type", Number)
], ProjectedDirectoryCacheEntity.prototype, "oldestMedia", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('bigint', { nullable: true, transformer: { from: (v) => v == null ? null : parseInt(v, 10), to: (v) => v } }),
    tslib_1.__metadata("design:type", Number)
], ProjectedDirectoryCacheEntity.prototype, "youngestMedia", void 0);
tslib_1.__decorate([
    (0, typeorm_1.ManyToOne)(() => MediaEntity_1.MediaEntity, { onDelete: 'SET NULL', nullable: true }),
    tslib_1.__metadata("design:type", MediaEntity_1.MediaEntity)
], ProjectedDirectoryCacheEntity.prototype, "cover", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)() // Add index for valid column used in joins
    ,
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    tslib_1.__metadata("design:type", Boolean)
], ProjectedDirectoryCacheEntity.prototype, "valid", void 0);
exports.ProjectedDirectoryCacheEntity = ProjectedDirectoryCacheEntity = tslib_1.__decorate([
    (0, typeorm_1.Entity)(),
    (0, typeorm_1.Unique)(['projectionKey', 'directory']),
    (0, typeorm_1.Index)(['directory', 'projectionKey', 'valid']) // Composite index for join optimization
    ,
    (0, typeorm_1.Index)(['projectionKey', 'valid']) // Index for projection key + valid queries
], ProjectedDirectoryCacheEntity);

//# sourceMappingURL=ProjectedDirectoryCacheEntity.js.map
