"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VersionEntity = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
let VersionEntity = class VersionEntity {
};
exports.VersionEntity = VersionEntity;
tslib_1.__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    tslib_1.__metadata("design:type", Number)
], VersionEntity.prototype, "id", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)(),
    tslib_1.__metadata("design:type", Number)
], VersionEntity.prototype, "version", void 0);
exports.VersionEntity = VersionEntity = tslib_1.__decorate([
    (0, typeorm_1.Entity)()
], VersionEntity);

//# sourceMappingURL=VersionEntity.js.map
