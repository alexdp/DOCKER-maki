"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProjectionAwareManager = void 0;
/**
 * Base class for managers that handle projection-aware caching.
 * Provides common functionality for managers that need to cache data
 * per user projection (like AlbumManager and PersonManager).
 */
class ProjectionAwareManager {
    constructor() {
        this.cache = {};
    }
    /**
     * Get all entities for the given session. Subclasses should implement
     * the actual loading logic in loadEntities().
     */
    async getAll(session) {
        const cached = this.getCachedEntities(session);
        if (cached !== null) {
            return cached;
        }
        const entities = await this.loadEntities(session);
        this.setCachedEntities(session, entities);
        return entities;
    }
    async invalidateCache(changedDir) {
        await this.invalidateDBCache(changedDir);
        this.resetMemoryCache();
    }
    /**
     * Default implementation of onNewDataVersion that invalidates cache.
     * Subclasses can override for more specific behavior.
     */
    async onNewDataVersion(changedDir) {
        await this.invalidateCache(changedDir);
    }
    /**
     * Reset the entire memory cache
     */
    resetMemoryCache() {
        this.cache = {};
    }
    /**
     * Get cached entities for the given session projection
     */
    getCachedEntities(session) {
        return this.cache[session.user.projectionKey] || null;
    }
    /**
     * Set cached entities for the given session projection
     */
    setCachedEntities(session, entities) {
        this.cache[session.user.projectionKey] = entities;
    }
}
exports.ProjectionAwareManager = ProjectionAwareManager;

//# sourceMappingURL=ProjectionAwareManager.js.map
