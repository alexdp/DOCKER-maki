"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoverManager = void 0;
const tslib_1 = require("tslib");
const Config_1 = require("../../../common/config/private/Config");
const typeorm_1 = require("typeorm");
const MediaEntity_1 = require("./enitites/MediaEntity");
const DiskManager_1 = require("../fileaccess/DiskManager");
const ObjectManagers_1 = require("../ObjectManagers");
const PrivateConfig_1 = require("../../../common/config/private/PrivateConfig");
const SQLConnection_1 = require("./SQLConnection");
const SearchQueryDTO_1 = require("../../../common/entities/SearchQueryDTO");
const DirectoryEntity_1 = require("./enitites/DirectoryEntity");
const Utils_1 = require("../../../common/Utils");
const Logger_1 = require("../../Logger");
const SearchManager_1 = require("./SearchManager");
const ExtensionDecorator_1 = require("../extension/ExtensionDecorator");
const SessionContext_1 = require("../SessionContext");
const ProjectedDirectoryCacheEntity_1 = require("./enitites/ProjectedDirectoryCacheEntity");
const LOG_TAG = '[CoverManager]';
class CoverManager {
    static { this.DIRECTORY_SELECT = ['directory.name', 'directory.path']; }
    async resetCovers() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        await connection
            .createQueryBuilder()
            .update(ProjectedDirectoryCacheEntity_1.ProjectedDirectoryCacheEntity)
            .set({ valid: false })
            .execute();
    }
    async getCoverForAlbum(session, album) {
        const albumQuery = await ObjectManagers_1.ObjectManagers.getInstance().SearchManager.prepareAndBuildWhereQuery(album.searchQuery);
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const coverQuery = () => {
            const query = connection
                .getRepository(MediaEntity_1.MediaEntity)
                .createQueryBuilder('media')
                .innerJoin('media.directory', 'directory')
                .select(['media.name', 'media.id', ...CoverManager.DIRECTORY_SELECT])
                .where(albumQuery);
            if (session.projectionQuery) {
                query.andWhere(session.projectionQuery);
            }
            SearchManager_1.SearchManager.setSorting(query, Config_1.Config.AlbumCover.Sorting);
            return query;
        };
        let coverMedia = null;
        if (Config_1.Config.AlbumCover.SearchQuery &&
            !Utils_1.Utils.equalsFilter(Config_1.Config.AlbumCover.SearchQuery, {
                type: SearchQueryDTO_1.SearchQueryTypes.any_text,
                text: '',
            })) {
            try {
                const coverFilterQuery = await ObjectManagers_1.ObjectManagers.getInstance().SearchManager.prepareAndBuildWhereQuery(Config_1.Config.AlbumCover.SearchQuery);
                coverMedia = await coverQuery()
                    .andWhere(coverFilterQuery)
                    .limit(1)
                    .getOne();
            }
            catch (e) {
                Logger_1.Logger.error(LOG_TAG, 'Cant get album cover using:', JSON.stringify(album.searchQuery), JSON.stringify(Config_1.Config.AlbumCover.SearchQuery));
                throw e;
            }
        }
        if (!coverMedia) {
            try {
                coverMedia = await coverQuery().limit(1).getOne();
            }
            catch (e) {
                Logger_1.Logger.error(LOG_TAG, 'Cant get album cover using:', JSON.stringify(album.searchQuery));
                throw e;
            }
        }
        return coverMedia || null;
    }
    async getPartialDirsWithoutCovers() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        return await connection
            .getRepository(DirectoryEntity_1.DirectoryEntity)
            .createQueryBuilder('directory')
            .leftJoin('directory.cache', 'cache')
            .where(new typeorm_1.Brackets(qb => {
            qb.where('cache.valid = :valid', { valid: 0 })
                .orWhere('cache.valid IS NULL');
        }))
            .select(['directory.name as name', 'directory.id as id', 'directory.path as path'])
            .distinct(true)
            .getRawMany();
    }
    async getCoverForDirectory(session, dir) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const coverQuery = () => {
            const query = connection
                .getRepository(MediaEntity_1.MediaEntity)
                .createQueryBuilder('media')
                .innerJoin('media.directory', 'directory')
                .select(['media.name', 'media.id', ...CoverManager.DIRECTORY_SELECT])
                .where(new typeorm_1.Brackets((q) => {
                q.where('media.directory = :dir', {
                    dir: dir.id,
                });
                if (Config_1.Config.Database.type === PrivateConfig_1.DatabaseType.mysql) {
                    q.orWhere('directory.path like :path || \'%\'', {
                        path: DiskManager_1.DiskManager.pathFromParent(dir),
                    });
                }
                else {
                    q.orWhere('directory.path GLOB :path', {
                        path: DiskManager_1.DiskManager.pathFromParent(dir)
                            // glob escaping. see https://github.com/bpatrik/pigallery2/issues/621
                            .replaceAll('[', '[[]') + '*',
                    });
                }
            }));
            // Select from the directory if any otherwise from any subdirectories.
            // (There is no priority between subdirectories)
            query.orderBy(`CASE WHEN directory.id = ${dir.id} THEN 0 ELSE 1 END`, 'ASC');
            if (session.projectionQuery) {
                query.andWhere(session.projectionQuery);
            }
            SearchManager_1.SearchManager.setSorting(query, Config_1.Config.AlbumCover.Sorting);
            return query;
        };
        let coverMedia = null;
        if (Config_1.Config.AlbumCover.SearchQuery &&
            !Utils_1.Utils.equalsFilter(Config_1.Config.AlbumCover.SearchQuery, {
                type: SearchQueryDTO_1.SearchQueryTypes.any_text,
                text: '',
            })) {
            coverMedia = await coverQuery()
                .andWhere(await ObjectManagers_1.ObjectManagers.getInstance().SearchManager.prepareAndBuildWhereQuery(Config_1.Config.AlbumCover.SearchQuery))
                .limit(1)
                .getOne();
        }
        if (!coverMedia) {
            coverMedia = await coverQuery().limit(1).getOne();
        }
        return coverMedia;
    }
}
exports.CoverManager = CoverManager;
tslib_1.__decorate([
    (0, ExtensionDecorator_1.ExtensionDecorator)(e => e.gallery.CoverManager.getCoverForAlbum),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [SessionContext_1.SessionContext, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], CoverManager.prototype, "getCoverForAlbum", null);
tslib_1.__decorate([
    (0, ExtensionDecorator_1.ExtensionDecorator)(e => e.gallery.CoverManager.getCoverForDirectory),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [SessionContext_1.SessionContext, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], CoverManager.prototype, "getCoverForDirectory", null);

//# sourceMappingURL=CoverManager.js.map
