"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProjectedCacheManager = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const SQLConnection_1 = require("./SQLConnection");
const ProjectedDirectoryCacheEntity_1 = require("./enitites/ProjectedDirectoryCacheEntity");
const ProjectedAlbumCacheEntity_1 = require("./enitites/album/ProjectedAlbumCacheEntity");
const DirectoryEntity_1 = require("./enitites/DirectoryEntity");
const ObjectManagers_1 = require("../ObjectManagers");
const UserEntity_1 = require("./enitites/UserEntity");
const SharingEntity_1 = require("./enitites/SharingEntity");
const DiskManager_1 = require("../fileaccess/DiskManager");
const ExtensionDecorator_1 = require("../extension/ExtensionDecorator");
const Logger_1 = require("../../Logger");
const SessionManager_1 = require("./SessionManager");
const path = require("path");
const SessionContext_1 = require("../SessionContext");
const MediaEntity_1 = require("./enitites/MediaEntity");
const Config_1 = require("../../../common/config/private/Config");
const PrivateConfig_1 = require("../../../common/config/private/PrivateConfig");
const ProjectedPersonCacheEntity_1 = require("./enitites/person/ProjectedPersonCacheEntity");
const LOG_TAG = '[ProjectedCacheManager]';
class ProjectedCacheManager {
    async init() {
        // Cleanup at startup to avoid stale growth
        await this.cleanupNonExistingProjections();
    }
    async onNewDataVersion(changedDir) {
        if (!changedDir) {
            return;
        }
        await this.invalidateDirectoryCache(changedDir);
    }
    async getAllProjections() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const activeKeys = new Set();
        // Always include default projection key
        activeKeys.add(SessionManager_1.SessionManager.NO_PROJECTION_KEY);
        // Users
        const users = await connection.getRepository(UserEntity_1.UserEntity).find();
        for (const user of users) {
            const ctx = await ObjectManagers_1.ObjectManagers.getInstance().SessionManager.buildContext(user);
            if (ctx?.user?.projectionKey) {
                activeKeys.add(ctx.user.projectionKey);
            }
        }
        // Sharings
        const shares = await connection.getRepository(SharingEntity_1.SharingEntity)
            .createQueryBuilder('share')
            .leftJoinAndSelect('share.creator', 'creator')
            .getMany();
        for (const s of shares) {
            const q = ObjectManagers_1.ObjectManagers.getInstance().SessionManager.buildAllowListForSharing(s);
            const key = ObjectManagers_1.ObjectManagers.getInstance().SessionManager.createProjectionKey(q);
            activeKeys.add(key);
        }
        return Array.from(activeKeys);
    }
    async cleanupNonExistingProjections() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const keys = await this.getAllProjections();
        Logger_1.Logger.debug(LOG_TAG, 'Cleanup non existing projections, known number of keys: ' + keys.length);
        if (keys.length === 0) {
            // No known projections; nothing to prune safely
            return;
        }
        await connection.getRepository(ProjectedDirectoryCacheEntity_1.ProjectedDirectoryCacheEntity)
            .createQueryBuilder()
            .delete()
            .where('projectionKey NOT IN (:...keys)', { keys })
            .execute();
        await connection.getRepository(ProjectedAlbumCacheEntity_1.ProjectedAlbumCacheEntity)
            .createQueryBuilder()
            .delete()
            .where('projectionKey NOT IN (:...keys)', { keys })
            .execute();
        await connection.getRepository(ProjectedPersonCacheEntity_1.ProjectedPersonCacheEntity)
            .createQueryBuilder()
            .delete()
            .where('projectionKey NOT IN (:...keys)', { keys })
            .execute();
    }
    async getCacheForDirectory(connection, session, dir) {
        // Compute aggregates under the current projection (if any)
        const mediaRepo = connection.getRepository(MediaEntity_1.MediaEntity);
        const baseQb = mediaRepo
            .createQueryBuilder('media')
            .innerJoin('media.directory', 'directory')
            .where('directory.id = :dir', { dir: dir.id });
        if (session.projectionQuery) {
            baseQb.andWhere(session.projectionQuery);
        }
        const agg = await baseQb
            .select([
            'COUNT(*) as mediaCount',
            'MIN(media.metadata.creationDate) as oldest',
            'MAX(media.metadata.creationDate) as youngest',
        ])
            .getRawOne();
        const mediaCount = agg?.mediaCount != null ? parseInt(agg.mediaCount, 10) : 0;
        const oldestMedia = agg?.oldest != null ? parseInt(agg.oldest, 10) : null;
        const youngestMedia = agg?.youngest != null ? parseInt(agg.youngest, 10) : null;
        // Compute recursive media count under projection (includes children) using single SQL query
        const recQb = mediaRepo
            .createQueryBuilder('media')
            .innerJoin('media.directory', 'directory')
            .where(new typeorm_1.Brackets(q => {
            q.where('directory.id = :dir', { dir: dir.id });
            if (Config_1.Config.Database.type === PrivateConfig_1.DatabaseType.mysql) {
                q.orWhere('directory.path like :path || \'%\'', { path: DiskManager_1.DiskManager.pathFromParent(dir) });
            }
            else {
                q.orWhere('directory.path GLOB :path', {
                    path: DiskManager_1.DiskManager.pathFromParent(dir).replaceAll('[', '[[]') + '*',
                });
            }
        }));
        if (session.projectionQuery) {
            recQb.andWhere(session.projectionQuery);
        }
        const aggRec = await recQb.select(['COUNT(*) as cnt']).getRawOne();
        const recursiveMediaCount = aggRec?.cnt != null ? parseInt(aggRec.cnt, 10) : 0;
        // Compute cover respecting projection
        const coverMedia = await ObjectManagers_1.ObjectManagers.getInstance().CoverManager.getCoverForDirectory(session, dir);
        const cacheRepo = connection.getRepository(ProjectedDirectoryCacheEntity_1.ProjectedDirectoryCacheEntity);
        // Find existing cache row by (projectionKey, directory)
        const projectionKey = session?.user?.projectionKey;
        let row = await cacheRepo
            .createQueryBuilder('pdc')
            .leftJoin('pdc.directory', 'd')
            .where('pdc.projectionKey = :pk AND d.id = :dir', { pk: projectionKey, dir: dir.id })
            .getOne();
        if (!row) {
            row = new ProjectedDirectoryCacheEntity_1.ProjectedDirectoryCacheEntity();
            row.projectionKey = projectionKey;
            // Avoid fetching the full directory graph; assign relation by id only
            row.directory = { id: dir.id };
        }
        row.mediaCount = mediaCount || 0;
        row.recursiveMediaCount = recursiveMediaCount || 0;
        row.oldestMedia = oldestMedia ?? null;
        row.youngestMedia = youngestMedia ?? null;
        row.cover = coverMedia;
        row.valid = true;
        return row;
    }
    async setAndGetCacheForDirectory(connection, session, dir) {
        const cacheRepo = connection.getRepository(ProjectedDirectoryCacheEntity_1.ProjectedDirectoryCacheEntity);
        const row = await this.getCacheForDirectory(connection, session, dir);
        const ret = await cacheRepo.save(row);
        // we would not select these either
        delete ret.projectionKey;
        delete ret.directory;
        delete ret.id;
        if (ret.cover) {
            delete ret.cover.id;
        }
        return ret;
    }
    async setAndGetCacheForAlbum(connection, session, album) {
        const cacheRepo = connection.getRepository(ProjectedAlbumCacheEntity_1.ProjectedAlbumCacheEntity);
        // Find existing cache row by (projectionKey, album)
        const projectionKey = session?.user?.projectionKey;
        let row = await cacheRepo
            .createQueryBuilder('pac')
            .leftJoin('pac.album', 'a')
            .where('pac.projectionKey = :pk AND a.id = :albumId', { pk: projectionKey, albumId: album.id })
            .getOne();
        if (row && row.valid === true) {
            return row;
        }
        // Compute aggregates under the current projection (if any)
        const mediaRepo = connection.getRepository(MediaEntity_1.MediaEntity);
        // Build base query from album's search query
        const baseQb = mediaRepo
            .createQueryBuilder('media')
            .leftJoin('media.directory', 'directory');
        // Apply album search query constraints
        const albumWhereQuery = await ObjectManagers_1.ObjectManagers.getInstance().SearchManager.prepareAndBuildWhereQuery(album.searchQuery);
        baseQb.andWhere(albumWhereQuery);
        // Apply projection constraints if any
        if (session.projectionQuery) {
            baseQb.andWhere(session.projectionQuery);
        }
        const agg = await baseQb
            .select([
            'COUNT(*) as itemCount',
            'MIN(media.metadata.creationDate) as oldest',
            'MAX(media.metadata.creationDate) as youngest',
        ])
            .getRawOne();
        const itemCount = agg?.itemCount != null ? parseInt(agg.itemCount, 10) : 0;
        const oldestMedia = agg?.oldest != null ? parseInt(agg.oldest, 10) : null;
        const youngestMedia = agg?.youngest != null ? parseInt(agg.youngest, 10) : null;
        // Compute cover respecting projection
        const coverMedia = await ObjectManagers_1.ObjectManagers.getInstance().CoverManager.getCoverForAlbum(session, album);
        if (!row) {
            row = new ProjectedAlbumCacheEntity_1.ProjectedAlbumCacheEntity();
            row.projectionKey = projectionKey;
            // Avoid fetching the full album graph; assign relation by id only
            row.album = { id: album.id };
        }
        row.itemCount = itemCount || 0;
        row.oldestMedia = oldestMedia ?? null;
        row.youngestMedia = youngestMedia ?? null;
        row.cover = coverMedia;
        row.valid = true;
        const ret = await cacheRepo.save(row);
        // we would not select these either
        delete ret.projectionKey;
        delete ret.album;
        delete ret.id;
        if (ret.cover) {
            delete ret.cover.id;
        }
        return ret;
    }
    async invalidateDirectoryCache(dir) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const dirRepo = connection.getRepository(DirectoryEntity_1.DirectoryEntity);
        // Collect directory paths from target to root
        const paths = [];
        let fullPath = DiskManager_1.DiskManager.normalizeDirPath(path.join(dir.path, dir.name));
        const root = DiskManager_1.DiskManager.pathFromRelativeDirName('.');
        // Build path-name pairs for current directory and all parents
        while (fullPath !== root) {
            const name = DiskManager_1.DiskManager.dirName(fullPath);
            const parentPath = DiskManager_1.DiskManager.pathFromRelativeDirName(fullPath);
            paths.push({ path: parentPath, name });
            fullPath = parentPath;
        }
        // Add root directory
        paths.push({ path: DiskManager_1.DiskManager.pathFromRelativeDirName(root), name: DiskManager_1.DiskManager.dirName(root) });
        if (paths.length === 0) {
            return;
        }
        // Build query for all directories in one shot
        const qb = dirRepo.createQueryBuilder('d');
        paths.forEach((p, i) => {
            qb.orWhere(new typeorm_1.Brackets(q => {
                q.where(`d.path = :path${i}`, { [`path${i}`]: p.path })
                    .andWhere(`d.name = :name${i}`, { [`name${i}`]: p.name });
            }));
        });
        // Find matching directories and invalidate their cache entries
        const entities = await qb.getMany();
        if (entities.length === 0) {
            return;
        }
        // Invalidate all related cache entries in one operation
        await connection.getRepository(ProjectedDirectoryCacheEntity_1.ProjectedDirectoryCacheEntity)
            .createQueryBuilder()
            .update()
            .set({ valid: false })
            .where('directoryId IN (:...dirIds)', { dirIds: entities.map(e => e.id) })
            .execute();
    }
}
exports.ProjectedCacheManager = ProjectedCacheManager;
tslib_1.__decorate([
    (0, ExtensionDecorator_1.ExtensionDecorator)(e => e.gallery.ProjectedCacheManager.getCacheForDirectory),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [typeorm_1.Connection, SessionContext_1.SessionContext, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], ProjectedCacheManager.prototype, "getCacheForDirectory", null);
tslib_1.__decorate([
    (0, ExtensionDecorator_1.ExtensionDecorator)(e => e.gallery.ProjectedCacheManager.invalidateDirectoryCache),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], ProjectedCacheManager.prototype, "invalidateDirectoryCache", null);

//# sourceMappingURL=ProjectedCacheManager.js.map
