"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SharingManager = void 0;
const SQLConnection_1 = require("./SQLConnection");
const SharingEntity_1 = require("./enitites/SharingEntity");
const Config_1 = require("../../../common/config/private/Config");
const PasswordHelper_1 = require("../PasswordHelper");
const SearchQueryUtils_1 = require("../../../common/SearchQueryUtils");
class SharingManager {
    static async removeExpiredLink() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        return await connection
            .getRepository(SharingEntity_1.SharingEntity)
            .createQueryBuilder('share')
            .where('expires < :now', { now: Date.now() })
            .delete()
            .execute();
    }
    async deleteSharing(sharingKey) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const sharing = await connection
            .getRepository(SharingEntity_1.SharingEntity)
            .findOneBy({ sharingKey });
        await connection.getRepository(SharingEntity_1.SharingEntity).remove(sharing);
    }
    async listAll() {
        await SharingManager.removeExpiredLink();
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        return await connection
            .getRepository(SharingEntity_1.SharingEntity)
            .createQueryBuilder('share')
            .leftJoinAndSelect('share.creator', 'creator')
            .getMany();
    }
    async listAllForQuery(query, user) {
        await SharingManager.removeExpiredLink();
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const q = connection
            .getRepository(SharingEntity_1.SharingEntity)
            .createQueryBuilder('share')
            .leftJoinAndSelect('share.creator', 'creator')
            .where('share.searchQuery = :query', { query: SearchQueryUtils_1.SearchQueryUtils.stringifyForComparison(query) });
        if (user) {
            q.where('share.creator = :user', { user: user.id });
        }
        return await q.getMany();
    }
    async findOne(sharingKey) {
        await SharingManager.removeExpiredLink();
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        return await connection.getRepository(SharingEntity_1.SharingEntity)
            .createQueryBuilder('share')
            .leftJoinAndSelect('share.creator', 'creator')
            .where('share.sharingKey = :sharingKey', { sharingKey })
            .getOne();
    }
    async createSharing(sharing) {
        await SharingManager.removeExpiredLink();
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        if (sharing.password) {
            sharing.password = PasswordHelper_1.PasswordHelper.cryptPassword(sharing.password);
        }
        if (sharing.searchQuery) {
            SearchQueryUtils_1.SearchQueryUtils.validateSearchQuery(sharing.searchQuery);
            sharing.searchQuery = SearchQueryUtils_1.SearchQueryUtils.sortQuery(sharing.searchQuery);
        }
        return connection.getRepository(SharingEntity_1.SharingEntity).save(sharing);
    }
    async updateSharing(inSharing, forceUpdate) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const sharing = await connection.getRepository(SharingEntity_1.SharingEntity).findOneBy({
            id: inSharing.id,
            creator: inSharing.creator.id,
        });
        if (sharing.timeStamp < Date.now() - Config_1.Config.Sharing.updateTimeout &&
            forceUpdate !== true) {
            throw new Error('Sharing is locked, can\'t update anymore');
        }
        if (inSharing.password == null) {
            sharing.password = null;
        }
        else {
            sharing.password = PasswordHelper_1.PasswordHelper.cryptPassword(inSharing.password);
        }
        // allow updating searchQuery and canonicalize it
        sharing.searchQuery = SearchQueryUtils_1.SearchQueryUtils.sortQuery(inSharing.searchQuery);
        sharing.expires = inSharing.expires;
        return connection.getRepository(SharingEntity_1.SharingEntity).save(sharing);
    }
}
exports.SharingManager = SharingManager;

//# sourceMappingURL=SharingManager.js.map
