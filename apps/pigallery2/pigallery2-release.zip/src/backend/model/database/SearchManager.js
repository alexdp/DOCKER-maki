"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchManager = void 0;
/* eslint-disable no-case-declarations */
const AutoCompleteItem_1 = require("../../../common/entities/AutoCompleteItem");
const SQLConnection_1 = require("./SQLConnection");
const PhotoEntity_1 = require("./enitites/PhotoEntity");
const DirectoryEntity_1 = require("./enitites/DirectoryEntity");
const MediaEntity_1 = require("./enitites/MediaEntity");
const PersonEntry_1 = require("./enitites/person/PersonEntry");
const typeorm_1 = require("typeorm");
const Config_1 = require("../../../common/config/private/Config");
const SearchQueryDTO_1 = require("../../../common/entities/SearchQueryDTO");
const GalleryManager_1 = require("./GalleryManager");
const ObjectManagers_1 = require("../ObjectManagers");
const PrivateConfig_1 = require("../../../common/config/private/PrivateConfig");
const Utils_1 = require("../../../common/Utils");
const FileEntity_1 = require("./enitites/FileEntity");
const EntityUtils_1 = require("./enitites/EntityUtils");
const SortingMethods_1 = require("../../../common/entities/SortingMethods");
class SearchManager {
    constructor() {
        this.DIRECTORY_SELECT = [
            'directory.id',
            'directory.name',
            'directory.path',
        ];
        // makes all search query params unique, so typeorm won't mix them
        this.queryIdBase = 0;
    }
    static setSorting(query, sortings) {
        if (!sortings || !Array.isArray(sortings)) {
            return query;
        }
        if (sortings.findIndex(s => s.method == SortingMethods_1.SortByTypes.Random) !== -1 && sortings.length > 1) {
            throw new Error('Error during applying sorting: Can\' randomize and also sort the result. Bad input:' + sortings.map(s => SortingMethods_1.GroupSortByTypes[s.method]).join(', '));
        }
        for (const sort of sortings) {
            switch (sort.method) {
                case SortingMethods_1.SortByTypes.Date:
                    if (Config_1.Config.Gallery.ignoreTimestampOffset === true) {
                        query.addOrderBy('media.metadata.creationDate + (coalesce(media.metadata.creationDateOffset,0) * 60000)', sort.ascending ? 'ASC' : 'DESC');
                    }
                    else {
                        query.addOrderBy('media.metadata.creationDate', sort.ascending ? 'ASC' : 'DESC');
                    }
                    break;
                case SortingMethods_1.SortByTypes.Rating:
                    query.addOrderBy('media.metadata.rating', sort.ascending ? 'ASC' : 'DESC');
                    break;
                case SortingMethods_1.SortByTypes.Name:
                    query.addOrderBy('media.name', sort.ascending ? 'ASC' : 'DESC');
                    break;
                case SortingMethods_1.SortByTypes.PersonCount:
                    query.addOrderBy('media.metadata.personsLength', sort.ascending ? 'ASC' : 'DESC');
                    break;
                case SortingMethods_1.SortByTypes.FileSize:
                    query.addOrderBy('media.metadata.fileSize', sort.ascending ? 'ASC' : 'DESC');
                    break;
                case SortingMethods_1.SortByTypes.Random:
                    if (Config_1.Config.Database.type === PrivateConfig_1.DatabaseType.mysql) {
                        query.groupBy('RAND(), media.id');
                    }
                    else {
                        query.groupBy('RANDOM()');
                    }
                    break;
            }
        }
        return query;
    }
    static autoCompleteItemsUnique(array) {
        const a = array.concat();
        for (let i = 0; i < a.length; ++i) {
            for (let j = i + 1; j < a.length; ++j) {
                if (a[i].equals(a[j])) {
                    a.splice(j--, 1);
                }
            }
        }
        return a;
    }
    async autocomplete(session, text, type) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const photoRepository = connection.getRepository(PhotoEntity_1.PhotoEntity);
        const mediaRepository = connection.getRepository(MediaEntity_1.MediaEntity);
        const personRepository = connection.getRepository(PersonEntry_1.PersonEntry);
        const directoryRepository = connection.getRepository(DirectoryEntity_1.DirectoryEntity);
        const partialResult = [];
        if (type === SearchQueryDTO_1.SearchQueryTypes.any_text ||
            type === SearchQueryDTO_1.SearchQueryTypes.keyword) {
            const acList = [];
            const q = photoRepository
                .createQueryBuilder('media')
                .select('DISTINCT(media.metadata.keywords)')
                .where('media.metadata.keywords LIKE :textKW COLLATE ' + EntityUtils_1.SQL_COLLATE, {
                textKW: '%' + text + '%',
            });
            if (session.projectionQuery) {
                if (session.hasDirectoryProjection) {
                    q.leftJoin('media.directory', 'directory');
                }
                q.andWhere(session.projectionQuery);
            }
            q.limit(Config_1.Config.Search.AutoComplete.ItemsPerCategory.keyword);
            (await q.getRawMany())
                .map((r) => r.metadataKeywords.split(','))
                .forEach((keywords) => {
                acList.push(...this.encapsulateAutoComplete(keywords.filter((k) => k.toLowerCase().indexOf(text.toLowerCase()) !== -1), SearchQueryDTO_1.SearchQueryTypes.keyword));
            });
            partialResult.push(acList);
        }
        if (type === SearchQueryDTO_1.SearchQueryTypes.any_text ||
            type === SearchQueryDTO_1.SearchQueryTypes.person) {
            // make sure all persons have up-to-date cache
            await ObjectManagers_1.ObjectManagers.getInstance().PersonManager.getAll(session);
            partialResult.push(this.encapsulateAutoComplete((await personRepository
                .createQueryBuilder('person')
                .select('DISTINCT(person.name), cache.count')
                .leftJoin('person.cache', 'cache', 'cache.projectionKey = :pk', { pk: session.user.projectionKey })
                .where('person.name LIKE :text COLLATE ' + EntityUtils_1.SQL_COLLATE, {
                text: '%' + text + '%',
            })
                .andWhere('cache.count > 0 AND cache.valid = 1')
                .limit(Config_1.Config.Search.AutoComplete.ItemsPerCategory.person)
                .orderBy('cache.count', 'DESC')
                .getRawMany()).map((r) => r.name), SearchQueryDTO_1.SearchQueryTypes.person));
        }
        if (type === SearchQueryDTO_1.SearchQueryTypes.any_text ||
            type === SearchQueryDTO_1.SearchQueryTypes.position ||
            type === SearchQueryDTO_1.SearchQueryTypes.distance) {
            const acList = [];
            const q = photoRepository
                .createQueryBuilder('media')
                .select('media.metadata.positionData.country as country, ' +
                'media.metadata.positionData.state as state, media.metadata.positionData.city as city');
            const b = new typeorm_1.Brackets((q) => {
                q.where('media.metadata.positionData.country LIKE :text COLLATE ' +
                    EntityUtils_1.SQL_COLLATE, { text: '%' + text + '%' }).orWhere('media.metadata.positionData.state LIKE :text COLLATE ' +
                    EntityUtils_1.SQL_COLLATE, { text: '%' + text + '%' }).orWhere('media.metadata.positionData.city LIKE :text COLLATE ' +
                    EntityUtils_1.SQL_COLLATE, { text: '%' + text + '%' });
            });
            q.where(b);
            if (session.projectionQuery) {
                if (session.hasDirectoryProjection) {
                    q.leftJoin('media.directory', 'directory');
                }
                q.andWhere(session.projectionQuery);
            }
            q.groupBy('media.metadata.positionData.country, media.metadata.positionData.state, media.metadata.positionData.city')
                .limit(Config_1.Config.Search.AutoComplete.ItemsPerCategory.position);
            (await q.getRawMany())
                .filter((pm) => !!pm)
                .map((pm) => [pm.city || '', pm.country || '', pm.state || ''])
                .forEach((positions) => {
                acList.push(...this.encapsulateAutoComplete(positions.filter((p) => p.toLowerCase().indexOf(text.toLowerCase()) !== -1), type === SearchQueryDTO_1.SearchQueryTypes.distance
                    ? type
                    : SearchQueryDTO_1.SearchQueryTypes.position));
            });
            partialResult.push(acList);
        }
        if (type === SearchQueryDTO_1.SearchQueryTypes.any_text ||
            type === SearchQueryDTO_1.SearchQueryTypes.file_name) {
            const q = mediaRepository
                .createQueryBuilder('media')
                .select('DISTINCT(media.name)')
                .where('media.name LIKE :text COLLATE ' + EntityUtils_1.SQL_COLLATE, {
                text: '%' + text + '%',
            });
            if (session.projectionQuery) {
                if (session.hasDirectoryProjection) {
                    q.leftJoin('media.directory', 'directory');
                }
                q.andWhere(session.projectionQuery);
            }
            q.limit(Config_1.Config.Search.AutoComplete.ItemsPerCategory.fileName);
            partialResult.push(this.encapsulateAutoComplete((await q.getRawMany()).map((r) => r.name), SearchQueryDTO_1.SearchQueryTypes.file_name));
        }
        if (type === SearchQueryDTO_1.SearchQueryTypes.any_text ||
            type === SearchQueryDTO_1.SearchQueryTypes.caption) {
            const q = photoRepository
                .createQueryBuilder('media')
                .select('DISTINCT(media.metadata.caption) as caption')
                .where('media.metadata.caption LIKE :text COLLATE ' + EntityUtils_1.SQL_COLLATE, { text: '%' + text + '%' });
            if (session.projectionQuery) {
                if (session.hasDirectoryProjection) {
                    q.leftJoin('media.directory', 'directory');
                }
                q.andWhere(session.projectionQuery);
            }
            q.limit(Config_1.Config.Search.AutoComplete.ItemsPerCategory.caption);
            partialResult.push(this.encapsulateAutoComplete((await q.getRawMany()).map((r) => r.caption), SearchQueryDTO_1.SearchQueryTypes.caption));
        }
        if (type === SearchQueryDTO_1.SearchQueryTypes.any_text ||
            type === SearchQueryDTO_1.SearchQueryTypes.directory) {
            const dirs = await directoryRepository
                .createQueryBuilder('directory')
                .leftJoinAndSelect('directory.cache', 'cache', 'cache.projectionKey = :pk AND cache.valid = 1', { pk: session.user.projectionKey })
                .where('directory.name LIKE :text COLLATE ' + EntityUtils_1.SQL_COLLATE, {
                text: '%' + text + '%',
            })
                .andWhere('(cache.recursiveMediaCount > 0 OR cache.id is NULL)')
                .limit(Config_1.Config.Search.AutoComplete.ItemsPerCategory.directory)
                .getMany();
            // fill cache as we need it for this autocomplete search
            for (const dir of dirs) {
                if (!dir.cache?.valid) {
                    dir.cache = await ObjectManagers_1.ObjectManagers.getInstance().ProjectedCacheManager.setAndGetCacheForDirectory(connection, session, dir);
                }
            }
            partialResult.push(this.encapsulateAutoComplete(dirs.filter(d => d.cache.valid && d.cache.recursiveMediaCount > 0).map((r) => r.name), SearchQueryDTO_1.SearchQueryTypes.directory));
        }
        const result = [];
        while (result.length < Config_1.Config.Search.AutoComplete.ItemsPerCategory.maxItems) {
            let adding = false;
            for (let i = 0; i < partialResult.length; ++i) {
                if (partialResult[i].length <= 0) {
                    continue;
                }
                result.push(partialResult[i].shift()); // first elements are more important
                adding = true;
            }
            if (!adding) {
                break;
            }
        }
        return SearchManager.autoCompleteItemsUnique(result);
    }
    async search(session, queryIN) {
        const query = await this.prepareQuery(queryIN);
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const result = {
            searchQuery: queryIN,
            directories: [],
            media: [],
            metaFile: [],
            resultOverflow: false,
        };
        const q = connection
            .getRepository(MediaEntity_1.MediaEntity)
            .createQueryBuilder('media')
            .select(['media', ...this.DIRECTORY_SELECT])
            .where(this.buildWhereQuery(query))
            .leftJoin('media.directory', 'directory')
            .limit(Config_1.Config.Search.maxMediaResult + 1);
        if (session.projectionQuery) {
            q.andWhere(session.projectionQuery);
        }
        result.media = await q.getMany();
        if (result.media.length > Config_1.Config.Search.maxMediaResult) {
            result.resultOverflow = true;
        }
        if (Config_1.Config.Search.listMetafiles === true) {
            const dIds = Array.from(new Set(result.media.map(m => m.directory.id)));
            result.metaFile = await connection
                .getRepository(FileEntity_1.FileEntity)
                .createQueryBuilder('file')
                .select(['file', ...this.DIRECTORY_SELECT])
                .where(`file.directoryId IN(${dIds})`)
                .leftJoin('file.directory', 'directory')
                .getMany();
        }
        if (Config_1.Config.Search.listDirectories === true) {
            const dirQuery = this.filterDirectoryQuery(query);
            if (dirQuery !== null) {
                result.directories = await connection
                    .getRepository(DirectoryEntity_1.DirectoryEntity)
                    .createQueryBuilder('directory')
                    .where(this.buildWhereQuery(dirQuery, true))
                    .leftJoin('directory.cache', 'cache', 'cache.projectionKey = :pk AND cache.valid = 1', { pk: session.user.projectionKey })
                    .leftJoin('cache.cover', 'cover')
                    .leftJoin('cover.directory', 'coverDirectory')
                    .limit(Config_1.Config.Search.maxDirectoryResult + 1)
                    .select([
                    'directory',
                    'cache.valid',
                    'cache.oldestMedia',
                    'cache.youngestMedia',
                    'cache.mediaCount',
                    'cache.recursiveMediaCount',
                    'cover.name',
                    'coverDirectory.name',
                    'coverDirectory.path',
                ])
                    .getMany();
                // setting covers
                if (result.directories) {
                    for (const item of result.directories) {
                        await ObjectManagers_1.ObjectManagers.getInstance().GalleryManager.fillCacheForSubDir(connection, session, item);
                    }
                }
                // do not show empty directories in search results
                result.directories = result.directories.filter(d => d.cache.recursiveMediaCount > 0);
                if (result.directories.length > Config_1.Config.Search.maxDirectoryResult) {
                    result.resultOverflow = true;
                }
            }
        }
        return result;
    }
    async getNMedia(session, query, sortings, take, photoOnly = false) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const sqlQuery = connection
            .getRepository(photoOnly ? PhotoEntity_1.PhotoEntity : MediaEntity_1.MediaEntity)
            .createQueryBuilder('media')
            .select(['media', ...this.DIRECTORY_SELECT])
            .innerJoin('media.directory', 'directory')
            .where(await this.prepareAndBuildWhereQuery(query));
        if (session.projectionQuery) {
            sqlQuery.andWhere(session.projectionQuery);
        }
        SearchManager.setSorting(sqlQuery, sortings);
        return sqlQuery.limit(take).getMany();
    }
    async getCount(session, query) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const q = connection
            .getRepository(MediaEntity_1.MediaEntity)
            .createQueryBuilder('media')
            .innerJoin('media.directory', 'directory')
            .where(await this.prepareAndBuildWhereQuery(query));
        if (session.projectionQuery) {
            q.andWhere(session.projectionQuery);
        }
        return await q.getCount();
    }
    async prepareAndBuildWhereQuery(queryIN, directoryOnly = false, aliases = {}) {
        let query = await this.prepareQuery(queryIN);
        if (directoryOnly) {
            query = this.filterDirectoryQuery(query);
        }
        return this.buildWhereQuery(query, directoryOnly, aliases);
    }
    async prepareQuery(queryIN) {
        let query = this.assignQueryIDs(Utils_1.Utils.clone(queryIN)); // assign local ids before flattening SOME_OF queries
        query = this.flattenSameOfQueries(query);
        query = await this.getGPSData(query);
        return query;
    }
    /**
     * Builds the SQL Where query from search query
     * @param query input search query
     * @param directoryOnly Only builds directory related queries
     * @param aliases for SQL alias mapping
     * @private
     */
    buildWhereQuery(query, directoryOnly = false, aliases = {}) {
        const queryId = query.queryId;
        switch (query.type) {
            case SearchQueryDTO_1.SearchQueryTypes.AND:
                return new typeorm_1.Brackets((q) => {
                    query.list.forEach((sq) => {
                        q.andWhere(this.buildWhereQuery(sq, directoryOnly));
                    });
                    return q;
                });
            case SearchQueryDTO_1.SearchQueryTypes.OR:
                return new typeorm_1.Brackets((q) => {
                    query.list.forEach((sq) => {
                        q.orWhere(this.buildWhereQuery(sq, directoryOnly));
                    });
                    return q;
                });
            case SearchQueryDTO_1.SearchQueryTypes.distance:
                if (directoryOnly) {
                    throw new Error('not supported in directoryOnly mode');
                }
                /**
                 * This is a best effort calculation, not fully accurate in order to have higher performance.
                 * see: https://stackoverflow.com/a/50506609
                 */
                const earth = 6378.137; // radius of the earth in kilometer
                const latDelta = 1 / (((2 * Math.PI) / 360) * earth); // 1 km in degree
                const lonDelta = 1 / (((2 * Math.PI) / 360) * earth); // 1 km in degree
                // TODO: properly handle latitude / longitude boundaries
                const trimRange = (value, min, max) => {
                    return Math.min(Math.max(value, min), max);
                };
                const minLat = trimRange(query.from.GPSData.latitude -
                    query.distance * latDelta, -90, 90);
                const maxLat = trimRange(query.from.GPSData.latitude +
                    query.distance * latDelta, -90, 90);
                const minLon = trimRange(query.from.GPSData.longitude -
                    (query.distance * lonDelta) /
                        Math.cos(minLat * (Math.PI / 180)), -180, 180);
                const maxLon = trimRange(query.from.GPSData.longitude +
                    (query.distance * lonDelta) /
                        Math.cos(maxLat * (Math.PI / 180)), -180, 180);
                return new typeorm_1.Brackets((q) => {
                    const textParam = {};
                    textParam['maxLat' + queryId] = maxLat;
                    textParam['minLat' + queryId] = minLat;
                    textParam['maxLon' + queryId] = maxLon;
                    textParam['minLon' + queryId] = minLon;
                    if (!query.negate) {
                        q.where(`media.metadata.positionData.GPSData.latitude < :maxLat${queryId}`, textParam);
                        q.andWhere(`media.metadata.positionData.GPSData.latitude > :minLat${queryId}`, textParam);
                        q.andWhere(`media.metadata.positionData.GPSData.longitude < :maxLon${queryId}`, textParam);
                        q.andWhere(`media.metadata.positionData.GPSData.longitude > :minLon${queryId}`, textParam);
                    }
                    else {
                        q.where(`media.metadata.positionData.GPSData.latitude > :maxLat${queryId}`, textParam);
                        q.orWhere(`media.metadata.positionData.GPSData.latitude < :minLat${queryId}`, textParam);
                        q.orWhere(`media.metadata.positionData.GPSData.longitude > :maxLon${queryId}`, textParam);
                        q.orWhere(`media.metadata.positionData.GPSData.longitude < :minLon${queryId}`, textParam);
                    }
                    return q;
                });
            case SearchQueryDTO_1.SearchQueryTypes.from_date:
                if (directoryOnly) {
                    throw new Error('not supported in directoryOnly mode');
                }
                return new typeorm_1.Brackets((q) => {
                    if (typeof query.value === 'undefined') {
                        throw new Error('Invalid search query: Date Query should contain from value');
                    }
                    const relation = query.negate ? '<' : '>=';
                    const textParam = {};
                    textParam['from' + queryId] = query.value;
                    if (Config_1.Config.Gallery.ignoreTimestampOffset === true) {
                        q.where(`(media.metadata.creationDate + (coalesce(media.metadata.creationDateOffset,0) * 60000)) ${relation} :from${queryId}`, textParam);
                    }
                    else {
                        q.where(`media.metadata.creationDate ${relation} :from${queryId}`, textParam);
                    }
                    return q;
                });
            case SearchQueryDTO_1.SearchQueryTypes.to_date:
                if (directoryOnly) {
                    throw new Error('not supported in directoryOnly mode');
                }
                return new typeorm_1.Brackets((q) => {
                    if (typeof query.value === 'undefined') {
                        throw new Error('Invalid search query: Date Query should contain to value');
                    }
                    const relation = query.negate ? '>' : '<=';
                    const textParam = {};
                    textParam['to' + queryId] = query.value;
                    if (Config_1.Config.Gallery.ignoreTimestampOffset === true) {
                        q.where(`(media.metadata.creationDate + (coalesce(media.metadata.creationDateOffset,0) * 60000)) ${relation} :to${queryId}`, textParam);
                    }
                    else {
                        q.where(`media.metadata.creationDate ${relation} :to${queryId}`, textParam);
                    }
                    return q;
                });
            case SearchQueryDTO_1.SearchQueryTypes.min_rating:
                if (directoryOnly) {
                    throw new Error('not supported in directoryOnly mode');
                }
                return new typeorm_1.Brackets((q) => {
                    if (typeof query.value === 'undefined') {
                        throw new Error('Invalid search query: Rating Query should contain minvalue');
                    }
                    const relation = query.negate ? '<' : '>=';
                    const textParam = {};
                    textParam['min' + queryId] = query.value;
                    q.where(`media.metadata.rating ${relation}  :min${queryId}`, textParam);
                    return q;
                });
            case SearchQueryDTO_1.SearchQueryTypes.max_rating:
                if (directoryOnly) {
                    throw new Error('not supported in directoryOnly mode');
                }
                return new typeorm_1.Brackets((q) => {
                    if (typeof query.value === 'undefined') {
                        throw new Error('Invalid search query: Rating Query should contain  max value');
                    }
                    const relation = query.negate ? '>' : '<=';
                    if (typeof query.value !== 'undefined') {
                        const textParam = {};
                        textParam['max' + queryId] = query.value;
                        q.where(`media.metadata.rating ${relation}  :max${queryId}`, textParam);
                    }
                    return q;
                });
            case SearchQueryDTO_1.SearchQueryTypes.min_person_count:
                if (directoryOnly) {
                    throw new Error('not supported in directoryOnly mode');
                }
                return new typeorm_1.Brackets((q) => {
                    if (typeof query.value === 'undefined') {
                        throw new Error('Invalid search query: Person count Query should contain minvalue');
                    }
                    const relation = query.negate ? '<' : '>=';
                    const textParam = {};
                    textParam['min' + queryId] = query.value;
                    q.where(`media.metadata.personsLength ${relation}  :min${queryId}`, textParam);
                    return q;
                });
            case SearchQueryDTO_1.SearchQueryTypes.max_person_count:
                if (directoryOnly) {
                    throw new Error('not supported in directoryOnly mode');
                }
                return new typeorm_1.Brackets((q) => {
                    if (typeof query.value === 'undefined') {
                        throw new Error('Invalid search query: Person count Query should contain max value');
                    }
                    const relation = query.negate ? '>' : '<=';
                    if (typeof query.value !== 'undefined') {
                        const textParam = {};
                        textParam['max' + queryId] = query.value;
                        q.where(`media.metadata.personsLength ${relation}  :max${queryId}`, textParam);
                    }
                    return q;
                });
            case SearchQueryDTO_1.SearchQueryTypes.min_resolution:
                if (directoryOnly) {
                    throw new Error('not supported in directoryOnly mode');
                }
                return new typeorm_1.Brackets((q) => {
                    if (typeof query.value === 'undefined') {
                        throw new Error('Invalid search query: Resolution Query should contain min value');
                    }
                    const relation = query.negate ? '<' : '>=';
                    const textParam = {};
                    textParam['min' + queryId] =
                        query.value * 1000 * 1000;
                    q.where(`media.metadata.size.width * media.metadata.size.height ${relation} :min${queryId}`, textParam);
                    return q;
                });
            case SearchQueryDTO_1.SearchQueryTypes.max_resolution:
                if (directoryOnly) {
                    throw new Error('not supported in directoryOnly mode');
                }
                return new typeorm_1.Brackets((q) => {
                    if (typeof query.value === 'undefined') {
                        throw new Error('Invalid search query: Rating Query should contain min or max value');
                    }
                    const relation = query.negate ? '>' : '<=';
                    const textParam = {};
                    textParam['max' + queryId] =
                        query.value * 1000 * 1000;
                    q.where(`media.metadata.size.width * media.metadata.size.height ${relation} :max${queryId}`, textParam);
                    return q;
                });
            case SearchQueryDTO_1.SearchQueryTypes.orientation:
                if (directoryOnly) {
                    throw new Error('not supported in directoryOnly mode');
                }
                return new typeorm_1.Brackets((q) => {
                    if (query.landscape) {
                        q.where('media.metadata.size.width >= media.metadata.size.height');
                    }
                    else {
                        q.where('media.metadata.size.width <= media.metadata.size.height');
                    }
                    return q;
                });
            case SearchQueryDTO_1.SearchQueryTypes.date_pattern: {
                if (directoryOnly) {
                    throw new Error('not supported in directoryOnly mode');
                }
                const tq = query;
                return new typeorm_1.Brackets((q) => {
                    // Fixed frequency
                    if ((tq.frequency === SearchQueryDTO_1.DatePatternFrequency.years_ago ||
                        tq.frequency === SearchQueryDTO_1.DatePatternFrequency.months_ago ||
                        tq.frequency === SearchQueryDTO_1.DatePatternFrequency.weeks_ago ||
                        tq.frequency === SearchQueryDTO_1.DatePatternFrequency.days_ago)) {
                        if (isNaN(tq.agoNumber)) {
                            throw new Error('ago number is missing on date pattern search query with frequency: ' + SearchQueryDTO_1.DatePatternFrequency[tq.frequency] + ', ago number: ' + tq.agoNumber);
                        }
                        const to = new Date();
                        to.setHours(0, 0, 0, 0);
                        to.setUTCDate(to.getUTCDate() + 1);
                        switch (tq.frequency) {
                            case SearchQueryDTO_1.DatePatternFrequency.days_ago:
                                to.setUTCDate(to.getUTCDate() - tq.agoNumber);
                                break;
                            case SearchQueryDTO_1.DatePatternFrequency.weeks_ago:
                                to.setUTCDate(to.getUTCDate() - tq.agoNumber * 7);
                                break;
                            case SearchQueryDTO_1.DatePatternFrequency.months_ago:
                                to.setTime(Utils_1.Utils.addMonthToDate(to, -1 * tq.agoNumber).getTime());
                                break;
                            case SearchQueryDTO_1.DatePatternFrequency.years_ago:
                                to.setUTCFullYear(to.getUTCFullYear() - tq.agoNumber);
                                break;
                        }
                        const from = new Date(to);
                        from.setUTCDate(from.getUTCDate() - tq.daysLength);
                        const textParam = {};
                        textParam['to' + queryId] = to.getTime();
                        textParam['from' + queryId] = from.getTime();
                        if (tq.negate) {
                            if (Config_1.Config.Gallery.ignoreTimestampOffset === true) {
                                q.where(`(media.metadata.creationDate + (coalesce(media.metadata.creationDateOffset,0) * 60000)) >= :to${queryId}`, textParam).orWhere(`(media.metadata.creationDate + (coalesce(media.metadata.creationDateOffset,0) * 60000)) < :from${queryId}`, textParam);
                            }
                            else {
                                q.where(`media.metadata.creationDate >= :to${queryId}`, textParam).orWhere(`media.metadata.creationDate < :from${queryId}`, textParam);
                            }
                        }
                        else {
                            if (Config_1.Config.Gallery.ignoreTimestampOffset === true) {
                                q.where(`(media.metadata.creationDate + (coalesce(media.metadata.creationDateOffset,0) * 60000)) < :to${queryId}`, textParam).andWhere(`(media.metadata.creationDate + (coalesce(media.metadata.creationDateOffset,0) * 60000)) >= :from${queryId}`, textParam);
                            }
                            else {
                                q.where(`media.metadata.creationDate < :to${queryId}`, textParam).andWhere(`media.metadata.creationDate >= :from${queryId}`, textParam);
                            }
                        }
                    }
                    else {
                        // recurring
                        const textParam = {};
                        textParam['diff' + queryId] = tq.daysLength;
                        const addWhere = (duration, crossesDateBoundary) => {
                            const relationEql = tq.negate ? '!=' : '=';
                            // reminder: !(a&&b) = (!a || !b), that is what happening here if negate is true
                            const relationTop = tq.negate ? '>' : '<=';
                            const relationBottom = tq.negate ? '<=' : '>';
                            // this is an XoR. during date boundary crossing we swap boolean logic again
                            const whereFN = !!tq.negate !== crossesDateBoundary ? 'orWhere' : 'andWhere';
                            if (Config_1.Config.Database.type === PrivateConfig_1.DatabaseType.sqlite) {
                                if (tq.daysLength == 0) {
                                    if (Config_1.Config.Gallery.ignoreTimestampOffset === true) {
                                        q.where(`CAST(strftime('${duration}',(media.metadataCreationDate + (media.metadataCreationDateOffset * 60000))/1000, 'unixepoch') AS INTEGER) ${relationEql} CAST(strftime('${duration}','now') AS INTEGER)`);
                                    }
                                    else {
                                        q.where(`CAST(strftime('${duration}',media.metadataCreationDate/1000, 'unixepoch') AS INTEGER) ${relationEql} CAST(strftime('${duration}','now') AS INTEGER)`);
                                    }
                                }
                                else {
                                    if (Config_1.Config.Gallery.ignoreTimestampOffset === true) {
                                        q.where(`CAST(strftime('${duration}',(media.metadataCreationDate + (media.metadataCreationDateOffset * 60000))/1000, 'unixepoch') AS INTEGER) ${relationTop} CAST(strftime('${duration}','now') AS INTEGER)`)[whereFN](`CAST(strftime('${duration}',(media.metadataCreationDate + (media.metadataCreationDateOffset * 60000))/1000, 'unixepoch') AS INTEGER) ${relationBottom} CAST(strftime('${duration}','now','-:diff${queryId} day') AS INTEGER)`, textParam);
                                    }
                                    else {
                                        q.where(`CAST(strftime('${duration}',media.metadataCreationDate/1000, 'unixepoch') AS INTEGER) ${relationTop} CAST(strftime('${duration}','now') AS INTEGER)`)[whereFN](`CAST(strftime('${duration}',media.metadataCreationDate/1000, 'unixepoch') AS INTEGER) ${relationBottom} CAST(strftime('${duration}','now','-:diff${queryId} day') AS INTEGER)`, textParam);
                                    }
                                }
                            }
                            else {
                                if (tq.daysLength == 0) {
                                    if (Config_1.Config.Gallery.ignoreTimestampOffset === true) {
                                        q.where(`CAST(FROM_UNIXTIME((media.metadataCreationDate + (media.metadataCreationDateOffset * 60000))/1000, '${duration}') AS SIGNED) ${relationEql} CAST(DATE_FORMAT(CURDATE(),'${duration}') AS SIGNED)`);
                                    }
                                    else {
                                        q.where(`CAST(FROM_UNIXTIME(media.metadataCreationDate/1000, '${duration}') AS SIGNED) ${relationEql} CAST(DATE_FORMAT(CURDATE(),'${duration}') AS SIGNED)`);
                                    }
                                }
                                else {
                                    if (Config_1.Config.Gallery.ignoreTimestampOffset === true) {
                                        q.where(`CAST(FROM_UNIXTIME((media.metadataCreationDate + (media.metadataCreationDateOffset * 60000))/1000, '${duration}') AS SIGNED) ${relationTop} CAST(DATE_FORMAT(CURDATE(),'${duration}') AS SIGNED)`)[whereFN](`CAST(FROM_UNIXTIME((media.metadataCreationDate + (media.metadataCreationDateOffset * 60000))/1000, '${duration}') AS SIGNED) ${relationBottom} CAST(DATE_FORMAT((DATE_ADD(curdate(), INTERVAL -:diff${queryId} DAY)),'${duration}') AS SIGNED)`, textParam);
                                    }
                                    else {
                                        q.where(`CAST(FROM_UNIXTIME(media.metadataCreationDate/1000, '${duration}') AS SIGNED) ${relationTop} CAST(DATE_FORMAT(CURDATE(),'${duration}') AS SIGNED)`)[whereFN](`CAST(FROM_UNIXTIME(media.metadataCreationDate/1000, '${duration}') AS SIGNED) ${relationBottom} CAST(DATE_FORMAT((DATE_ADD(curdate(), INTERVAL -:diff${queryId} DAY)),'${duration}') AS SIGNED)`, textParam);
                                    }
                                }
                            }
                        };
                        switch (tq.frequency) {
                            case SearchQueryDTO_1.DatePatternFrequency.every_year:
                                const d = new Date();
                                if (tq.daysLength >= (Utils_1.Utils.isDateFromLeapYear(d) ? 366 : 365)) { // trivial result includes all photos
                                    if (tq.negate) {
                                        q.andWhere('FALSE');
                                    }
                                    return q;
                                }
                                const dayOfYear = Utils_1.Utils.getDayOfYear(d);
                                addWhere('%m%d', dayOfYear - tq.daysLength < 0);
                                break;
                            case SearchQueryDTO_1.DatePatternFrequency.every_month:
                                if (tq.daysLength >= 31) { // trivial result includes all photos
                                    if (tq.negate) {
                                        q.andWhere('FALSE');
                                    }
                                    return q;
                                }
                                addWhere('%d', (new Date()).getUTCDate() - tq.daysLength < 0);
                                break;
                            case SearchQueryDTO_1.DatePatternFrequency.every_week:
                                if (tq.daysLength >= 7) { // trivial result includes all photos
                                    if (tq.negate) {
                                        q.andWhere('FALSE');
                                    }
                                    return q;
                                }
                                addWhere('%w', (new Date()).getUTCDay() - tq.daysLength < 0);
                                break;
                        }
                    }
                    return q;
                });
            }
            case SearchQueryDTO_1.SearchQueryTypes.SOME_OF:
                throw new Error('Some of not supported');
        }
        return new typeorm_1.Brackets((q) => {
            const createMatchString = (str) => {
                if (query.matchType ===
                    SearchQueryDTO_1.TextSearchQueryMatchTypes.exact_match) {
                    return str;
                }
                // MySQL uses C escape syntax in strings, details:
                // https://stackoverflow.com/questions/14926386/how-to-search-for-slash-in-mysql-and-why-escaping-not-required-for-wher
                if (Config_1.Config.Database.type === PrivateConfig_1.DatabaseType.mysql) {
                    /// this reqExp replaces the "\\" to "\\\\\"
                    return '%' + str.replace(new RegExp('\\\\', 'g'), '\\\\') + '%';
                }
                return `%${str}%`;
            };
            const LIKE = query.negate ? 'NOT LIKE' : 'LIKE';
            // if the expression is negated, we use AND instead of OR as nowhere should that match
            const whereFN = query.negate ? 'andWhere' : 'orWhere';
            const whereFNRev = query.negate ? 'orWhere' : 'andWhere';
            const textParam = {};
            textParam['text' + queryId] = createMatchString(query.text);
            if (query.type === SearchQueryDTO_1.SearchQueryTypes.any_text ||
                query.type === SearchQueryDTO_1.SearchQueryTypes.directory) {
                const dirPathStr = query.text.replace(new RegExp('\\\\', 'g'), '/');
                const alias = aliases['directory'] ?? 'directory';
                textParam['fullPath' + queryId] = createMatchString(dirPathStr);
                q[whereFN](`${alias}.path ${LIKE} :fullPath${queryId} COLLATE ` + EntityUtils_1.SQL_COLLATE, textParam);
                const directoryPath = GalleryManager_1.GalleryManager.parseRelativeDirPath(dirPathStr);
                q[whereFN](new typeorm_1.Brackets((dq) => {
                    textParam['dirName' + queryId] = createMatchString(directoryPath.name);
                    dq[whereFNRev](`${alias}.name ${LIKE} :dirName${queryId} COLLATE ${EntityUtils_1.SQL_COLLATE}`, textParam);
                    if (dirPathStr.includes('/')) {
                        textParam['parentName' + queryId] = createMatchString(directoryPath.parent);
                        dq[whereFNRev](`${alias}.path ${LIKE} :parentName${queryId} COLLATE ${EntityUtils_1.SQL_COLLATE}`, textParam);
                    }
                    return dq;
                }));
            }
            if ((query.type === SearchQueryDTO_1.SearchQueryTypes.any_text && !directoryOnly) ||
                query.type === SearchQueryDTO_1.SearchQueryTypes.file_name) {
                q[whereFN](`media.name ${LIKE} :text${queryId} COLLATE ${EntityUtils_1.SQL_COLLATE}`, textParam);
            }
            if ((query.type === SearchQueryDTO_1.SearchQueryTypes.any_text && !directoryOnly) ||
                query.type === SearchQueryDTO_1.SearchQueryTypes.caption) {
                q[whereFN](`media.metadata.caption ${LIKE} :text${queryId} COLLATE ${EntityUtils_1.SQL_COLLATE}`, textParam);
            }
            if ((query.type === SearchQueryDTO_1.SearchQueryTypes.any_text && !directoryOnly) ||
                query.type === SearchQueryDTO_1.SearchQueryTypes.position) {
                q[whereFN](`media.metadata.positionData.country ${LIKE} :text${queryId} COLLATE ${EntityUtils_1.SQL_COLLATE}`, textParam)[whereFN](`media.metadata.positionData.state ${LIKE} :text${queryId} COLLATE ${EntityUtils_1.SQL_COLLATE}`, textParam)[whereFN](`media.metadata.positionData.city ${LIKE} :text${queryId} COLLATE ${EntityUtils_1.SQL_COLLATE}`, textParam);
            }
            // Matching for array type fields
            const matchArrayField = (fieldName) => {
                q[whereFN](new typeorm_1.Brackets((qbr) => {
                    if (query.matchType !==
                        SearchQueryDTO_1.TextSearchQueryMatchTypes.exact_match) {
                        qbr[whereFN](`${fieldName} ${LIKE} :text${queryId} COLLATE ${EntityUtils_1.SQL_COLLATE}`, textParam);
                    }
                    else {
                        qbr[whereFN](new typeorm_1.Brackets((qb) => {
                            textParam['CtextC' + queryId] = `%,${query.text},%`;
                            textParam['Ctext' + queryId] = `%,${query.text}`;
                            textParam['textC' + queryId] = `${query.text},%`;
                            textParam['text_exact' + queryId] = `${query.text}`;
                            qb[whereFN](`${fieldName} ${LIKE} :CtextC${queryId} COLLATE ${EntityUtils_1.SQL_COLLATE}`, textParam);
                            qb[whereFN](`${fieldName} ${LIKE} :Ctext${queryId} COLLATE ${EntityUtils_1.SQL_COLLATE}`, textParam);
                            qb[whereFN](`${fieldName} ${LIKE} :textC${queryId} COLLATE ${EntityUtils_1.SQL_COLLATE}`, textParam);
                            qb[whereFN](`${fieldName} ${LIKE} :text_exact${queryId} COLLATE ${EntityUtils_1.SQL_COLLATE}`, textParam);
                        }));
                    }
                    if (query.negate) {
                        qbr.orWhere(`${fieldName} IS NULL`);
                    }
                }));
            };
            if ((query.type === SearchQueryDTO_1.SearchQueryTypes.any_text && !directoryOnly) ||
                query.type === SearchQueryDTO_1.SearchQueryTypes.person) {
                matchArrayField('media.metadata.persons');
            }
            if ((query.type === SearchQueryDTO_1.SearchQueryTypes.any_text && !directoryOnly) ||
                query.type === SearchQueryDTO_1.SearchQueryTypes.keyword) {
                matchArrayField('media.metadata.keywords');
            }
            return q;
        });
    }
    hasDirectoryQuery(query) {
        switch (query.type) {
            case SearchQueryDTO_1.SearchQueryTypes.AND:
            case SearchQueryDTO_1.SearchQueryTypes.OR:
            case SearchQueryDTO_1.SearchQueryTypes.SOME_OF:
                return query.list.some(q => this.hasDirectoryQuery(q));
            case SearchQueryDTO_1.SearchQueryTypes.any_text:
            case SearchQueryDTO_1.SearchQueryTypes.directory:
                return true;
        }
        return false;
    }
    flattenSameOfQueries(query) {
        switch (query.type) {
            case SearchQueryDTO_1.SearchQueryTypes.AND:
            case SearchQueryDTO_1.SearchQueryTypes.OR:
                return {
                    type: query.type,
                    list: (query.list || []).map((q) => this.flattenSameOfQueries(q)),
                };
            case SearchQueryDTO_1.SearchQueryTypes.SOME_OF:
                const someOfQ = query;
                someOfQ.min = someOfQ.min || 1;
                if (someOfQ.min === 1) {
                    return this.flattenSameOfQueries({
                        type: SearchQueryDTO_1.SearchQueryTypes.OR,
                        list: someOfQ.list,
                    });
                }
                if (someOfQ.min === (query.list || []).length) {
                    return this.flattenSameOfQueries({
                        type: SearchQueryDTO_1.SearchQueryTypes.AND,
                        list: someOfQ.list,
                    });
                }
                const getAllCombinations = (num, arr, start = 0) => {
                    if (num <= 0 || num > arr.length || start >= arr.length) {
                        return null;
                    }
                    if (num <= 1) {
                        return arr.slice(start);
                    }
                    if (num === arr.length - start) {
                        return [
                            {
                                type: SearchQueryDTO_1.SearchQueryTypes.AND,
                                list: arr.slice(start),
                            },
                        ];
                    }
                    const ret = [];
                    for (let i = start; i < arr.length; ++i) {
                        const subRes = getAllCombinations(num - 1, arr, i + 1);
                        if (subRes === null) {
                            break;
                        }
                        const and = {
                            type: SearchQueryDTO_1.SearchQueryTypes.AND,
                            list: [arr[i]],
                        };
                        if (subRes.length === 1) {
                            if (subRes[0].type === SearchQueryDTO_1.SearchQueryTypes.AND) {
                                and.list.push(...subRes[0].list);
                            }
                            else {
                                and.list.push(subRes[0]);
                            }
                        }
                        else {
                            and.list.push({
                                type: SearchQueryDTO_1.SearchQueryTypes.OR,
                                list: subRes,
                            });
                        }
                        ret.push(and);
                    }
                    if (ret.length === 0) {
                        return null;
                    }
                    return ret;
                };
                return this.flattenSameOfQueries({
                    type: SearchQueryDTO_1.SearchQueryTypes.OR,
                    list: getAllCombinations(someOfQ.min, query.list),
                });
        }
        return query;
    }
    /**
     * Assigning IDs to search queries. It is a help / simplification to typeorm,
     * so less parameters are needed to pass down to SQL.
     * Witch SOME_OF query the number of WHERE constrains have O(N!) complexity
     */
    assignQueryIDs(queryIN, id = { value: 1 }) {
        // It is possible that one SQL query contains multiple searchQueries
        // (like: where (<searchQuery1> AND (<searchQuery2>))
        // lets make params unique across multiple queries
        if (id.value === 1) {
            this.queryIdBase++;
            if (this.queryIdBase > 10000) {
                this.queryIdBase = 0;
            }
        }
        if (queryIN.list) {
            queryIN.list.forEach((q) => this.assignQueryIDs(q, id));
            return queryIN;
        }
        queryIN.queryId =
            this.queryIdBase + '_' + id.value;
        id.value++;
        return queryIN;
    }
    /**
     * Returns only those parts of a query tree that only contains directory-related search queries
     */
    filterDirectoryQuery(query) {
        switch (query.type) {
            case SearchQueryDTO_1.SearchQueryTypes.AND:
                const andRet = {
                    type: SearchQueryDTO_1.SearchQueryTypes.AND,
                    list: query.list.map((q) => this.filterDirectoryQuery(q)),
                };
                // if any of the queries contain non dir query thw whole and query is a non dir query
                if (andRet.list.indexOf(null) !== -1) {
                    return null;
                }
                return andRet;
            case SearchQueryDTO_1.SearchQueryTypes.OR:
                const orRet = {
                    type: SearchQueryDTO_1.SearchQueryTypes.OR,
                    list: query.list
                        .map((q) => this.filterDirectoryQuery(q))
                        .filter((q) => q !== null),
                };
                if (orRet.list.length === 0) {
                    return null;
                }
                return orRet;
            case SearchQueryDTO_1.SearchQueryTypes.any_text:
            case SearchQueryDTO_1.SearchQueryTypes.directory:
                return query;
            case SearchQueryDTO_1.SearchQueryTypes.SOME_OF:
                throw new Error('"Some of" queries should have been already flattened');
        }
        // of none of the above, its not a directory search
        return null;
    }
    async getGPSData(query) {
        if (query.list) {
            for (let i = 0; i < query.list.length; ++i) {
                query.list[i] =
                    await this.getGPSData(query.list[i]);
            }
        }
        if (query.type === SearchQueryDTO_1.SearchQueryTypes.distance &&
            query.from.text) {
            query.from.GPSData =
                await ObjectManagers_1.ObjectManagers.getInstance().LocationManager.getGPSData(query.from.text);
        }
        return query;
    }
    encapsulateAutoComplete(values, type) {
        const res = [];
        values.forEach((value) => {
            res.push(new AutoCompleteItem_1.AutoCompleteItem(value, type));
        });
        return res;
    }
}
exports.SearchManager = SearchManager;

//# sourceMappingURL=SearchManager.js.map
