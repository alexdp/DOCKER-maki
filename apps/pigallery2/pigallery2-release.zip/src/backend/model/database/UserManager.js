"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserManager = void 0;
const UserDTO_1 = require("../../../common/entities/UserDTO");
const UserEntity_1 = require("./enitites/UserEntity");
const SQLConnection_1 = require("./SQLConnection");
const PasswordHelper_1 = require("../PasswordHelper");
const SearchQueryUtils_1 = require("../../../common/SearchQueryUtils");
const Config_1 = require("../../../common/config/private/Config");
class UserManager {
    async findOne(filter) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const pass = filter.password;
        delete filter.password;
        const user = await connection.getRepository(UserEntity_1.UserEntity).findOneBy(filter);
        if (pass && !PasswordHelper_1.PasswordHelper.comparePassword(pass, user.password)) {
            throw new Error('No entry found');
        }
        return user;
    }
    async find(filter) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        return await connection.getRepository(UserEntity_1.UserEntity).findBy(filter);
    }
    async createUser(user) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        // Validate search queries if provided
        if (user.allowQuery) {
            SearchQueryUtils_1.SearchQueryUtils.validateSearchQuery(user.allowQuery, 'User allowQuery');
        }
        if (user.blockQuery) {
            SearchQueryUtils_1.SearchQueryUtils.validateSearchQuery(user.blockQuery, 'User blockQuery');
        }
        user.password = PasswordHelper_1.PasswordHelper.cryptPassword(user.password);
        return connection.getRepository(UserEntity_1.UserEntity).save(user);
    }
    async deleteUser(id) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const user = await connection.getRepository(UserEntity_1.UserEntity).findOneBy({ id });
        return await connection.getRepository(UserEntity_1.UserEntity).remove(user);
    }
    async changeRole(id, newRole) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const userRepository = connection.getRepository(UserEntity_1.UserEntity);
        const user = await userRepository.findOneBy({ id });
        user.role = newRole;
        return userRepository.save(user);
    }
    async updateSettings(id, settings) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const userRepository = connection.getRepository(UserEntity_1.UserEntity);
        const user = await userRepository.findOneBy({ id });
        if (!user) {
            throw new Error('User not found');
        }
        if (typeof settings.overrideAllowBlockList !== 'undefined') {
            user.overrideAllowBlockList = settings.overrideAllowBlockList;
        }
        if (typeof settings.allowQuery !== 'undefined') {
            if (settings.allowQuery) {
                SearchQueryUtils_1.SearchQueryUtils.validateSearchQuery(settings.allowQuery, 'User allowQuery');
            }
            user.allowQuery = settings.allowQuery ?? null;
        }
        if (typeof settings.blockQuery !== 'undefined') {
            if (settings.blockQuery) {
                SearchQueryUtils_1.SearchQueryUtils.validateSearchQuery(settings.blockQuery, 'User blockQuery');
            }
            user.blockQuery = settings.blockQuery ?? null;
        }
        if (settings.newPassword && settings.newPassword.length > 0) {
            user.password = PasswordHelper_1.PasswordHelper.cryptPassword(settings.newPassword);
        }
        return userRepository.save(user);
    }
    getUnAuthenticatedUser() {
        return {
            name: UserDTO_1.UserRoles[Config_1.Config.Users.unAuthenticatedUserRole],
            role: Config_1.Config.Users.unAuthenticatedUserRole,
        };
    }
}
exports.UserManager = UserManager;

//# sourceMappingURL=UserManager.js.map
