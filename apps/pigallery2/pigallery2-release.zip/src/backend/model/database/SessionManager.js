"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionManager = void 0;
const crypto = require("crypto");
const SessionContext_1 = require("../SessionContext");
const SearchQueryUtils_1 = require("../../../common/SearchQueryUtils");
const Config_1 = require("../../../common/config/private/Config");
const SearchQueryDTO_1 = require("../../../common/entities/SearchQueryDTO");
const ObjectManagers_1 = require("../ObjectManagers");
const Logger_1 = require("../../Logger");
const LOG_TAG = '[SessionManager]';
class SessionManager {
    static { this.NO_PROJECTION_KEY = crypto.createHash('md5').update('No Key').digest('hex'); }
    getQueryForUser(user) {
        let blockQuery = user.overrideAllowBlockList ? user.blockQuery : Config_1.Config.Users.blockQuery;
        const allowQuery = user.overrideAllowBlockList ? user.allowQuery : Config_1.Config.Users.allowQuery;
        if (SearchQueryUtils_1.SearchQueryUtils.isQueryEmpty(allowQuery) && SearchQueryUtils_1.SearchQueryUtils.isQueryEmpty(blockQuery)) {
            return null;
        }
        if (!SearchQueryUtils_1.SearchQueryUtils.isQueryEmpty(blockQuery)) {
            blockQuery = SearchQueryUtils_1.SearchQueryUtils.negate(blockQuery);
        }
        let query = !SearchQueryUtils_1.SearchQueryUtils.isQueryEmpty(allowQuery) ? allowQuery : blockQuery;
        if (!SearchQueryUtils_1.SearchQueryUtils.isQueryEmpty(allowQuery) && !SearchQueryUtils_1.SearchQueryUtils.isQueryEmpty(blockQuery)) {
            query = {
                type: SearchQueryDTO_1.SearchQueryTypes.AND,
                list: [
                    allowQuery,
                    blockQuery
                ]
            };
        }
        return query;
    }
    buildAllowListForSharing(sharing) {
        const creatorQuery = this.getQueryForUser(sharing.creator);
        let finalQuery = sharing.searchQuery;
        if (creatorQuery) {
            finalQuery = {
                type: SearchQueryDTO_1.SearchQueryTypes.AND,
                list: [
                    creatorQuery,
                    sharing.searchQuery
                ]
            };
        }
        return finalQuery;
    }
    createProjectionKey(q) {
        const canonical = SearchQueryUtils_1.SearchQueryUtils.stringifyForComparison(q);
        return crypto.createHash('md5').update(canonical).digest('hex');
    }
    async buildContext(user) {
        const context = new SessionContext_1.SessionContext();
        context.user = user;
        context.user.projectionKey = SessionManager.NO_PROJECTION_KEY;
        let finalQuery = this.getQueryForUser(user);
        if (finalQuery) {
            // Build the Brackets-based query
            context.projectionQuery = await ObjectManagers_1.ObjectManagers.getInstance().SearchManager.prepareAndBuildWhereQuery(finalQuery);
            context.hasDirectoryProjection = ObjectManagers_1.ObjectManagers.getInstance().SearchManager.hasDirectoryQuery(finalQuery);
            if (context.hasDirectoryProjection) {
                context.projectionQueryForSubDir = await ObjectManagers_1.ObjectManagers.getInstance().SearchManager.prepareAndBuildWhereQuery(finalQuery, true, { directory: 'directories' });
            }
            context.user.projectionKey = this.createProjectionKey(finalQuery);
            if (SearchQueryUtils_1.SearchQueryUtils.isQueryEmpty(finalQuery)) {
                Logger_1.Logger.silly(LOG_TAG, 'Empty Projection query.');
            }
            else {
                Logger_1.Logger.silly(LOG_TAG, 'Projection query: ' + JSON.stringify(finalQuery));
            }
        }
        return context;
    }
    async getAvailableUserSessions() {
        // If authentication is not required, expose the unauthenticated session only
        if (Config_1.Config.Users.authenticationRequired === false) {
            const user = ObjectManagers_1.ObjectManagers.getInstance().UserManager.getUnAuthenticatedUser();
            const ctx = await this.buildContext(user);
            return [ctx];
        }
        // List all users and build a session context for each
        const users = await ObjectManagers_1.ObjectManagers.getInstance().UserManager.find({});
        const sessions = [];
        for (const u of users) {
            try {
                const ctx = await this.buildContext(u);
                sessions.push(ctx);
            }
            catch (e) {
                // Log and continue on individual user context build failure to ensure we return other sessions
                Logger_1.Logger.warn(LOG_TAG, 'Failed to build session context for user id=' + u?.id + ': ' + e?.message);
            }
        }
        return sessions;
    }
}
exports.SessionManager = SessionManager;

//# sourceMappingURL=SessionManager.js.map
