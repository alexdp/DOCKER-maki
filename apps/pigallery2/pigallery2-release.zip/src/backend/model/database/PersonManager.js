"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PersonManager = void 0;
const SQLConnection_1 = require("./SQLConnection");
const PersonEntry_1 = require("./enitites/person/PersonEntry");
const Logger_1 = require("../../Logger");
const EntityUtils_1 = require("./enitites/EntityUtils");
const PersonJunctionTable_1 = require("./enitites/person/PersonJunctionTable");
const ProjectedPersonCacheEntity_1 = require("./enitites/person/ProjectedPersonCacheEntity");
const ProjectionAwareManager_1 = require("./ProjectionAwareManager");
const LOG_TAG = '[PersonManager]';
class PersonManager extends ProjectionAwareManager_1.ProjectionAwareManager {
    async updatePerson(name, partialPerson) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const repository = connection.getRepository(PersonEntry_1.PersonEntry);
        const person = await repository
            .createQueryBuilder('person')
            .limit(1)
            .where('person.name LIKE :name COLLATE ' + EntityUtils_1.SQL_COLLATE, { name })
            .getOne();
        if (typeof partialPerson.name !== 'undefined') {
            person.name = partialPerson.name;
        }
        if (typeof partialPerson.isFavourite !== 'undefined') {
            person.isFavourite = partialPerson.isFavourite;
        }
        await repository.save(person);
        // reset memory cache after person update. DB cache entry did not change, no need to reset that
        this.resetMemoryCache();
        return person;
    }
    /**
     * Used for statistic
     */
    async countFaces() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        return await connection
            .getRepository(PersonJunctionTable_1.PersonJunctionTable)
            .createQueryBuilder('personJunction')
            .getCount();
    }
    async get(session, name) {
        const persons = await this.getAll(session);
        return persons.find((p) => p.name === name);
    }
    async saveAll(persons) {
        const toSave = [];
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const personRepository = connection.getRepository(PersonEntry_1.PersonEntry);
        const personJunction = connection.getRepository(PersonJunctionTable_1.PersonJunctionTable);
        const savedPersons = await personRepository.find();
        // filter already existing persons
        for (const personToSave of persons) {
            const person = savedPersons.find((p) => p.name === personToSave.name);
            if (!person) {
                toSave.push(personToSave);
            }
        }
        if (toSave.length > 0) {
            for (let i = 0; i < toSave.length / 200; i++) {
                const saving = toSave.slice(i * 200, (i + 1) * 200);
                // saving person
                const inserted = await personRepository.insert(saving.map((p) => ({ name: p.name })));
                // saving junction table
                const junctionTable = inserted.identifiers.map((idObj, j) => ({ person: idObj, media: { id: saving[j].mediaId } }));
                await personJunction.insert(junctionTable);
            }
        }
    }
    async invalidateDBCache(changedDir) {
        if (!changedDir || !changedDir.id) {
            await this.invalidateAllDBCache();
            return;
        }
        try {
            const connection = await SQLConnection_1.SQLConnection.getConnection();
            // Collect affected person ids from this directory (non-recursive)
            const rows = await connection.getRepository(PersonJunctionTable_1.PersonJunctionTable)
                .createQueryBuilder('pjt')
                .innerJoin('pjt.media', 'm')
                .innerJoin('m.directory', 'd')
                .innerJoin('pjt.person', 'person')
                .where('d.id = :dirId', { dirId: changedDir.id })
                .select('DISTINCT person.id', 'pid')
                .getRawMany();
            const pids = rows.map((r) => parseInt(r.pid, 10)).filter((n) => !isNaN(n));
            if (pids.length === 0) {
                return;
            }
            // Mark projection-aware person cache entries invalid for these persons
            await connection.getRepository(ProjectedPersonCacheEntity_1.ProjectedPersonCacheEntity)
                .createQueryBuilder()
                .update()
                .set({ valid: false })
                .where('personId IN (:...pids)', { pids })
                .execute();
        }
        catch (err) {
            Logger_1.Logger.warn(LOG_TAG, 'Failed to invalidate projected person cache on data change', err);
        }
    }
    async loadEntities(session) {
        await this.updateCacheForAll(session);
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const personRepository = connection.getRepository(PersonEntry_1.PersonEntry);
        return await personRepository
            .createQueryBuilder('person')
            .leftJoin('person.cache', 'cache', 'cache.projectionKey = :pk', { pk: session.user.projectionKey })
            .leftJoin('cache.sampleRegion', 'sampleRegion')
            .leftJoin('sampleRegion.media', 'media')
            .leftJoin('media.directory', 'directory')
            .select([
            'person.id',
            'person.name',
            'person.isFavourite',
            'cache.count',
            'sampleRegion',
            'media',
            'directory.path',
            'directory.name'
        ])
            .where('cache.valid = 1 AND cache.count > 0')
            .getMany();
    }
    async invalidateAllDBCache() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        await connection.getRepository(ProjectedPersonCacheEntity_1.ProjectedPersonCacheEntity)
            .createQueryBuilder()
            .update()
            .set({ valid: false })
            .execute();
    }
    async updateCacheForAll(session) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const projectionKey = session.user.projectionKey;
        // Get all persons that need cache updates (either missing or invalid)
        const personsNeedingUpdate = await connection
            .getRepository(PersonEntry_1.PersonEntry)
            .createQueryBuilder('person')
            .leftJoin('person.cache', 'cache', 'cache.projectionKey = :projectionKey', { projectionKey })
            .where('cache.id IS NULL OR cache.valid = false')
            .select(['person.id'])
            .getMany();
        if (personsNeedingUpdate.length === 0) {
            return;
        }
        // Process persons in batches to avoid memory issues
        const batchSize = 200;
        for (let i = 0; i < personsNeedingUpdate.length; i += batchSize) {
            const batch = personsNeedingUpdate.slice(i, i + batchSize);
            const personIds = batch.map(p => p.id);
            // Build base query for person junction table with projection constraints
            const baseQb = connection
                .getRepository(PersonJunctionTable_1.PersonJunctionTable)
                .createQueryBuilder('pjt')
                .innerJoin('pjt.media', 'media')
                .where('pjt.person IN (:...personIds)', { personIds });
            // Apply projection query if it exists
            if (session.projectionQuery) {
                if (session.hasDirectoryProjection) {
                    baseQb.leftJoin('media.directory', 'directory');
                }
                baseQb.andWhere(session.projectionQuery);
            }
            // Compute counts per person
            const countResults = await baseQb
                .clone()
                .select(['pjt.person as personId', 'COUNT(*) as count'])
                .groupBy('pjt.person')
                .getRawMany();
            // Compute sample regions per person (best rated/newest photo)
            // Use individual queries per person to ensure compatibility with older SQLite versions
            const topSamples = {};
            for (const personId of personIds) {
                const sampleQb = connection
                    .getRepository(PersonJunctionTable_1.PersonJunctionTable)
                    .createQueryBuilder('pjt')
                    .innerJoin('pjt.media', 'media')
                    .where('pjt.person = :personId', { personId });
                // Apply projection query if it exists
                if (session.projectionQuery) {
                    if (session.hasDirectoryProjection) {
                        sampleQb.leftJoin('media.directory', 'directory');
                    }
                    sampleQb.andWhere(session.projectionQuery);
                }
                const sampleResult = await sampleQb
                    .select('pjt.id')
                    .orderBy('media.metadataRating', 'DESC')
                    .addOrderBy('media.metadataCreationdate', 'DESC')
                    .limit(1)
                    .getOne();
                if (sampleResult) {
                    topSamples[personId] = sampleResult.id;
                }
            }
            // Build count lookup
            const counts = countResults.reduce((acc, r) => {
                acc[parseInt(r.personId, 10)] = parseInt(r.count, 10);
                return acc;
            }, {});
            // Batch upsert cache entries to minimize DB transactions
            const cacheRepo = connection.getRepository(ProjectedPersonCacheEntity_1.ProjectedPersonCacheEntity);
            const cacheEntriesToSave = [];
            // Get existing cache entries for this batch
            const existingEntries = await cacheRepo
                .createQueryBuilder('cache')
                .leftJoinAndSelect('cache.person', 'person')
                .where('cache.projectionKey = :projectionKey', { projectionKey })
                .andWhere('cache.person IN (:...personIds)', { personIds })
                .getMany();
            const existingByPersonId = existingEntries.reduce((acc, entry) => {
                acc[entry.person.id] = entry;
                return acc;
            }, {});
            for (const person of batch) {
                const count = counts[person.id] || 0;
                const sampleRegionId = topSamples[person.id] || null;
                let cacheEntry = existingByPersonId[person.id];
                if (cacheEntry) {
                    // Update existing entry
                    cacheEntry.count = count;
                    cacheEntry.sampleRegion = sampleRegionId ? { id: sampleRegionId } : null;
                    cacheEntry.valid = true;
                }
                else {
                    // Create new entry
                    cacheEntry = new ProjectedPersonCacheEntity_1.ProjectedPersonCacheEntity();
                    cacheEntry.projectionKey = projectionKey;
                    cacheEntry.person = { id: person.id };
                    cacheEntry.count = count;
                    cacheEntry.sampleRegion = sampleRegionId ? { id: sampleRegionId } : null;
                    cacheEntry.valid = true;
                }
                cacheEntriesToSave.push(cacheEntry);
            }
            // Batch save all cache entries for this batch
            if (cacheEntriesToSave.length > 0) {
                await cacheRepo.save(cacheEntriesToSave);
            }
        }
    }
}
exports.PersonManager = PersonManager;

//# sourceMappingURL=PersonManager.js.map
