"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumManager = void 0;
const SQLConnection_1 = require("./SQLConnection");
const AlbumBaseEntity_1 = require("./enitites/album/AlbumBaseEntity");
const ObjectManagers_1 = require("../ObjectManagers");
const SavedSearchEntity_1 = require("./enitites/album/SavedSearchEntity");
const Logger_1 = require("../../Logger");
const ProjectedAlbumCacheEntity_1 = require("./enitites/album/ProjectedAlbumCacheEntity");
const ProjectionAwareManager_1 = require("./ProjectionAwareManager");
const LOG_TAG = '[AlbumManager]';
class AlbumManager extends ProjectionAwareManager_1.ProjectionAwareManager {
    async addIfNotExistSavedSearch(name, searchQuery, lockedAlbum) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const album = await connection
            .getRepository(SavedSearchEntity_1.SavedSearchEntity)
            .findOneBy({ name, searchQuery });
        if (album) {
            return;
        }
        await this.addSavedSearch(name, searchQuery, lockedAlbum);
    }
    async addSavedSearch(name, searchQuery, lockedAlbum) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        await connection
            .getRepository(SavedSearchEntity_1.SavedSearchEntity)
            .save({ name, searchQuery, locked: lockedAlbum });
    }
    async deleteAlbum(id) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        if ((await connection
            .getRepository(AlbumBaseEntity_1.AlbumBaseEntity)
            .countBy({ id, locked: false })) !== 1) {
            throw new Error('Could not delete album, id:' + id);
        }
        await connection
            .getRepository(AlbumBaseEntity_1.AlbumBaseEntity)
            .delete({ id, locked: false });
    }
    async loadEntities(session) {
        Logger_1.Logger.debug(LOG_TAG, 'loadEntities called for projection key:', session.user.projectionKey);
        await this.updateAlbums(session);
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        // Return albums with projected cache data
        const result = await connection
            .getRepository(AlbumBaseEntity_1.AlbumBaseEntity)
            .createQueryBuilder('album')
            .leftJoin('album.cache', 'cache', 'cache.projectionKey = :pk AND cache.valid = 1', { pk: session.user.projectionKey })
            .leftJoin('cache.cover', 'cover')
            .leftJoin('cover.directory', 'directory')
            .select(['album', 'cache', 'cover.name', 'directory.name', 'directory.path'])
            .getMany();
        Logger_1.Logger.debug(LOG_TAG, 'loadEntities returning', result.length, 'albums');
        return result;
    }
    async invalidateDBCache() {
        // Invalidate all album cache entries
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        await connection.getRepository(ProjectedAlbumCacheEntity_1.ProjectedAlbumCacheEntity)
            .createQueryBuilder()
            .update()
            .set({ valid: false })
            .execute();
    }
    async deleteAll() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        await connection
            .getRepository(AlbumBaseEntity_1.AlbumBaseEntity)
            .createQueryBuilder('album')
            .delete()
            .execute();
    }
    async updateAlbums(session) {
        Logger_1.Logger.debug(LOG_TAG, 'Updating derived album data');
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const albums = await connection
            .getRepository(SavedSearchEntity_1.SavedSearchEntity)
            .createQueryBuilder('album')
            .leftJoinAndSelect('album.cache', 'cache', 'cache.projectionKey = :pk AND cache.valid = 1', { pk: session.user.projectionKey })
            .getMany();
        for (const a of albums) {
            if (a.cache?.valid === true) {
                continue;
            }
            await ObjectManagers_1.ObjectManagers.getInstance().ProjectedCacheManager
                .setAndGetCacheForAlbum(connection, session, {
                id: a.id,
                searchQuery: a.searchQuery
            });
            // giving back the control to the main event loop (Macrotask queue)
            // https://blog.insiderattack.net/promises-next-ticks-and-immediates-nodejs-event-loop-part-3-9226cbe7a6aa
            await new Promise(setImmediate);
        }
    }
}
exports.AlbumManager = AlbumManager;

//# sourceMappingURL=AlbumManager.js.map
