"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ObjectManagers = void 0;
/* eslint-disable @typescript-eslint/no-var-requires */
const SQLConnection_1 = require("./database/SQLConnection");
const Logger_1 = require("../Logger");
const LocationManager_1 = require("./database/LocationManager");
const JobManager_1 = require("./jobs/JobManager");
const GalleryManager_1 = require("./database/GalleryManager");
const UserManager_1 = require("./database/UserManager");
const IndexingManager_1 = require("./database/IndexingManager");
const SearchManager_1 = require("./database/SearchManager");
const VersionManager_1 = require("./database/VersionManager");
const CoverManager_1 = require("./database/CoverManager");
const AlbumManager_1 = require("./database/AlbumManager");
const PersonManager_1 = require("./database/PersonManager");
const SharingManager_1 = require("./database/SharingManager");
const ExtensionManager_1 = require("./extension/ExtensionManager");
const ProjectedCacheManager_1 = require("./database/ProjectedCacheManager");
const SessionManager_1 = require("./database/SessionManager");
const LOG_TAG = '[ObjectManagers]';
class ObjectManagers {
    static { this.instance = null; }
    constructor() {
        this.initDone = false;
        this.managers = [];
    }
    static getInstance() {
        if (!this.instance) {
            this.instance = new ObjectManagers();
        }
        return this.instance;
    }
    static async reset() {
        Logger_1.Logger.silly(LOG_TAG, 'Object manager reset begin');
        if (ObjectManagers.isReady()) {
            if (ObjectManagers.getInstance().IndexingManager &&
                ObjectManagers.getInstance().IndexingManager.IsSavingInProgress) {
                await ObjectManagers.getInstance().IndexingManager.SavingReady;
            }
            for (const manager of ObjectManagers.getInstance().managers) {
                if (manager === ObjectManagers.getInstance().versionManager) {
                    continue;
                }
                if (manager.cleanUp) {
                    await manager.cleanUp();
                }
            }
        }
        await SQLConnection_1.SQLConnection.close();
        this.instance = null;
        Logger_1.Logger.debug(LOG_TAG, 'Object manager reset done');
    }
    static isReady() {
        return this.instance && this.instance.initDone;
    }
    async init() {
        if (this.initDone) {
            return;
        }
        await SQLConnection_1.SQLConnection.init();
        await this.initManagers();
        Logger_1.Logger.debug(LOG_TAG, 'SQL DB inited');
        this.initDone = true;
    }
    async initManagers() {
        this.AlbumManager = new AlbumManager_1.AlbumManager();
        this.GalleryManager = new GalleryManager_1.GalleryManager();
        this.IndexingManager = new IndexingManager_1.IndexingManager();
        this.PersonManager = new PersonManager_1.PersonManager();
        this.CoverManager = new CoverManager_1.CoverManager();
        this.SearchManager = new SearchManager_1.SearchManager();
        this.SharingManager = new SharingManager_1.SharingManager();
        this.UserManager = new UserManager_1.UserManager();
        this.VersionManager = new VersionManager_1.VersionManager();
        this.JobManager = new JobManager_1.JobManager();
        this.LocationManager = new LocationManager_1.LocationManager();
        this.ExtensionManager = new ExtensionManager_1.ExtensionManager();
        this.ProjectedCacheManager = new ProjectedCacheManager_1.ProjectedCacheManager();
        this.SessionManager = new SessionManager_1.SessionManager();
        for (const manager of ObjectManagers.getInstance().managers) {
            if (manager === ObjectManagers.getInstance().versionManager) {
                continue;
            }
            if (manager.init) {
                await manager.init();
            }
        }
    }
    async onDataChange(changedDir = null) {
        await this.VersionManager.onNewDataVersion();
        for (const manager of this.managers) {
            if (manager === this.versionManager) {
                continue;
            }
            if (manager.onNewDataVersion) {
                await manager.onNewDataVersion(changedDir);
            }
        }
    }
    get VersionManager() {
        return this.versionManager;
    }
    set VersionManager(value) {
        if (this.versionManager) {
            this.managers.splice(this.managers.indexOf(this.versionManager), 1);
        }
        this.versionManager = value;
        this.managers.push(this.versionManager);
    }
    get LocationManager() {
        return this.locationManager;
    }
    set LocationManager(value) {
        if (this.locationManager) {
            this.managers.splice(this.managers.indexOf(this.locationManager), 1);
        }
        this.locationManager = value;
        this.managers.push(this.locationManager);
    }
    get AlbumManager() {
        return this.albumManager;
    }
    set AlbumManager(value) {
        if (this.albumManager) {
            this.managers.splice(this.managers.indexOf(this.albumManager), 1);
        }
        this.albumManager = value;
        this.managers.push(this.albumManager);
    }
    get PersonManager() {
        return this.personManager;
    }
    set PersonManager(value) {
        if (this.personManager) {
            this.managers.splice(this.managers.indexOf(this.personManager), 1);
        }
        this.personManager = value;
        this.managers.push(this.personManager);
    }
    get CoverManager() {
        return this.coverManager;
    }
    set CoverManager(value) {
        if (this.coverManager) {
            this.managers.splice(this.managers.indexOf(this.coverManager), 1);
        }
        this.coverManager = value;
        this.managers.push(this.coverManager);
    }
    get IndexingManager() {
        return this.indexingManager;
    }
    set IndexingManager(value) {
        if (this.indexingManager) {
            this.managers.splice(this.managers.indexOf(this.indexingManager), 1);
        }
        this.indexingManager = value;
        this.managers.push(this.indexingManager);
    }
    get GalleryManager() {
        return this.galleryManager;
    }
    set GalleryManager(value) {
        if (this.galleryManager) {
            this.managers.splice(this.managers.indexOf(this.galleryManager), 1);
        }
        this.galleryManager = value;
        this.managers.push(this.galleryManager);
    }
    get UserManager() {
        return this.userManager;
    }
    set UserManager(value) {
        if (this.userManager) {
            this.managers.splice(this.managers.indexOf(this.userManager), 1);
        }
        this.userManager = value;
        this.managers.push(this.userManager);
    }
    get SearchManager() {
        return this.searchManager;
    }
    set SearchManager(value) {
        if (this.searchManager) {
            this.managers.splice(this.managers.indexOf(this.searchManager), 1);
        }
        this.searchManager = value;
        this.managers.push(this.searchManager);
    }
    get SharingManager() {
        return this.sharingManager;
    }
    set SharingManager(value) {
        if (this.sharingManager) {
            this.managers.splice(this.managers.indexOf(this.sharingManager), 1);
        }
        this.sharingManager = value;
        this.managers.push(this.sharingManager);
    }
    get JobManager() {
        return this.jobManager;
    }
    set JobManager(value) {
        if (this.jobManager) {
            this.managers.splice(this.managers.indexOf(this.jobManager), 1);
        }
        this.jobManager = value;
        this.managers.push(this.jobManager);
    }
    get ExtensionManager() {
        return this.extensionManager;
    }
    set ExtensionManager(value) {
        if (this.extensionManager) {
            this.managers.splice(this.managers.indexOf(this.extensionManager), 1);
        }
        this.extensionManager = value;
        this.managers.push(this.extensionManager);
    }
    get ProjectedCacheManager() {
        return this.projectedCacheManager;
    }
    set ProjectedCacheManager(value) {
        if (this.projectedCacheManager) {
            this.managers.splice(this.managers.indexOf(this.projectedCacheManager), 1);
        }
        this.projectedCacheManager = value;
        this.managers.push(this.projectedCacheManager);
    }
    get SessionManager() {
        return this.sessionManager;
    }
    set SessionManager(value) {
        if (this.sessionManager) {
            this.managers.splice(this.managers.indexOf(this.sessionManager), 1);
        }
        this.sessionManager = value;
        this.managers.push(this.sessionManager);
    }
}
exports.ObjectManagers = ObjectManagers;

//# sourceMappingURL=ObjectManagers.js.map
