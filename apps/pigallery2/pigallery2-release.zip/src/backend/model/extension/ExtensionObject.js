"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExtensionObject = void 0;
const ExtensionApp_1 = require("./ExtensionApp");
const ExtensionDB_1 = require("./ExtensionDB");
const ProjectPath_1 = require("../../ProjectPath");
const ExpressRouterWrapper_1 = require("./ExpressRouterWrapper");
const Logger_1 = require("../../Logger");
const ExtensionMessengerHandler_1 = require("./ExtensionMessengerHandler");
const ExtensionConfig_1 = require("./ExtensionConfig");
const UIExtension_1 = require("./UIExtension");
class ExtensionObject {
    /**
     * @param extensionId - Unique ID used internally to track this extension instance (may have _1, _2 suffix if name collision occurs)
     * @param extensionName - Display name of the extension (typically from package.json)
     * @param folder - Folder name where the extension is stored (also used as config key in Config.Extensions.extensions)
     * @param extensionRouter - Express router for extension REST API endpoints
     * @param events - Extension events for hooking into gallery functionality
     */
    constructor(extensionId, extensionName, folder, extensionRouter, events) {
        this.extensionId = extensionId;
        this.extensionName = extensionName;
        this.folder = folder;
        const logger = (0, Logger_1.createLoggerWrapper)(`[Extension][${extensionId}]`);
        this._app = new ExtensionApp_1.ExtensionApp();
        this.config = new ExtensionConfig_1.ExtensionConfig(folder);
        this.db = new ExtensionDB_1.ExtensionDB(logger);
        this.paths = ProjectPath_1.ProjectPath;
        this.Logger = logger;
        this.events = events;
        this.RESTApi = new ExpressRouterWrapper_1.ExpressRouterWrapper(extensionRouter, extensionId, logger);
        this.messengers = new ExtensionMessengerHandler_1.ExtensionMessengerHandler(logger);
        this.ui = new UIExtension_1.UIExtension(this);
    }
}
exports.ExtensionObject = ExtensionObject;

//# sourceMappingURL=ExtensionObject.js.map
