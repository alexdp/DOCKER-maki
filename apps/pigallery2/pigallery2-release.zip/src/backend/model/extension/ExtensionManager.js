"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExtensionManager = void 0;
const ProjectPath_1 = require("../../ProjectPath");
const Config_1 = require("../../../common/config/private/Config");
const fs = require("fs");
const path = require("path");
const promises_1 = require("stream/promises");
const stream_1 = require("stream");
const Logger_1 = require("../../Logger");
const server_1 = require("../../server");
const ExtensionEvent_1 = require("./ExtensionEvent");
const express = require("express");
const SQLConnection_1 = require("../database/SQLConnection");
const ExtensionObject_1 = require("./ExtensionObject");
const ExtensionDecorator_1 = require("./ExtensionDecorator");
const util = require("util");
const AdmZip = require("adm-zip");
const ExtensionRepository_1 = require("./ExtensionRepository");
const ExtensionConfigTemplateLoader_1 = require("./ExtensionConfigTemplateLoader");
const Utils_1 = require("../../../common/Utils");
const ExtensionConfigWrapper_1 = require("./ExtensionConfigWrapper");
// eslint-disable-next-line @typescript-eslint/no-var-requires
const exec = util.promisify(require('child_process').exec);
const LOG_TAG = '[ExtensionManager]';
class ExtensionManager {
    static { this.EXTENSION_API_PATH = Config_1.Config.Server.apiPath + '/extension'; }
    constructor() {
        this.repository = new ExtensionRepository_1.ExtensionRepository();
        this.extObjects = {};
        this.initEvents();
    }
    async init() {
        this.extObjects = {};
        this.initEvents();
        if (!Config_1.Config.Extensions.enabled) {
            return;
        }
        this.router = express.Router();
        server_1.Server.instance?.app.use(ExtensionManager.EXTENSION_API_PATH, this.router);
        await this.initExtensions();
    }
    async getExtensionListWithInstallStatus() {
        const extensionList = await this.repository.getExtensionList();
        // Add installed status to each extension
        return extensionList.map(extension => {
            // Check if the extension is installed by looking for its name in the installed extensions
            const isInstalled = Array.from(Config_1.Config.Extensions.extensions.keys()).some(key => key.toLowerCase() === extension.id.toLowerCase());
            return {
                ...extension,
                installed: isInstalled
            };
        });
    }
    async cleanUp() {
        if (!Config_1.Config.Extensions.enabled) {
            return;
        }
        this.initEvents(); // reset events
        await this.cleanUpExtensions();
        server_1.Server.instance?.app.use(ExtensionManager.EXTENSION_API_PATH, this.router);
        this.extObjects = {};
    }
    /**
     * Install an extension from the repository
     * @param extensionId - The repository extension ID (not to be confused with the unique internal extensionId used in extObjects)
     */
    async installExtension(extensionId) {
        if (!Config_1.Config.Extensions.enabled) {
            throw new Error('Extensions are disabled');
        }
        Logger_1.Logger.debug(LOG_TAG, `Installing extension with ID: ${extensionId}`);
        // Get the extension list
        const extensionList = await this.repository.getExtensionList();
        // Find the extension with the given ID
        const extension = extensionList.find(ext => ext.id.toLowerCase() === extensionId.toLowerCase());
        if (!extension) {
            throw new Error(`Extension with ID ${extensionId} not found`);
        }
        if (!extension.zipUrl) {
            throw new Error(`Extension ${extensionId} does not have a zip URL`);
        }
        // Download the zip file
        const zipFilePath = path.join(ProjectPath_1.ProjectPath.ExtensionFolder, `${extensionId}.zip`);
        Logger_1.Logger.silly(LOG_TAG, `Downloading extension from ${extension.zipUrl} to ${zipFilePath}`);
        await this.downloadFile(extension.zipUrl, zipFilePath);
        // Create the extension directory
        const extensionDir = path.join(ProjectPath_1.ProjectPath.ExtensionFolder, extensionId);
        if (!fs.existsSync(extensionDir)) {
            await fs.promises.mkdir(extensionDir, { recursive: true });
        }
        // Unzip the file
        Logger_1.Logger.silly(LOG_TAG, `Unzipping extension to ${extensionDir}`);
        await this.unzipFile(zipFilePath, extensionDir);
        // Update the configuration
        Logger_1.Logger.silly(LOG_TAG, `Updating configuration for extension ${extensionId}`);
        ExtensionConfigTemplateLoader_1.ExtensionConfigTemplateLoader.Instance.loadSingleExtension(extensionId, Config_1.Config);
        // Initialize the extension
        Logger_1.Logger.silly(LOG_TAG, `Initializing extension ${extensionId}`);
        await this.initSingleExtension(extensionId);
        // Clean up the temporary file
        if (fs.existsSync(zipFilePath)) {
            fs.unlinkSync(zipFilePath);
        }
        Logger_1.Logger.debug(LOG_TAG, `Extension ${extensionId} installed successfully`);
    }
    /**
     * Reload an extension by cleaning up and re-initializing it
     * @param configKey - The key used in Config.Extensions.extensions map (typically the folder name)
     */
    async reloadExtension(configKey) {
        if (!Config_1.Config.Extensions.enabled) {
            throw new Error('Extensions are disabled');
        }
        Logger_1.Logger.debug(LOG_TAG, `Reloading extension with config key: ${configKey}`);
        // Find the unique extension ID by matching the folder name
        let uniqueExtensionId = null;
        for (const id of Object.keys(this.extObjects)) {
            if (this.extObjects[id].folder === configKey) {
                uniqueExtensionId = id;
                break;
            }
        }
        if (!uniqueExtensionId) {
            throw new Error(`Extension with config key ${configKey} not found in configuration`);
        }
        // Clean up the extension
        await this.cleanUpSingleExtension(uniqueExtensionId);
        // Re-initialize the extension
        await this.initSingleExtension(configKey);
        Logger_1.Logger.debug(LOG_TAG, `Extension ${uniqueExtensionId} reloaded successfully`);
    }
    /**
     * Delete an extension by cleaning up, removing its folder, and removing it from configuration
     * @param configKey - The key used in Config.Extensions.extensions map (typically the folder name)
     */
    async deleteExtension(configKey) {
        if (!Config_1.Config.Extensions.enabled) {
            throw new Error('Extensions are disabled');
        }
        Logger_1.Logger.debug(LOG_TAG, `Deleting extension with config key: ${configKey}`);
        // Find the unique extension ID by matching the folder name
        let uniqueExtensionId = null;
        for (const id of Object.keys(this.extObjects)) {
            if (this.extObjects[id].folder === configKey) {
                uniqueExtensionId = id;
                break;
            }
        }
        if (!uniqueExtensionId) {
            // The extension does not have an extension object, probably it had no init function
            Logger_1.Logger.silly(LOG_TAG, `Extension with config key ${configKey} not found in configuration`);
        }
        else {
            // Clean up the extension
            await this.cleanUpSingleExtension(uniqueExtensionId);
        }
        // Remove the extension folder
        const extPath = path.join(ProjectPath_1.ProjectPath.ExtensionFolder, configKey);
        if (fs.existsSync(extPath)) {
            Logger_1.Logger.silly(LOG_TAG, `Removing extension folder: ${extPath}`);
            fs.rmSync(extPath, { recursive: true, force: true });
        }
        // Remove from configuration
        const original = await ExtensionConfigWrapper_1.ExtensionConfigWrapper.original();
        original.Extensions.extensions.removeProperty(configKey);
        await original.save();
        Config_1.Config.Extensions.extensions.removeProperty(configKey);
        Logger_1.Logger.debug(LOG_TAG, `Extension ${configKey} deleted successfully`);
    }
    getUIExtensionConfigs() {
        return Object.values(this.extObjects)
            .filter(obj => !!obj.ui?.buttonConfigs?.length)
            .map(obj => ({
            mediaButtons: obj.ui.buttonConfigs,
            extensionBasePath: Utils_1.Utils.concatUrls('/extension', obj.extensionId)
        }));
    }
    initEvents() {
        this.events = {
            gallery: {
                MetadataLoader: {
                    loadPhotoMetadata: new ExtensionEvent_1.ExtensionEvent(),
                    loadVideoMetadata: new ExtensionEvent_1.ExtensionEvent()
                },
                CoverManager: {
                    getCoverForDirectory: new ExtensionEvent_1.ExtensionEvent(),
                    getCoverForAlbum: new ExtensionEvent_1.ExtensionEvent(),
                },
                ProjectedCacheManager: {
                    invalidateDirectoryCache: new ExtensionEvent_1.ExtensionEvent(),
                    getCacheForDirectory: new ExtensionEvent_1.ExtensionEvent()
                },
                DiskManager: {
                    excludeDir: new ExtensionEvent_1.ExtensionEvent(),
                    scanDirectory: new ExtensionEvent_1.ExtensionEvent()
                },
                ImageRenderer: {
                    render: new ExtensionEvent_1.ExtensionEvent()
                },
                VideoConverter: {
                    convert: new ExtensionEvent_1.ExtensionEvent()
                }
            }
        };
        ExtensionDecorator_1.ExtensionDecoratorObject.init(this.events);
    }
    createUniqueExtensionObject(extensionName, folderName) {
        let uniqueExtensionId = extensionName;
        if (this.extObjects[uniqueExtensionId]) {
            let i = 0;
            while (this.extObjects[`${extensionName}_${++i}`]) { /* empty */
            }
            uniqueExtensionId = `${extensionName}_${++i}`;
        }
        if (!this.extObjects[uniqueExtensionId]) {
            this.extObjects[uniqueExtensionId] = new ExtensionObject_1.ExtensionObject(uniqueExtensionId, extensionName, folderName, this.router, this.events);
        }
        return this.extObjects[uniqueExtensionId];
    }
    /**
     * Initialize a single extension
     * @param configKey The key used in Config.Extensions.extensions map (typically the folder name)
     * @returns Promise that resolves when the extension is initialized
     */
    async initSingleExtension(configKey) {
        const extConf = Config_1.Config.Extensions.extensions[configKey];
        if (!extConf) {
            Logger_1.Logger.silly(LOG_TAG, `Skipping ${configKey} initiation. Extension config is missing.`);
            return;
        }
        const folderName = extConf.path;
        let extName = folderName;
        if (extConf.enabled === false) {
            Logger_1.Logger.silly(LOG_TAG, `Skipping ${folderName} initiation. Extension is disabled.`);
            return;
        }
        const extPath = path.join(ProjectPath_1.ProjectPath.ExtensionFolder, folderName);
        const serverExtPath = path.join(extPath, 'server.js');
        const packageJsonPath = path.join(extPath, 'package.json');
        if (!fs.existsSync(serverExtPath)) {
            Logger_1.Logger.silly(LOG_TAG, `Skipping ${folderName} server initiation. server.js does not exists`);
            return;
        }
        if (fs.existsSync(packageJsonPath)) {
            if (fs.existsSync(path.join(extPath, 'node_modules'))) {
                Logger_1.Logger.debug(LOG_TAG, `node_modules folder exists. Skipping "npm install".`);
            }
            else {
                Logger_1.Logger.silly(LOG_TAG, `Running: "npm install --prefer-offline --no-audit --progress=false --omit=dev" in ${extPath}`);
                await exec('npm install  --no-audit --progress=false --omit=dev', {
                    cwd: extPath
                });
            }
            // eslint-disable-next-line @typescript-eslint/no-var-requires
            const pkg = require(packageJsonPath);
            if (pkg.name) {
                extName = pkg.name;
            }
        }
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const ext = require(serverExtPath);
        if (typeof ext?.init === 'function') {
            Logger_1.Logger.debug(LOG_TAG, 'Running init on extension: ' + folderName);
            await ext?.init(this.createUniqueExtensionObject(extName, folderName));
        }
    }
    /**
     * Initialize all extensions
     */
    async initExtensions() {
        for (const prop of Config_1.Config.Extensions.extensions.keys()) {
            await this.initSingleExtension(prop);
        }
        if (Config_1.Config.Extensions.cleanUpUnusedTables) {
            // Clean up tables after all Extension was initialized.
            await SQLConnection_1.SQLConnection.removeUnusedTables();
        }
    }
    async cleanUpSingleExtension(uniqueExtensionId) {
        const extObj = this.extObjects[uniqueExtensionId];
        if (!extObj) {
            Logger_1.Logger.silly(LOG_TAG, `Extension ${uniqueExtensionId} not found in extObjects, skipping cleanup`);
            return;
        }
        const serverExt = path.join(extObj.folder, 'server.js');
        if (fs.existsSync(serverExt)) {
            // eslint-disable-next-line @typescript-eslint/no-var-requires
            const ext = require(serverExt);
            if (typeof ext?.cleanUp === 'function') {
                Logger_1.Logger.debug(LOG_TAG, 'Running cleanUp on extension: ' + extObj.extensionName);
                await ext?.cleanUp(extObj);
            }
        }
        extObj.messengers.cleanUp();
        // Remove from extObjects
        delete this.extObjects[uniqueExtensionId];
    }
    async cleanUpExtensions() {
        for (const uniqueExtensionId of Object.keys(this.extObjects)) {
            await this.cleanUpSingleExtension(uniqueExtensionId);
        }
    }
    async downloadFile(url, outputPath) {
        const response = await fetch(url);
        if (!response.ok || !response.body) {
            throw new Error(`Unexpected response ${response.statusText}`);
        }
        const nodeReadable = stream_1.Readable.fromWeb(response.body);
        // Pipe the response body to a file
        await (0, promises_1.pipeline)(nodeReadable, fs.createWriteStream(outputPath));
    }
    async unzipFile(zipFilePath, outputPath) {
        try {
            // Extract to temp first
            const tempExtractPath = path.join(outputPath, '__temp_unzip');
            const zip = new AdmZip(zipFilePath);
            zip.extractAllTo(tempExtractPath, true);
            // Flatten directory
            // Check for single subdirectory
            const entries = fs.readdirSync(tempExtractPath);
            if (entries.length === 1) {
                const singleDirPath = path.join(tempExtractPath, entries[0]);
                const stat = fs.statSync(singleDirPath);
                if (stat.isDirectory()) {
                    const innerFiles = fs.readdirSync(singleDirPath);
                    // Move contents of the inner folder to outputPath
                    innerFiles.forEach((file) => {
                        const src = path.join(singleDirPath, file);
                        const dest = path.join(outputPath, file);
                        fs.renameSync(src, dest);
                    });
                    // Remove the temp and wrapper folder
                    fs.rmSync(tempExtractPath, { recursive: true, force: true });
                    console.log('Flattened and extracted successfully.');
                }
                else {
                    // It's not a folder, just move it directly
                    fs.renameSync(singleDirPath, path.join(outputPath, entries[0]));
                    fs.rmSync(tempExtractPath, { recursive: true, force: true });
                    console.log('Moved single file directly.');
                }
            }
            else {
                // Multiple entries, just move all
                entries.forEach((entry) => {
                    const src = path.join(tempExtractPath, entry);
                    const dest = path.join(outputPath, entry);
                    fs.renameSync(src, dest);
                });
                fs.rmSync(tempExtractPath, { recursive: true, force: true });
                console.log('Extracted with multiple top-level items.');
            }
        }
        catch (error) {
            Logger_1.Logger.error(LOG_TAG, `Error unzipping file: ${error}`);
            throw new Error(`Failed to unzip file: ${error}`);
        }
    }
}
exports.ExtensionManager = ExtensionManager;

//# sourceMappingURL=ExtensionManager.js.map
