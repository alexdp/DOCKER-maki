"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExtensionDecorator = exports.ExtensionDecoratorObject = void 0;
class ExtensionDecoratorObject {
    static init(events) {
        this.events = events;
    }
}
exports.ExtensionDecoratorObject = ExtensionDecoratorObject;
const ExtensionDecorator = (fn) => {
    return (target, propertyName, descriptor) => {
        const targetMethod = descriptor.value;
        descriptor.value = async function (...args) {
            if (!ExtensionDecoratorObject.events) {
                return await targetMethod.apply(this, args);
            }
            const event = fn(ExtensionDecoratorObject.events);
            const eventObj = { stopPropagation: false };
            const input = await event.triggerBefore(args, eventObj);
            // skip the rest of the execution if the before handler asked for stop propagation
            if (eventObj.stopPropagation) {
                return input;
            }
            const out = await targetMethod.apply(this, input);
            return await event.triggerAfter(input, out);
        };
        return descriptor;
    };
};
exports.ExtensionDecorator = ExtensionDecorator;

//# sourceMappingURL=ExtensionDecorator.js.map
