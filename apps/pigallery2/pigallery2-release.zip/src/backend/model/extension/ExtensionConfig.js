"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExtensionConfig = void 0;
const Config_1 = require("../../../common/config/private/Config");
class ExtensionConfig {
    /**
     * @param configKey - The key used in Config.Extensions.extensions map (matches the extension's folder name)
     */
    constructor(configKey) {
        this.configKey = configKey;
    }
    getConfig() {
        const c = Config_1.Config.Extensions.extensions[this.configKey];
        return c?.configs;
    }
}
exports.ExtensionConfig = ExtensionConfig;

//# sourceMappingURL=ExtensionConfig.js.map
