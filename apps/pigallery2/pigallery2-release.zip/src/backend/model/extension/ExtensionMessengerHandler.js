"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExtensionMessengerHandler = void 0;
const ExtensionMessenger_1 = require("../messenger/ExtensionMessenger");
const MessengerRepository_1 = require("../messenger/MessengerRepository");
class ExtensionMessengerHandler {
    constructor(extLogger) {
        this.extLogger = extLogger;
        this.messengers = [];
    }
    addMessenger(name, config, callbacks) {
        if (MessengerRepository_1.MessengerRepository.Instance.get(name)) {
            this.extLogger.silly('Messenger already exist. Overriding it:', name);
            MessengerRepository_1.MessengerRepository.Instance.remove({ Name: name });
        }
        else {
            this.extLogger.silly('Adding new Messenger:', name);
        }
        const em = new ExtensionMessenger_1.ExtensionMessenger(name, config, callbacks);
        this.messengers.push(em);
        MessengerRepository_1.MessengerRepository.Instance.register(em);
    }
    cleanUp() {
        this.extLogger.silly('Removing Messenger');
        this.messengers.forEach(m => MessengerRepository_1.MessengerRepository.Instance.remove(m));
    }
}
exports.ExtensionMessengerHandler = ExtensionMessengerHandler;

//# sourceMappingURL=ExtensionMessengerHandler.js.map
