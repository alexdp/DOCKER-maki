"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExtensionDB = void 0;
const SQLConnection_1 = require("../database/SQLConnection");
class ExtensionDB {
    constructor(extLogger) {
        this.extLogger = extLogger;
    }
    // eslint-disable-next-line @typescript-eslint/ban-types
    _getAllTables() {
        return SQLConnection_1.SQLConnection.getEntries();
    }
    getSQLConnection() {
        return SQLConnection_1.SQLConnection.getConnection();
    }
    // eslint-disable-next-line @typescript-eslint/ban-types
    async setExtensionTables(tables) {
        this.extLogger.debug('Adding ' + tables?.length + ' extension tables to DB');
        await SQLConnection_1.SQLConnection.addEntries(tables);
    }
}
exports.ExtensionDB = ExtensionDB;

//# sourceMappingURL=ExtensionDB.js.map
