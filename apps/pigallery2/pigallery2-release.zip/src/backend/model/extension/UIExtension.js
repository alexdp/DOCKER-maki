"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UIExtension = void 0;
const UserDTO_1 = require("../../../common/entities/UserDTO");
const Logger_1 = require("../../Logger");
class UIExtension {
    constructor(extensionObject) {
        this.extensionObject = extensionObject;
        this.buttonConfigs = [];
    }
    addMediaButton(buttonConfig, serverSB) {
        this.buttonConfigs.push(buttonConfig);
        // api path isn't set
        if (!buttonConfig.apiPath && serverSB) {
            Logger_1.Logger.warn('[UIExtension]', `Button config ${buttonConfig.name} has no apiPath, but has callback function. This is not supported.`);
            return;
        }
        this.extensionObject.RESTApi.post.mediaJsonResponse([buttonConfig.apiPath], buttonConfig.minUserRole || UserDTO_1.UserRoles.LimitedGuest, !buttonConfig.skipDirectoryInvalidation, serverSB);
    }
}
exports.UIExtension = UIExtension;

//# sourceMappingURL=UIExtension.js.map
