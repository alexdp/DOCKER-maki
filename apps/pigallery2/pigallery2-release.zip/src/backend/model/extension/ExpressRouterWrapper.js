"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpressRouteWrapper = exports.ExpressRouterWrapper = void 0;
const AuthenticationMWs_1 = require("../../middlewares/user/AuthenticationMWs");
const RenderingMWs_1 = require("../../middlewares/RenderingMWs");
const ExtensionManager_1 = require("./ExtensionManager");
const Utils_1 = require("../../../common/Utils");
const GalleryMWs_1 = require("../../middlewares/GalleryMWs");
const MediaEntity_1 = require("../database/enitites/MediaEntity");
const SQLConnection_1 = require("../database/SQLConnection");
const ObjectManagers_1 = require("../ObjectManagers");
class ExpressRouterWrapper {
    constructor(router, name, extLogger) {
        this.router = router;
        this.name = name;
        this.extLogger = extLogger;
    }
    get use() {
        return new ExpressRouteWrapper(this.router, this.name, 'use', this.extLogger);
    }
    get get() {
        return new ExpressRouteWrapper(this.router, this.name, 'get', this.extLogger);
    }
    get put() {
        return new ExpressRouteWrapper(this.router, this.name, 'put', this.extLogger);
    }
    get post() {
        return new ExpressRouteWrapper(this.router, this.name, 'post', this.extLogger);
    }
    get delete() {
        return new ExpressRouteWrapper(this.router, this.name, 'delete', this.extLogger);
    }
}
exports.ExpressRouterWrapper = ExpressRouterWrapper;
class ExpressRouteWrapper {
    constructor(router, name, func, extLogger) {
        this.router = router;
        this.name = name;
        this.func = func;
        this.extLogger = extLogger;
    }
    mediaJsonResponse(paths, minRole, invalidateDirectory, cb) {
        const fullPaths = paths.map(p => (Utils_1.Utils.concatUrls('/' + this.name + '/' + p)));
        this.router[this.func](fullPaths, ...(this.getAuthMWs(minRole).concat([
            async (req, res, next) => {
                req.params['mediaPath'] = req.body.media;
                next();
            },
            AuthenticationMWs_1.AuthenticationMWs.normalizePathParam('mediaPath'),
            AuthenticationMWs_1.AuthenticationMWs.authoriseMedia('mediaPath'),
            GalleryMWs_1.GalleryMWs.getMediaEntry,
            async (req, res, next) => {
                try {
                    const media = req.resultPipe;
                    const connection = await SQLConnection_1.SQLConnection.getConnection();
                    await cb(req.params, req.body, req.session.context.user, media, connection.getRepository(MediaEntity_1.MediaEntity));
                    if (invalidateDirectory) {
                        await ObjectManagers_1.ObjectManagers.getInstance().onDataChange(media.directory);
                    }
                    req.resultPipe = 'ok';
                    next();
                }
                catch (e) {
                    next(new Error(`[${this.name}]Error during processing:${paths}`));
                }
            },
            RenderingMWs_1.RenderingMWs.renderResult
        ])));
        const p = ExtensionManager_1.ExtensionManager.EXTENSION_API_PATH + fullPaths;
        this.extLogger.silly(`Listening on ${this.func} ${p}`);
        return p;
    }
    jsonResponse(paths, minRole, cb) {
        const fullPaths = paths.map(p => (Utils_1.Utils.concatUrls('/' + this.name + '/' + p)));
        this.router[this.func](fullPaths, ...(this.getAuthMWs(minRole).concat([
            async (req, res, next) => {
                try {
                    req.resultPipe = await cb(req.params, req.body, req.session.context.user);
                    next();
                }
                catch (e) {
                    next(new Error(`[${this.name}]Error during processing:${paths}`));
                }
            },
            RenderingMWs_1.RenderingMWs.renderResult
        ])));
        const p = ExtensionManager_1.ExtensionManager.EXTENSION_API_PATH + fullPaths;
        this.extLogger.silly(`Listening on ${this.func} ${p}`);
        return p;
    }
    rawMiddleware(paths, minRole, mw) {
        const fullPaths = paths.map(p => (Utils_1.Utils.concatUrls('/' + this.name + '/' + p)));
        this.router[this.func](fullPaths, ...this.getAuthMWs(minRole), mw);
        const p = ExtensionManager_1.ExtensionManager.EXTENSION_API_PATH + fullPaths;
        this.extLogger.silly(`Listening on ${this.func} ${p}`);
        return p;
    }
    getAuthMWs(minRole) {
        return minRole ? [AuthenticationMWs_1.AuthenticationMWs.authenticate,
            AuthenticationMWs_1.AuthenticationMWs.authorise(minRole)] : [];
    }
}
exports.ExpressRouteWrapper = ExpressRouteWrapper;

//# sourceMappingURL=ExpressRouterWrapper.js.map
