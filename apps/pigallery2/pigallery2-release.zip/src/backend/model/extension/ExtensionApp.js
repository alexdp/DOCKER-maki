"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExtensionApp = void 0;
const ObjectManagers_1 = require("../ObjectManagers");
const Config_1 = require("../../../common/config/private/Config");
const server_1 = require("../../server");
class ExtensionApp {
    get config() {
        return Config_1.Config;
    }
    get expressApp() {
        return server_1.Server.getInstance().app;
    }
    get objectManagers() {
        return ObjectManagers_1.ObjectManagers.getInstance();
    }
}
exports.ExtensionApp = ExtensionApp;

//# sourceMappingURL=ExtensionApp.js.map
