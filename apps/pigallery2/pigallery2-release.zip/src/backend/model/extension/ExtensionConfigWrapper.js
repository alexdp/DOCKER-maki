"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExtensionConfigWrapper = void 0;
const PrivateConfigClass_1 = require("../../../common/config/private/PrivateConfigClass");
const node_1 = require("typeconfig/node");
const ExtensionConfigTemplateLoader_1 = require("./ExtensionConfigTemplateLoader");
const NotifocationManager_1 = require("../NotifocationManager");
const fs = require("fs");
const LOG_TAG = '[ExtensionConfigWrapper]';
/**
 * Wraps to the original config and makes sure all extension-related configs are loaded
 */
class ExtensionConfigWrapper {
    static async original(showDetailedError = false) {
        const pc = node_1.ConfigClassBuilder.attachPrivateInterface(new PrivateConfigClass_1.PrivateConfigClass());
        ExtensionConfigTemplateLoader_1.ExtensionConfigTemplateLoader.Instance.loadExtensionTemplates(pc);
        try {
            // make sure the config file exists by the time we load it.
            // TODO: remove this once typeconfig is fixed and can properly load defaults in arrays
            if (!fs.existsSync(pc.__options.configPath)) {
                await pc.load();
            }
            await pc.load(); // loading the basic configs, but we do not know the extension config hierarchy yet
            // TODO make sure that all extensions are present even after loading them from file
        }
        catch (e) {
            console.error(LOG_TAG, 'Error during loading config. Reverting to defaults.');
            console.error(e);
            if (showDetailedError) {
                console.error(LOG_TAG, 'This is most likely due to: 1) you added a bad configuration in the server.json OR 2) The configuration changed in the latest release.');
                NotifocationManager_1.NotificationManager.error('Can\'t load config. Reverting to default. This is most likely due to: 1) you added a bad configuration in the server.json OR 2) The configuration changed in the latest release.', (e.toString ? e.toString() : JSON.stringify(e)));
            }
        }
        return pc;
    }
    static originalSync(showDetailedError = false) {
        const pc = node_1.ConfigClassBuilder.attachPrivateInterface(new PrivateConfigClass_1.PrivateConfigClass());
        ExtensionConfigTemplateLoader_1.ExtensionConfigTemplateLoader.Instance.loadExtensionTemplates(pc);
        try {
            // make sure the config file exists by the time we load it.
            // TODO: remove this once typeconfig is fixed and can properly load defaults in arrays
            if (!fs.existsSync(pc.__options.configPath)) {
                pc.loadSync();
            }
            pc.loadSync(); // loading the basic configs, but we do not know the extension config hierarchy yet
            // TODO make sure that all extensions are present even after loading them from file
        }
        catch (e) {
            console.error(LOG_TAG, 'Error during loading config. Reverting to defaults.');
            console.error(e);
            if (showDetailedError) {
                console.error(LOG_TAG, 'This is most likely due to: 1) you added a bad configuration in the server.json OR 2) The configuration changed in the latest release.');
                NotifocationManager_1.NotificationManager.error('Ca\'nt load config. Reverting to default. This is most likely due to: 1) you added a bad configuration in the server.json OR 2) The configuration changed in the latest release.', (e.toString ? e.toString() : JSON.stringify(e)));
            }
        }
        return pc;
    }
}
exports.ExtensionConfigWrapper = ExtensionConfigWrapper;

//# sourceMappingURL=ExtensionConfigWrapper.js.map
