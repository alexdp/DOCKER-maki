"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExtensionEvent = void 0;
class ExtensionEvent {
    constructor() {
        this.beforeHandlers = [];
        this.afterHandlers = [];
    }
    before(handler) {
        if (typeof handler !== 'function') {
            throw new Error('ExtensionEvent::before: Handler is not a function');
        }
        this.beforeHandlers.push(handler);
    }
    after(handler) {
        if (typeof handler !== 'function') {
            throw new Error('ExtensionEvent::after: Handler is not a function');
        }
        this.afterHandlers.push(handler);
    }
    offAfter(handler) {
        this.afterHandlers = this.afterHandlers.filter((h) => h !== handler);
    }
    offBefore(handler) {
        this.beforeHandlers = this.beforeHandlers.filter((h) => h !== handler);
    }
    async triggerBefore(input, event) {
        let pipe = input;
        if (this.beforeHandlers && this.beforeHandlers.length > 0) {
            const s = this.beforeHandlers.slice(0);
            for (let i = 0; i < s.length; ++i) {
                if (event.stopPropagation) {
                    break;
                }
                pipe = await s[i](pipe, event);
            }
        }
        return pipe;
    }
    async triggerAfter(input, output) {
        if (this.afterHandlers && this.afterHandlers.length > 0) {
            const s = this.afterHandlers.slice(0);
            for (let i = 0; i < s.length; ++i) {
                output = await s[i]({ input, output });
            }
        }
        return output;
    }
}
exports.ExtensionEvent = ExtensionEvent;

//# sourceMappingURL=ExtensionEvent.js.map
