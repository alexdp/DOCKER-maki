"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Messenger = void 0;
const MediaDTO_1 = require("../../../common/entities/MediaDTO");
const PhotoProcessing_1 = require("../fileaccess/fileprocessing/PhotoProcessing");
const ProjectPath_1 = require("../../ProjectPath");
const Config_1 = require("../../../common/config/private/Config");
const PhotoWorker_1 = require("../fileaccess/PhotoWorker");
const path = require("path");
const Utils_1 = require("../../../common/Utils");
const QueryParams_1 = require("../../../common/QueryParams");
class Messenger {
    constructor() {
        this.ConfigTemplate = [];
    }
    async getThumbnail(m) {
        return await PhotoProcessing_1.PhotoProcessing.generateThumbnail(path.join(ProjectPath_1.ProjectPath.ImageFolder, m.directory.path, m.directory.name, m.name), Config_1.Config.Media.Photo.thumbnailSizes[0], MediaDTO_1.MediaDTOUtils.isPhoto(m) ? PhotoWorker_1.ThumbnailSourceType.Photo : PhotoWorker_1.ThumbnailSourceType.Video, false);
    }
    async send(config, input) {
        if (Array.isArray(input) && input.length > 0
            && input[0]?.name
            && input[0]?.directory
            && input[0]?.metadata?.creationDate) {
            const media = input;
            for (let i = 0; i < media.length; ++i) {
                media[i].thumbnailPath = await this.getThumbnail(media[i]);
                media[i].thumbnailUrl = Utils_1.Utils.concatUrls(Config_1.Config.Server.publicUrl, '/gallery/', encodeURIComponent(path.join(media[i].directory.path, media[i].directory.name))) +
                    '?' + QueryParams_1.QueryParams.gallery.photo + '=' + encodeURIComponent(media[i].name);
            }
            return await this.sendMedia(config, media);
        }
        // TODO: implement other branches
        throw new Error('Not yet implemented');
    }
}
exports.Messenger = Messenger;

//# sourceMappingURL=Messenger.js.map
