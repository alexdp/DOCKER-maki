"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessengerRepository = void 0;
const EmailMessenger_1 = require("./EmailMessenger");
const StdoutMessenger_1 = require("./StdoutMessenger");
class MessengerRepository {
    constructor() {
        this.messengers = {};
    }
    static { this.instance = null; }
    static get Instance() {
        if (MessengerRepository.instance == null) {
            MessengerRepository.instance = new MessengerRepository();
        }
        return MessengerRepository.instance;
    }
    getAll() {
        return Object.values(this.messengers);
    }
    remove(m) {
        if (!this.messengers[m.Name]) {
            throw new Error('Messenger does not exist:' + m.Name);
        }
        delete this.messengers[m.Name];
    }
    register(msgr) {
        if (typeof this.messengers[msgr.Name] !== 'undefined') {
            throw new Error('Messenger already exist:' + msgr.Name);
        }
        this.messengers[msgr.Name] = msgr;
    }
    get(name) {
        return this.messengers[name];
    }
}
exports.MessengerRepository = MessengerRepository;
MessengerRepository.Instance.register(new EmailMessenger_1.EmailMessenger());
MessengerRepository.Instance.register(new StdoutMessenger_1.StdoutMessenger());

//# sourceMappingURL=MessengerRepository.js.map
