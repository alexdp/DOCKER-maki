"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StdoutMessenger = void 0;
const Messenger_1 = require("./Messenger");
const JobDTO_1 = require("../../../common/entities/job/JobDTO");
class StdoutMessenger extends Messenger_1.Messenger {
    constructor() {
        super();
        this.Name = JobDTO_1.DefaultMessengers[JobDTO_1.DefaultMessengers.Stdout];
        this.ConfigTemplate = [];
    }
    async sendMedia(config, media) {
        console.log(media.map(m => m.thumbnailPath));
    }
}
exports.StdoutMessenger = StdoutMessenger;

//# sourceMappingURL=StdoutMessenger.js.map
