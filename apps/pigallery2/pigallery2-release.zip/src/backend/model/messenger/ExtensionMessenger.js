"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExtensionMessenger = void 0;
const Messenger_1 = require("./Messenger");
class ExtensionMessenger extends Messenger_1.Messenger {
    constructor(Name, ConfigTemplate, callbacks) {
        super();
        this.Name = Name;
        this.ConfigTemplate = ConfigTemplate;
        this.callbacks = callbacks;
    }
    sendMedia(config, media) {
        return this.callbacks.sendMedia(config, media);
    }
}
exports.ExtensionMessenger = ExtensionMessenger;

//# sourceMappingURL=ExtensionMessenger.js.map
