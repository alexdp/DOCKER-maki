"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailMessenger = void 0;
const nodemailer_1 = require("nodemailer");
const Config_1 = require("../../../common/config/private/Config");
const Messenger_1 = require("./Messenger");
const BackendTexts_1 = require("../../../common/BackendTexts");
const JobDTO_1 = require("../../../common/entities/job/JobDTO");
const Utils_1 = require("../../../common/Utils");
class EmailMessenger extends Messenger_1.Messenger {
    constructor() {
        super();
        this.Name = JobDTO_1.DefaultMessengers[JobDTO_1.DefaultMessengers.Email];
        this.ConfigTemplate = [{
                id: 'emailTo',
                type: 'string-array',
                name: BackendTexts_1.backendTexts.emailTo.name,
                description: BackendTexts_1.backendTexts.emailTo.description,
                defaultValue: [],
            }, {
                id: 'emailSubject',
                type: 'string',
                name: BackendTexts_1.backendTexts.emailSubject.name,
                description: BackendTexts_1.backendTexts.emailSubject.description,
                defaultValue: 'Latest photos for you',
            }, {
                id: 'emailText',
                type: 'string',
                name: BackendTexts_1.backendTexts.emailText.name,
                description: BackendTexts_1.backendTexts.emailText.description,
                defaultValue: 'I hand picked these photos just for you:',
            }];
        this.transporter = (0, nodemailer_1.createTransport)({
            host: Config_1.Config.Messaging.Email.smtp.host,
            port: Config_1.Config.Messaging.Email.smtp.port,
            secure: Config_1.Config.Messaging.Email.smtp.secure,
            requireTLS: Config_1.Config.Messaging.Email.smtp.requireTLS,
            auth: {
                user: Config_1.Config.Messaging.Email.smtp.user,
                pass: Config_1.Config.Messaging.Email.smtp.password
            }
        });
    }
    async sendMedia(mailSettings, media) {
        const attachments = [];
        const htmlStart = '<h1 style="text-align: center; margin-bottom: 2em">' + Config_1.Config.Server.applicationTitle + '</h1>\n' +
            '<h3>' + mailSettings.emailText + '</h3>\n' +
            '<table style="margin-left: auto;  margin-right: auto;">\n' +
            '  <tbody>\n';
        const htmlEnd = '  </tr>\n' +
            '  </tbody>\n' +
            '</table>';
        let htmlMiddle = '';
        const numberOfColumns = media.length >= 6 ? 3 : 2;
        for (let i = 0; i < media.length; ++i) {
            const location = media[i].metadata.positionData?.country ?
                media[i].metadata.positionData?.country :
                (media[i].metadata.positionData?.city ?
                    media[i].metadata.positionData?.city : '');
            const caption = Utils_1.Utils.getFullYear(Utils_1.Utils.getTimeMS(media[i].metadata.creationDate, media[i].metadata.creationDateOffset, Config_1.Config.Gallery.ignoreTimestampOffset), undefined) + (location ? ', ' + location : '');
            attachments.push({
                filename: media[i].name,
                path: media[i].thumbnailPath,
                cid: 'img' + i
            });
            if (i % numberOfColumns == 0) {
                htmlMiddle += '<tr>';
            }
            htmlMiddle += '<td>\n' +
                '      <a style="display: block;text-align: center;" href="' + media[i].thumbnailUrl + '"><img alt="' + media[i].name + '" style="max-width: 200px; max-height: 150px;  height:auto; width:auto;" src="cid:img' + i + '"/></a>\n' +
                caption +
                '    </td>\n';
            if (i % numberOfColumns == (numberOfColumns - 1) || i === media.length - 1) {
                htmlMiddle += '</tr>';
            }
        }
        return await this.transporter.sendMail({
            from: Config_1.Config.Messaging.Email.emailFrom,
            to: mailSettings.emailTo,
            subject: mailSettings.emailSubject,
            html: htmlStart + htmlMiddle + htmlEnd,
            attachments: attachments
        });
    }
}
exports.EmailMessenger = EmailMessenger;

//# sourceMappingURL=EmailMessenger.js.map
