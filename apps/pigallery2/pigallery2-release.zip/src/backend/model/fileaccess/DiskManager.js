"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiskManager = void 0;
const tslib_1 = require("tslib");
const fs_1 = require("fs");
const path = require("path");
const ProjectPath_1 = require("../../ProjectPath");
const Config_1 = require("../../../common/config/private/Config");
const Logger_1 = require("../../Logger");
const VideoProcessing_1 = require("./fileprocessing/VideoProcessing");
const PhotoProcessing_1 = require("./fileprocessing/PhotoProcessing");
const Utils_1 = require("../../../common/Utils");
const GPXProcessing_1 = require("./fileprocessing/GPXProcessing");
const MetadataLoader_1 = require("./MetadataLoader");
const NotifocationManager_1 = require("../NotifocationManager");
const ExtensionDecorator_1 = require("../extension/ExtensionDecorator");
const SessionManager_1 = require("../database/SessionManager");
const LOG_TAG = '[DiskManager]';
class DiskManager {
    static calcLastModified(stat) {
        return Math.max(stat.ctime.getTime(), stat.mtime.getTime());
    }
    static normalizeDirPath(dirPath) {
        return path.normalize(path.join('.' + path.sep, dirPath));
    }
    static pathFromRelativeDirName(relativeDirectoryName) {
        return path.join(path.dirname(this.normalizeDirPath(relativeDirectoryName)), path.sep);
    }
    static pathFromParent(parent) {
        return path.join(this.normalizeDirPath(path.join(parent.path, parent.name)), path.sep);
    }
    static dirName(dirPath) {
        if (dirPath.trim().length === 0) {
            return '.';
        }
        return path.basename(dirPath);
    }
    static async excludeDir(dir) {
        if (Config_1.Config.Indexing.excludeFolderList.length === 0 &&
            Config_1.Config.Indexing.excludeFileList.length === 0) {
            return false;
        }
        const absoluteName = path.normalize(path.join(dir.parentDirAbsoluteName, dir.name));
        const relativeName = path.normalize(path.join(dir.parentDirRelativeName, dir.name));
        for (const exclude of Config_1.Config.Indexing.excludeFolderList) {
            if (exclude.startsWith('/')) {
                if (exclude === absoluteName) {
                    return true;
                }
            }
            else if (exclude.includes('/')) {
                if (path.normalize(exclude) === relativeName) {
                    return true;
                }
            }
            else {
                if (exclude === dir.name) {
                    return true;
                }
            }
        }
        // exclude dirs that have the given files (like .ignore)
        for (const exclude of Config_1.Config.Indexing.excludeFileList) {
            try {
                await fs_1.promises.access(path.join(absoluteName, exclude));
                return true;
            }
            catch (e) {
                // ignoring errors
            }
        }
        return false;
    }
    static async scanDirectoryNoMetadata(relativeDirectoryName, settings = {}) {
        settings.noMetadata = true;
        return (await this.scanDirectory(relativeDirectoryName, settings));
    }
    static async scanDirectory(relativeDirectoryName, settings = {}) {
        Logger_1.Logger.silly(LOG_TAG, 'scanning directory:', relativeDirectoryName);
        relativeDirectoryName = this.normalizeDirPath(relativeDirectoryName);
        const directoryName = DiskManager.dirName(relativeDirectoryName);
        const directoryParent = this.pathFromRelativeDirName(relativeDirectoryName);
        const absoluteDirectoryName = path.join(ProjectPath_1.ProjectPath.ImageFolder, relativeDirectoryName);
        const stat = await fs_1.promises.stat(path.join(ProjectPath_1.ProjectPath.ImageFolder, relativeDirectoryName));
        const directory = {
            id: null,
            parent: null,
            name: directoryName,
            path: directoryParent,
            lastModified: this.calcLastModified(stat),
            directories: [],
            isPartial: settings.coverOnly === true,
            media: [],
            metaFile: [],
            cache: {
                projectionKey: SessionManager_1.SessionManager.NO_PROJECTION_KEY,
                mediaCount: 0,
                cover: null,
                valid: false
            }
        };
        if (!settings.coverOnly) {
            directory.lastScanned = Date.now();
        }
        // nothing to scan, we are here for the empty dir
        if (settings.noPhoto === true &&
            settings.noMetaFile === true &&
            settings.noVideo === true) {
            return directory;
        }
        const list = await fs_1.promises.readdir(absoluteDirectoryName);
        for (const file of list) {
            const fullFilePath = path.normalize(path.join(absoluteDirectoryName, file));
            if ((await fs_1.promises.stat(fullFilePath)).isDirectory()) {
                try {
                    if (settings.noDirectory === true ||
                        settings.coverOnly === true ||
                        (await DiskManager.excludeDir({
                            name: file,
                            parentDirRelativeName: relativeDirectoryName,
                            parentDirAbsoluteName: absoluteDirectoryName
                        }))) {
                        continue;
                    }
                    // create cover directory
                    const d = (await DiskManager.scanDirectory(path.join(relativeDirectoryName, file), {
                        coverOnly: true,
                    }));
                    directory.directories.push(d);
                }
                catch (err) {
                    NotifocationManager_1.NotificationManager.warning('Unknown directory reading error, skipping: ' + path.join(relativeDirectoryName, file), err.toString());
                    console.error(err);
                }
            }
            else if (PhotoProcessing_1.PhotoProcessing.isPhoto(fullFilePath)) {
                try {
                    if (settings.noPhoto === true) {
                        continue;
                    }
                    const photo = {
                        name: file,
                        directory: null,
                        metadata: settings.noMetadata === true
                            ? null
                            : await MetadataLoader_1.MetadataLoader.loadPhotoMetadata(fullFilePath),
                    };
                    if (!directory.cache.cover) {
                        directory.cache.cover = Utils_1.Utils.clone(photo);
                        directory.cache.cover.directory = {
                            path: directory.path,
                            name: directory.name,
                        };
                    }
                    // add the cover photo to the list of media, so it will be saved to the DB
                    // and can be queried to populate covers,
                    // otherwise we do not return media list that is only partial
                    directory.media.push(photo);
                    if (settings.coverOnly === true) {
                        break;
                    }
                }
                catch (err) {
                    NotifocationManager_1.NotificationManager.warning('Media loading error, skipping: ' +
                        fullFilePath +
                        ', reason: ' +
                        err.toString());
                    console.error(err);
                }
            }
            else if (VideoProcessing_1.VideoProcessing.isVideo(fullFilePath)) {
                try {
                    if (Config_1.Config.Media.Video.enabled === false ||
                        settings.noVideo === true ||
                        settings.coverOnly === true) {
                        continue;
                    }
                    directory.media.push({
                        name: file,
                        directory: null,
                        metadata: settings.noMetadata === true
                            ? null
                            : await MetadataLoader_1.MetadataLoader.loadVideoMetadata(fullFilePath),
                    });
                }
                catch (e) {
                    Logger_1.Logger.warn('Media loading error, skipping: ' +
                        fullFilePath +
                        ', reason: ' +
                        e.toString());
                }
            }
            else if (GPXProcessing_1.GPXProcessing.isMetaFile(fullFilePath)) {
                try {
                    if (!DiskManager.isEnabledMetaFile(fullFilePath) ||
                        settings.noMetaFile === true ||
                        settings.coverOnly === true) {
                        continue;
                    }
                    directory.metaFile.push({
                        name: file,
                        directory: null,
                    });
                }
                catch (e) {
                    Logger_1.Logger.warn('Metafile loading error, skipping: ' +
                        fullFilePath +
                        ', reason: ' +
                        e.toString());
                }
            }
        }
        directory.cache.mediaCount = directory.media.length;
        if (!directory.isPartial) {
            directory.cache.youngestMedia = Number.MAX_SAFE_INTEGER;
            directory.cache.oldestMedia = Number.MIN_SAFE_INTEGER;
            directory.media.forEach((m) => {
                directory.cache.youngestMedia = Math.min(Utils_1.Utils.getTimeMS(m.metadata.creationDate, m.metadata.creationDateOffset, Config_1.Config.Gallery.ignoreTimestampOffset), directory.cache.youngestMedia);
                directory.cache.oldestMedia = Math.max(Utils_1.Utils.getTimeMS(m.metadata.creationDate, m.metadata.creationDateOffset, Config_1.Config.Gallery.ignoreTimestampOffset), directory.cache.oldestMedia);
            });
            directory.metaFile.forEach(mf => {
                if (DiskManager.isMarkdown(mf.name)) {
                    mf.date = directory.cache.youngestMedia;
                }
            });
        }
        return directory;
    }
    static isEnabledMetaFile(fullPath) {
        const extension = path.extname(fullPath).toLowerCase();
        switch (extension) {
            case '.gpx':
                return Config_1.Config.MetaFile.gpx;
            case '.md':
                return Config_1.Config.MetaFile.markdown;
            case '.pg2conf':
                return Config_1.Config.MetaFile.pg2conf;
        }
        return false;
    }
    static isMarkdown(fullPath) {
        const extension = path.extname(fullPath).toLowerCase();
        return extension == '.md';
    }
}
exports.DiskManager = DiskManager;
tslib_1.__decorate([
    (0, ExtensionDecorator_1.ExtensionDecorator)(e => e.gallery.DiskManager.excludeDir),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], DiskManager, "excludeDir", null);
tslib_1.__decorate([
    (0, ExtensionDecorator_1.ExtensionDecorator)(e => e.gallery.DiskManager.scanDirectory),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], DiskManager, "scanDirectory", null);

//# sourceMappingURL=DiskManager.js.map
