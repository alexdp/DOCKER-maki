"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PhotoProcessing = void 0;
const path = require("path");
const fs_1 = require("fs");
const os = require("os");
const crypto = require("crypto");
const ProjectPath_1 = require("../../../ProjectPath");
const Config_1 = require("../../../../common/config/private/Config");
const PhotoWorker_1 = require("../PhotoWorker");
const TaskExecuter_1 = require("../TaskExecuter");
const SupportedFormats_1 = require("../../../../common/SupportedFormats");
class PhotoProcessing {
    static { this.initDone = false; }
    static { this.taskQue = null; }
    static { this.CONVERTED_EXTENSION = '.webp'; }
    static init() {
        if (this.initDone === true) {
            return;
        }
        Config_1.Config.Media.Photo.concurrentThumbnailGenerations = Math.max(1, os.cpus().length - 1);
        this.taskQue = new TaskExecuter_1.TaskExecuter(Config_1.Config.Media.Photo.concurrentThumbnailGenerations, (input) => PhotoWorker_1.PhotoWorker.render(input));
        this.initDone = true;
    }
    static async generatePersonThumbnail(person) {
        // load parameters
        const photo = person.cache.sampleRegion.media;
        const mediaPath = path.join(ProjectPath_1.ProjectPath.ImageFolder, photo.directory.path, photo.directory.name, photo.name);
        const size = Config_1.Config.Media.Photo.personThumbnailSize;
        const faceRegion = person.cache.sampleRegion.media.metadata.faces.find(f => f.name === person.name);
        // generate thumbnail path
        const thPath = PhotoProcessing.generatePersonThumbnailPath(mediaPath, faceRegion, size);
        // check if thumbnail already exist
        try {
            await fs_1.promises.access(thPath, fs_1.constants.R_OK);
            return thPath;
        }
        catch (e) {
            // ignoring errors
        }
        const margin = {
            x: Math.round(faceRegion.box.width *
                Config_1.Config.Media.Photo.personFaceMargin),
            y: Math.round(faceRegion.box.height *
                Config_1.Config.Media.Photo.personFaceMargin),
        };
        // run on other thread
        const input = {
            type: PhotoWorker_1.ThumbnailSourceType.Photo,
            mediaPath,
            size,
            outPath: thPath,
            makeSquare: false,
            cut: {
                left: Math.round(Math.max(0, faceRegion.box.left - margin.x / 2)),
                top: Math.round(Math.max(0, faceRegion.box.top - margin.y / 2)),
                width: faceRegion.box.width + margin.x,
                height: faceRegion.box.height + margin.y,
            },
            useLanczos3: Config_1.Config.Media.Photo.useLanczos3,
            quality: Config_1.Config.Media.Photo.quality,
            smartSubsample: Config_1.Config.Media.Photo.smartSubsample,
        };
        input.cut.width = Math.min(input.cut.width, photo.metadata.size.width - input.cut.left);
        input.cut.height = Math.min(input.cut.height, photo.metadata.size.height - input.cut.top);
        await fs_1.promises.mkdir(ProjectPath_1.ProjectPath.FacesFolder, { recursive: true });
        await PhotoProcessing.taskQue.execute(input);
        return thPath;
    }
    static generateConvertedPath(mediaPath, size) {
        const file = path.basename(mediaPath);
        const animated = Config_1.Config.Media.Photo.animateGif && path.extname(mediaPath).toLowerCase() == '.gif';
        return path.join(ProjectPath_1.ProjectPath.TranscodedFolder, ProjectPath_1.ProjectPath.getRelativePathToImages(path.dirname(mediaPath)), file + '_' + size + 'q' + Config_1.Config.Media.Photo.quality +
            (animated ? 'anim' : '') +
            (Config_1.Config.Media.Photo.smartSubsample ? 'cs' : '') +
            PhotoProcessing.CONVERTED_EXTENSION);
    }
    static generatePersonThumbnailPath(mediaPath, faceRegion, size) {
        return path.join(ProjectPath_1.ProjectPath.FacesFolder, crypto
            .createHash('md5')
            .update(mediaPath +
            '_' +
            faceRegion.name +
            '_' +
            faceRegion.box.left +
            '_' +
            faceRegion.box.top)
            .digest('hex') +
            '_' +
            size +
            '_' + Config_1.Config.Media.Photo.personFaceMargin +
            PhotoProcessing.CONVERTED_EXTENSION);
    }
    /**
     * Tells if the path is valid with the current config
     * @param convertedPath
     */
    static async isValidConvertedPath(convertedPath) {
        const origFilePath = path.join(ProjectPath_1.ProjectPath.ImageFolder, path.relative(ProjectPath_1.ProjectPath.TranscodedFolder, convertedPath.substring(0, convertedPath.lastIndexOf('_'))));
        if (path.extname(convertedPath) !== PhotoProcessing.CONVERTED_EXTENSION) {
            return false;
        }
        let nextIndex = convertedPath.lastIndexOf('_') + 1;
        const sizeStr = convertedPath.substring(nextIndex, convertedPath.lastIndexOf('q'));
        nextIndex = convertedPath.lastIndexOf('q') + 1;
        const size = parseInt(sizeStr, 10);
        if ((size + '').length !== sizeStr.length ||
            (Config_1.Config.Media.Photo.thumbnailSizes.indexOf(size) === -1)) {
            return false;
        }
        const qualityStr = convertedPath.substring(nextIndex, nextIndex + convertedPath.substring(nextIndex).search(/[A-Za-z]/)); // end of quality string
        const quality = parseInt(qualityStr, 10);
        if ((quality + '').length !== qualityStr.length ||
            quality !== Config_1.Config.Media.Photo.quality) {
            return false;
        }
        nextIndex += qualityStr.length;
        const lowerExt = path.extname(origFilePath).toLowerCase();
        const shouldBeAnimated = Config_1.Config.Media.Photo.animateGif && lowerExt == '.gif';
        if (shouldBeAnimated) {
            if (convertedPath.substring(nextIndex, nextIndex + 'anim'.length) != 'anim') {
                return false;
            }
            nextIndex += 'anim'.length;
        }
        if (Config_1.Config.Media.Photo.smartSubsample) {
            if (convertedPath.substring(nextIndex, nextIndex + 2) != 'cs') {
                return false;
            }
            nextIndex += 2;
        }
        if (convertedPath.substring(nextIndex).toLowerCase() !== path.extname(convertedPath)) {
            return false;
        }
        try {
            await fs_1.promises.access(origFilePath, fs_1.constants.R_OK);
        }
        catch (e) {
            return false;
        }
        return true;
    }
    static async convertedPhotoExist(mediaPath, size) {
        // generate thumbnail path
        const outPath = PhotoProcessing.generateConvertedPath(mediaPath, size);
        // check if file already exist
        try {
            await fs_1.promises.access(outPath, fs_1.constants.R_OK);
            return true;
        }
        catch (e) {
            // ignoring errors
        }
        return false;
    }
    static async generateThumbnail(mediaPath, size, sourceType, makeSquare) {
        // generate thumbnail path
        const outPath = PhotoProcessing.generateConvertedPath(mediaPath, size);
        // check if file already exist
        try {
            await fs_1.promises.access(outPath, fs_1.constants.R_OK);
            return outPath;
        }
        catch (e) {
            // ignoring errors
        }
        // run on other thread
        const input = {
            type: sourceType,
            mediaPath,
            size,
            outPath,
            makeSquare,
            useLanczos3: Config_1.Config.Media.Photo.useLanczos3,
            quality: Config_1.Config.Media.Photo.quality,
            smartSubsample: Config_1.Config.Media.Photo.smartSubsample,
            sharpOptions: Config_1.Config.Media.Photo.sharpOptions,
            animate: Config_1.Config.Media.Photo.animateGif
        };
        const outDir = path.dirname(input.outPath);
        await fs_1.promises.mkdir(outDir, { recursive: true });
        await this.taskQue.execute(input);
        return outPath;
    }
    static isPhoto(fullPath) {
        const extension = path.extname(fullPath).toLowerCase();
        return SupportedFormats_1.SupportedFormats.WithDots.Photos.indexOf(extension) !== -1;
    }
    static async renderSVG(svgIcon, outPath, color = '#000') {
        // Generate hash from SVG content and color to create unique filename
        const contentHash = crypto
            .createHash('md5')
            .update(JSON.stringify(svgIcon) + color)
            .digest('hex')
            .substring(0, 8);
        // Update outPath to include hash
        const ext = path.extname(outPath);
        const baseName = path.basename(outPath, ext);
        const dir = path.dirname(outPath);
        const hashedOutPath = path.join(dir, `${baseName}_${contentHash}${ext}`);
        // check if file already exist
        try {
            await fs_1.promises.access(hashedOutPath, fs_1.constants.R_OK);
            return hashedOutPath;
        }
        catch (e) {
            // ignoring errors
        }
        const size = 256;
        // run on other thread
        const input = {
            type: PhotoWorker_1.ThumbnailSourceType.Photo,
            svgString: `<svg fill="${color}" width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg"
viewBox="${svgIcon.viewBox || '0 0 512 512'}">d="${svgIcon.items}</svg>`,
            size: size,
            outPath: hashedOutPath,
            makeSquare: false,
            animate: false,
            useLanczos3: Config_1.Config.Media.Photo.useLanczos3,
            quality: Config_1.Config.Media.Photo.quality,
            smartSubsample: Config_1.Config.Media.Photo.smartSubsample,
        };
        const outDir = path.dirname(input.outPath);
        await fs_1.promises.mkdir(outDir, { recursive: true });
        await this.taskQue.execute(input);
        return hashedOutPath;
    }
}
exports.PhotoProcessing = PhotoProcessing;

//# sourceMappingURL=PhotoProcessing.js.map
