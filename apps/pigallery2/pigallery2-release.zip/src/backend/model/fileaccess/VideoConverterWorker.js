"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoConverterWorker = void 0;
const tslib_1 = require("tslib");
const Logger_1 = require("../../Logger");
const fs_1 = require("fs");
const FFmpegFactory_1 = require("../FFmpegFactory");
const PrivateConfig_1 = require("../../../common/config/private/PrivateConfig");
const ExtensionDecorator_1 = require("../extension/ExtensionDecorator");
class VideoConverterWorker {
    static { this.ffmpeg = FFmpegFactory_1.FFmpegFactory.get(); }
    static async convert(input) {
        const origPath = input.output.path;
        input.output.path = origPath + '.part';
        await this._convert(input);
        await fs_1.promises.rename(input.output.path, origPath);
    }
    static _convert(input) {
        if (this.ffmpeg == null) {
            this.ffmpeg = FFmpegFactory_1.FFmpegFactory.get();
        }
        return new Promise((resolve, reject) => {
            Logger_1.Logger.silly('[FFmpeg] transcoding video: ' + input.videoPath);
            const command = this.ffmpeg(input.videoPath);
            let executedCmd = '';
            command
                .on('start', (cmd) => {
                Logger_1.Logger.silly('[FFmpeg] running:' + cmd);
                executedCmd = cmd;
            })
                .on('end', () => {
                resolve();
            })
                .on('error', (e) => {
                reject('[FFmpeg] ' + e.toString() + ' executed: ' + executedCmd);
            })
                .on('stderr', function (line) {
                // Although this is under `stderr` event, all of ffmpeg output come here.
                Logger_1.Logger.debug('[FFmpeg] ' + line);
            });
            // set custom input options
            if (input.input.customOptions) {
                command.inputOptions(input.input.customOptions);
            }
            // set video bitrate
            if (input.output.bitRate) {
                command.videoBitrate(input.output.bitRate / 1024 + 'k');
            }
            // set target codec
            command.videoCodec(input.output.codec);
            if (input.output.resolution) {
                command.size('?x' + input.output.resolution);
            }
            // set fps
            if (input.output.fps) {
                command.fps(input.output.fps);
            }
            // set Constant Rate Factor (CRF)
            if (input.output.crf) {
                command.addOption(['-crf ' + input.output.crf]);
            }
            // set preset
            if (input.output.preset) {
                command.addOption(['-preset ' + PrivateConfig_1.FFmpegPresets[input.output.preset]]);
            }
            // set any additional commands
            if (input.output.customOptions) {
                command.addOption(input.output.customOptions);
            }
            // set output format to force
            command
                .format(input.output.format)
                // save to file
                .save(input.output.path);
        });
    }
}
exports.VideoConverterWorker = VideoConverterWorker;
tslib_1.__decorate([
    (0, ExtensionDecorator_1.ExtensionDecorator)(e => e.gallery.VideoConverter.convert),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], VideoConverterWorker, "convert", null);

//# sourceMappingURL=VideoConverterWorker.js.map
