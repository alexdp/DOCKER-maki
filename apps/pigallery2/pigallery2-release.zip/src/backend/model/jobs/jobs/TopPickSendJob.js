"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TopPickSendJob = void 0;
const JobDTO_1 = require("../../../../common/entities/job/JobDTO");
const Job_1 = require("./Job");
const BackendTexts_1 = require("../../../../common/BackendTexts");
const SortingMethods_1 = require("../../../../common/entities/SortingMethods");
const SearchQueryDTO_1 = require("../../../../common/entities/SearchQueryDTO");
const ObjectManagers_1 = require("../../ObjectManagers");
const MediaDTO_1 = require("../../../../common/entities/MediaDTO");
const MessengerRepository_1 = require("../../messenger/MessengerRepository");
const Utils_1 = require("../../../../common/Utils");
const SessionContext_1 = require("../../SessionContext");
class TopPickSendJob extends Job_1.Job {
    constructor() {
        super();
        this.Name = JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Top Pick Sending']];
        this.Supported = true;
        this.status = 'Listing';
        this.mediaList = [];
        this.ConfigTemplate = [
            {
                id: 'mediaPick',
                type: 'MediaPickDTO-array',
                name: BackendTexts_1.backendTexts.mediaPick.name,
                description: BackendTexts_1.backendTexts.mediaPick.description,
                defaultValue: [{
                        searchQuery: {
                            type: SearchQueryDTO_1.SearchQueryTypes.date_pattern,
                            daysLength: 7,
                            frequency: SearchQueryDTO_1.DatePatternFrequency.every_year
                        },
                        sortBy: [{ method: SortingMethods_1.SortByTypes.Rating, ascending: false },
                            { method: SortingMethods_1.SortByTypes.PersonCount, ascending: false }],
                        pick: 5
                    }],
            }, {
                id: 'messenger',
                type: 'messenger',
                name: BackendTexts_1.backendTexts.messenger.name,
                description: BackendTexts_1.backendTexts.messenger.description,
                defaultValue: JobDTO_1.DefaultMessengers[JobDTO_1.DefaultMessengers.Email]
            }
        ];
        // add all messenger's config to the config template
        MessengerRepository_1.MessengerRepository.Instance.getAll()
            .forEach(msgr => Utils_1.Utils.clone(msgr.ConfigTemplate)
            .forEach(ct => {
            const c = Utils_1.Utils.clone(ct);
            c.validIf = { configFiled: 'messenger', equalsValue: msgr.Name };
            this.ConfigTemplate.push(c);
        }));
    }
    async init() {
        this.status = 'Listing';
        this.mediaList = [];
        this.Progress.Left = 2;
    }
    async step() {
        switch (this.status) {
            case 'Listing':
                if (!await this.stepListing()) {
                    this.status = 'Sending';
                }
                return true;
            case 'Sending':
                await this.stepSending();
        }
        return false;
    }
    async stepListing() {
        this.Progress.log('Collecting Photos and videos to Send.');
        this.mediaList = [];
        for (let i = 0; i < this.config.mediaPick.length; ++i) {
            let session = new SessionContext_1.SessionContext();
            if (this.config.mediaPick[i].creatorId) {
                const u = await ObjectManagers_1.ObjectManagers.getInstance().UserManager.findOne({ id: this.config.mediaPick[i].creatorId });
                session = await ObjectManagers_1.ObjectManagers.getInstance().SessionManager.buildContext(u);
            }
            const media = await ObjectManagers_1.ObjectManagers.getInstance().SearchManager
                .getNMedia(session, this.config.mediaPick[i].searchQuery, this.config.mediaPick[i].sortBy, this.config.mediaPick[i].pick);
            this.Progress.log('Find ' + media.length + ' photos and videos from ' + (i + 1) + '. load');
            this.mediaList = this.mediaList.concat(media);
        }
        // make the list unique
        this.mediaList = this.mediaList
            .filter((value, index, arr) => arr.findIndex(m => MediaDTO_1.MediaDTOUtils.equals(m, value)) === index);
        this.Progress.Processed++;
        return false;
    }
    async stepSending() {
        if (this.mediaList.length <= 0) {
            this.Progress.log('No photos found skipping sending.');
            this.Progress.Skipped++;
            return false;
        }
        const msgr = MessengerRepository_1.MessengerRepository.Instance.get(this.config.messenger);
        if (!msgr) {
            throw new Error('Can\t find "' + this.config.messenger + '" messenger.');
        }
        this.Progress.log('Sending ' + this.mediaList.length + ' photos.');
        await msgr.send(this.config, this.mediaList);
        this.Progress.Processed++;
        return false;
    }
}
exports.TopPickSendJob = TopPickSendJob;

//# sourceMappingURL=TopPickSendJob.js.map
