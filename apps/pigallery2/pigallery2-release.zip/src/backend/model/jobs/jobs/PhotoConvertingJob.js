"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PhotoConvertingJob = void 0;
const Config_1 = require("../../../../common/config/private/Config");
const JobDTO_1 = require("../../../../common/entities/job/JobDTO");
const FileJob_1 = require("./FileJob");
const PhotoProcessing_1 = require("../../fileaccess/fileprocessing/PhotoProcessing");
const PhotoWorker_1 = require("../../fileaccess/PhotoWorker");
const MediaDTO_1 = require("../../../../common/entities/MediaDTO");
const BackendTexts_1 = require("../../../../common/BackendTexts");
class PhotoConvertingJob extends FileJob_1.FileJob {
    constructor() {
        super({ noMetaFile: true });
        this.Name = JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Photo Converting']];
        this.ConfigTemplate.push({
            id: 'sizes',
            type: 'number-array',
            name: BackendTexts_1.backendTexts.sizeToGenerate.name,
            description: BackendTexts_1.backendTexts.sizeToGenerate.description,
            defaultValue: [Config_1.Config.Media.Photo.thumbnailSizes[0]],
        }, {
            id: 'maxVideoSize',
            type: 'number',
            name: BackendTexts_1.backendTexts.maxVideoSize.name,
            description: BackendTexts_1.backendTexts.maxVideoSize.description,
            defaultValue: 800,
        });
    }
    get Supported() {
        return true;
    }
    start(config, soloRun = false, allowParallelRun = false) {
        if (!config || !config.sizes || !Array.isArray(config.sizes) || config.sizes.length === 0) {
            config = config || {};
            config.sizes = this.ConfigTemplate.find(ct => ct.id == 'sizes').defaultValue;
        }
        for (const item of config.sizes) {
            if (Config_1.Config.Media.Photo.thumbnailSizes.indexOf(item) === -1) {
                throw new Error('unknown thumbnails size: ' +
                    item +
                    '. Add it to the possible thumbnail sizes.');
            }
        }
        return super.start(config, soloRun, allowParallelRun);
    }
    async filterMediaFiles(files) {
        return files;
    }
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    async filterMetaFiles(files) {
        return undefined;
    }
    async shouldProcess(mPath) {
        for (const item of this.config.sizes) {
            if (!(await PhotoProcessing_1.PhotoProcessing.convertedPhotoExist(mPath, item))) {
                return true;
            }
        }
        return false;
    }
    async processFile(mPath) {
        const isVideo = MediaDTO_1.MediaDTOUtils.isVideoPath(mPath);
        for (const item of this.config.sizes) {
            // skip hig- res photo creation for video files. App does not use photo preview fore videos in the lightbox
            if (this.config.maxVideoSize < item && isVideo) {
                continue;
            }
            await PhotoProcessing_1.PhotoProcessing.generateThumbnail(mPath, item, isVideo
                ? PhotoWorker_1.ThumbnailSourceType.Video
                : PhotoWorker_1.ThumbnailSourceType.Photo, false);
        }
    }
}
exports.PhotoConvertingJob = PhotoConvertingJob;

//# sourceMappingURL=PhotoConvertingJob.js.map
