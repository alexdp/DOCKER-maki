"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JobProgressManager = void 0;
const fs_1 = require("fs");
const path = require("path");
const ProjectPath_1 = require("../../ProjectPath");
const Config_1 = require("../../../common/config/private/Config");
const JobProgressDTO_1 = require("../../../common/entities/job/JobProgressDTO");
class JobProgressManager {
    static { this.VERSION = 3; }
    constructor() {
        this.db = {
            version: JobProgressManager.VERSION,
            progresses: {},
        };
        this.timer = null;
        this.dbPath = path.join(ProjectPath_1.ProjectPath.DBFolder, 'jobs.db');
        this.loadDB().catch(console.error);
    }
    get Progresses() {
        const m = {};
        for (const key of Object.keys(this.db.progresses)) {
            m[key] = this.db.progresses[key].progress;
            if (this.db.progresses[key].progress.state === JobProgressDTO_1.JobProgressStates.running) {
                m[key].time.end = Date.now();
            }
        }
        return m;
    }
    onJobProgressUpdate(progress) {
        this.db.progresses[progress.HashName] = { progress, timestamp: Date.now() };
        this.delayedSave();
    }
    async loadDB() {
        try {
            await fs_1.promises.access(this.dbPath);
        }
        catch (e) {
            return;
        }
        const data = await fs_1.promises.readFile(this.dbPath, 'utf8');
        const db = JSON.parse(data);
        if (db.version !== JobProgressManager.VERSION) {
            return;
        }
        this.db = db;
        while (Object.keys(this.db.progresses).length >
            Config_1.Config.Jobs.maxSavedProgress) {
            let min = null;
            for (const key of Object.keys(this.db.progresses)) {
                if (min === null ||
                    this.db.progresses[min].timestamp > this.db.progresses[key].timestamp) {
                    min = key;
                }
            }
            delete this.db.progresses[min];
        }
        for (const key of Object.keys(this.db.progresses)) {
            if (this.db.progresses[key].progress.state === JobProgressDTO_1.JobProgressStates.running ||
                this.db.progresses[key].progress.state === JobProgressDTO_1.JobProgressStates.cancelling) {
                this.db.progresses[key].progress.state = JobProgressDTO_1.JobProgressStates.interrupted;
            }
        }
    }
    async saveDB() {
        await fs_1.promises.writeFile(this.dbPath, JSON.stringify(this.db));
    }
    delayedSave() {
        if (this.timer !== null) {
            return;
        }
        this.timer = setTimeout(async () => {
            this.saveDB().catch(console.error);
            this.timer = null;
        }, 5000);
    }
}
exports.JobProgressManager = JobProgressManager;

//# sourceMappingURL=JobProgressManager.js.map
