"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Server = void 0;
const Config_1 = require("../common/config/private/Config");
const express = require("express");
const cookieParser = require("cookie-parser");
const _http = require("http");
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
const locale = require("locale");
const ObjectManagers_1 = require("./model/ObjectManagers");
const Logger_1 = require("./Logger");
const LoggerRouter_1 = require("./routes/LoggerRouter");
const ConfigDiagnostics_1 = require("./model/diagnostics/ConfigDiagnostics");
const Localizations_1 = require("./model/Localizations");
const CookieNames_1 = require("../common/CookieNames");
const Router_1 = require("./routes/Router");
const PhotoProcessing_1 = require("./model/fileaccess/fileprocessing/PhotoProcessing");
const Event_1 = require("../common/event/Event");
const QueryParams_1 = require("../common/QueryParams");
const node_1 = require("typeconfig/node");
// eslint-disable-next-line @typescript-eslint/no-require-imports
const session = require('cookie-session');
const LOG_TAG = '[server]';
class Server {
    static { this.instance = null; }
    static getInstance() {
        if (!this.instance) {
            this.instance = new Server();
        }
        return this.instance;
    }
    constructor(listen = true) {
        this.onStarted = new Event_1.Event();
        this.SIGTERM = () => {
            Logger_1.Logger.info(LOG_TAG, 'SIGTERM signal received');
            this.server.close(() => {
                process.exit(0);
            });
        };
        /**
         *
         * Event listener for HTTP server "error" event.
         */
        this.onError = (error) => {
            if (error.syscall !== 'listen') {
                Logger_1.Logger.error(LOG_TAG, 'Server error', error);
                throw error;
            }
            const bind = Config_1.Config.Server.host + ':' + Config_1.Config.Server.port;
            // handle specific listen error with friendly messages
            switch (error.code) {
                case 'EACCES':
                    Logger_1.Logger.error(LOG_TAG, bind + ' requires elevated privileges');
                    process.exit(1);
                    break;
                case 'EADDRINUSE':
                    Logger_1.Logger.error(LOG_TAG, bind + ' is already in use');
                    process.exit(1);
                    break;
                default:
                    throw error;
            }
        };
        /**
         * Event listener for HTTP server "listening" event.
         */
        this.onListening = () => {
            const addr = this.server.address();
            const bind = typeof addr === 'string' ? 'pipe ' + addr : 'port ' + addr.port;
            Logger_1.Logger.info(LOG_TAG, 'Listening on ' + bind);
            this.onStarted.trigger();
        };
        /**
         * Event listener for HTTP server "close" event.
         */
        this.onClose = () => {
            Logger_1.Logger.info(LOG_TAG, 'Closed http server');
        };
        if (!(process.env.NODE_ENV === 'production')) {
            Logger_1.Logger.info(LOG_TAG, 'Running in DEBUG mode, set env variable NODE_ENV=production to disable ');
        }
        this.init(listen).catch(console.error);
    }
    get Server() {
        return this.server;
    }
    async init(listen = true) {
        this.app = express();
        LoggerRouter_1.LoggerRouter.route(this.app);
        this.app.set('view engine', 'ejs');
        Logger_1.Logger.info(LOG_TAG, 'running diagnostics...');
        await ConfigDiagnostics_1.ConfigDiagnostics.runDiagnostics();
        Logger_1.Logger.verbose(LOG_TAG, () => 'using config from ' +
            node_1.ConfigClassBuilder.attachPrivateInterface(Config_1.Config)
                .__options.configPath +
            ':');
        Logger_1.Logger.verbose(LOG_TAG, () => JSON.stringify(Config_1.Config.toJSON({ attachDescription: false }), (k, v) => {
            const MAX_LENGTH = 80;
            if (typeof v === 'string' && v.length > MAX_LENGTH) {
                v = v.slice(0, MAX_LENGTH - 3) + '...';
            }
            return v;
        }, 2));
        /**
         * Session above all
         */
        this.app.use(session({
            name: CookieNames_1.CookieNames.session,
            keys: Config_1.Config.Server.sessionSecret,
        }));
        /**
         * Parse parameters in POST
         */
        // for parsing application/json
        this.app.use(express.json());
        this.app.use(cookieParser());
        // enable token generation but do not check it
        this.app.post([Config_1.Config.Server.apiPath + '/user/login', Config_1.Config.Server.apiPath + '/share/login']);
        this.app.get([Config_1.Config.Server.apiPath + '/user/me', Config_1.Config.Server.apiPath + '/share/:' + QueryParams_1.QueryParams.gallery.sharingKey_params]);
        PhotoProcessing_1.PhotoProcessing.init();
        Localizations_1.Localizations.init();
        this.app.use(locale(Config_1.Config.Server.languages, 'en'));
        await ObjectManagers_1.ObjectManagers.getInstance().init();
        Router_1.Router.route(this.app);
        // Get PORT from environment and store in Express.
        this.app.set('port', Config_1.Config.Server.port);
        // Set express 'trust proxy' setting to extract Remote Client IP
        // from optional reverse proxies trusted headers
        // See https://expressjs.com/en/guide/behind-proxies.html
        this.app.set('trust proxy', Server.getAppTrustProxyConfig());
        // Create HTTP server.
        this.server = _http.createServer(this.app);
        // Listen on provided PORT, on all network interfaces.
        if (listen) {
            this.server.listen(Config_1.Config.Server.port, Config_1.Config.Server.host);
        }
        this.server.on('error', this.onError);
        this.server.on('listening', this.onListening);
        this.server.on('close', this.onClose);
        // Sigterm handler
        process.removeAllListeners('SIGTERM');
        process.on('SIGTERM', this.SIGTERM);
        if (!listen) {
            this.onStarted.trigger();
        }
    }
    static getAppTrustProxyConfig() {
        const trustProxyValue = Config_1.Config.Server.trustProxy;
        switch (trustProxyValue) {
            case "true":
                return true;
                break;
            case "false":
                return false;
                break;
            default:
                if (/^\d+$/.test(trustProxyValue)) {
                    return Number(trustProxyValue);
                }
                return trustProxyValue;
        }
    }
    Stop() {
        return new Promise((resolve, reject) => {
            if (!this.server.listening) {
                return resolve();
            }
            this.server.close((err) => {
                if (!err) {
                    return resolve();
                }
                reject(err);
            });
        });
    }
}
exports.Server = Server;

//# sourceMappingURL=server.js.map
