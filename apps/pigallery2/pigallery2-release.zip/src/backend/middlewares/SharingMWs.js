"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SharingMWs = void 0;
const ObjectManagers_1 = require("../model/ObjectManagers");
const Error_1 = require("../../common/entities/Error");
const Config_1 = require("../../common/config/private/Config");
const QueryParams_1 = require("../../common/QueryParams");
const path = require("path");
const UserDTO_1 = require("../../common/entities/UserDTO");
const SearchQueryDTO_1 = require("../../common/entities/SearchQueryDTO");
const crypto = require("crypto");
class SharingMWs {
    static async getSharing(req, res, next) {
        try {
            if (Config_1.Config.Sharing.enabled === false) {
                return next();
            }
            const sharingKey = req.params[QueryParams_1.QueryParams.gallery.sharingKey_params];
            req.resultPipe =
                await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.findOne(sharingKey);
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during retrieving sharing link', err));
        }
    }
    static async getSharingKey(req, res, next) {
        try {
            if (Config_1.Config.Sharing.enabled === false) {
                return next();
            }
            const sharingKey = req.params[QueryParams_1.QueryParams.gallery.sharingKey_params];
            req.resultPipe =
                { sharingKey: (await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.findOne(sharingKey)).sharingKey };
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during retrieving sharing key', err));
        }
    }
    static async createSharing(req, res, next) {
        try {
            if (Config_1.Config.Sharing.enabled === false) {
                return next();
            }
            if (typeof req.body === 'undefined' ||
                typeof req.body.createSharing === 'undefined') {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'createSharing filed is missing'));
            }
            const createSharing = req.body.createSharing;
            if (Config_1.Config.Sharing.passwordRequired && !createSharing.password) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'Password is required.'));
            }
            let sharingKey = SharingMWs.generateKey(Config_1.Config.Sharing.sharingKeyLength);
            // create one not yet used
            // eslint-disable-next-line no-constant-condition
            while (true) {
                try {
                    await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.findOne(sharingKey);
                    sharingKey = this.generateKey(Config_1.Config.Sharing.sharingKeyLength);
                }
                catch (err) {
                    break;
                }
            }
            const directoryName = path.normalize(req.params['directory'] || '/');
            // Prefer provided searchQuery; otherwise fallback to strict directory exact-match query for compatibility
            const searchQuery = createSharing.searchQuery || {
                type: SearchQueryDTO_1.SearchQueryTypes.directory,
                text: directoryName,
                matchType: SearchQueryDTO_1.TextSearchQueryMatchTypes.exact_match,
                negate: false
            };
            const sharing = {
                id: null,
                sharingKey,
                searchQuery,
                password: createSharing.password,
                creator: req.session.context?.user,
                expires: createSharing.valid >= 0 // if === -1 it's forever
                    ? Date.now() + createSharing.valid
                    : new Date(9999, 0, 1).getTime(), // never expire
                timeStamp: Date.now(),
            };
            req.resultPipe =
                await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.createSharing(sharing);
            return next();
        }
        catch (err) {
            console.warn(err);
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during creating sharing link', err));
        }
    }
    static async updateSharing(req, res, next) {
        try {
            if (Config_1.Config.Sharing.enabled === false) {
                return next();
            }
            if (typeof req.body === 'undefined' ||
                typeof req.body.updateSharing === 'undefined') {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'updateSharing filed is missing'));
            }
            const updateSharing = req.body.updateSharing;
            const directoryName = path.normalize(req.params['directory'] || '/');
            const searchQuery = updateSharing.searchQuery || {
                type: SearchQueryDTO_1.SearchQueryTypes.directory,
                text: directoryName,
                matchType: SearchQueryDTO_1.TextSearchQueryMatchTypes.exact_match,
                negate: false
            };
            const sharing = {
                id: updateSharing.id,
                searchQuery,
                sharingKey: '',
                password: updateSharing.password && updateSharing.password !== ''
                    ? updateSharing.password
                    : null,
                creator: req.session.context?.user,
                expires: updateSharing.valid >= 0 // if === -1 its forever
                    ? Date.now() + updateSharing.valid
                    : new Date(9999, 0, 1).getTime(), // never expire
                timeStamp: Date.now(),
            };
            const forceUpdate = req.session.context.user.role >= UserDTO_1.UserRoles.Admin;
            req.resultPipe =
                await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.updateSharing(sharing, forceUpdate);
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during updating sharing link', err));
        }
    }
    static async deleteSharing(req, res, next) {
        try {
            if (Config_1.Config.Sharing.enabled === false) {
                return next();
            }
            if (typeof req.params === 'undefined' ||
                typeof req.params['sharingKey'] === 'undefined') {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'sharingKey is missing'));
            }
            const sharingKey = req.params['sharingKey'];
            // Check if user has the right to delete sharing.
            if (req.session.context?.user.role < UserDTO_1.UserRoles.Admin) {
                const s = await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.findOne(sharingKey);
                if (s.creator.id !== req.session.context?.user.id) {
                    return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.NOT_AUTHORISED, 'Can\'t delete sharing.'));
                }
            }
            req.resultPipe =
                await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.deleteSharing(sharingKey);
            req.resultPipe = 'ok';
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during deleting sharing', err));
        }
    }
    static async listSharing(req, res, next) {
        try {
            if (Config_1.Config.Sharing.enabled === false) {
                return next();
            }
            req.resultPipe =
                await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.listAll();
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during listing shares', err));
        }
    }
    static async listSharingForQuery(req, res, next) {
        try {
            if (Config_1.Config.Sharing.enabled === false) {
                return next();
            }
            if (!req.resultPipe) {
                return next();
            }
            const query = req.resultPipe;
            if (req.session.context?.user.role >= UserDTO_1.UserRoles.Admin) {
                req.resultPipe =
                    await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.listAllForQuery(query);
            }
            else {
                req.resultPipe =
                    await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.listAllForQuery(query, req.session.context?.user);
            }
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during listing shares', err));
        }
    }
    static generateKey(length) {
        return crypto.randomBytes(Math.ceil(length * 3 / 4))
            .toString('base64url')
            .slice(0, length);
    }
}
exports.SharingMWs = SharingMWs;

//# sourceMappingURL=SharingMWs.js.map
