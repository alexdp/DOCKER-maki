"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserMWs = void 0;
const Error_1 = require("../../../common/entities/Error");
const ObjectManagers_1 = require("../../model/ObjectManagers");
const Utils_1 = require("../../../common/Utils");
const Config_1 = require("../../../common/config/private/Config");
class UserMWs {
    static async createUser(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.USER_MANAGEMENT_DISABLED));
        }
        if (typeof req.body === 'undefined' ||
            typeof req.body.newUser === 'undefined') {
            return next();
        }
        try {
            await ObjectManagers_1.ObjectManagers.getInstance().UserManager.createUser(req.body.newUser);
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.USER_CREATION_ERROR, null, err));
        }
    }
    static async deleteUser(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.USER_MANAGEMENT_DISABLED));
        }
        if (typeof req.params === 'undefined' ||
            typeof req.params.id === 'undefined') {
            return next();
        }
        try {
            const deleted = await ObjectManagers_1.ObjectManagers.getInstance().UserManager.deleteUser(parseInt(req.params.id, 10));
            // If current session user was deleted, clear the session context
            if (req.session?.context?.user?.id === deleted.id) {
                delete req.session.context;
            }
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, null, err));
        }
    }
    static async changeRole(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.USER_MANAGEMENT_DISABLED));
        }
        if (typeof req.params === 'undefined' ||
            typeof req.params.id === 'undefined' ||
            typeof req.body === 'undefined' ||
            typeof req.body.newRole === 'undefined') {
            return next();
        }
        try {
            const updatedUser = await ObjectManagers_1.ObjectManagers.getInstance().UserManager.changeRole(parseInt(req.params.id, 10), req.body.newRole);
            // If the current session user was changed, recreate the session context
            if (req.session?.context?.user?.id === updatedUser.id) {
                const newUser = Utils_1.Utils.clone(updatedUser);
                // Do not keep password in session
                if (newUser && typeof newUser.password !== 'undefined') {
                    newUser.password = '';
                }
                // Preserve usedSharingKey if any
                if (req.session.context.user && req.session.context.user.usedSharingKey) {
                    newUser.usedSharingKey = req.session.context.user.usedSharingKey;
                }
                req.session.context = await ObjectManagers_1.ObjectManagers.getInstance().SessionManager.buildContext(newUser);
            }
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, null, err));
        }
    }
    static async updateSettings(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.USER_MANAGEMENT_DISABLED));
        }
        if (typeof req.params === 'undefined' ||
            typeof req.params.id === 'undefined' ||
            typeof req.body === 'undefined' ||
            typeof req.body.settings === 'undefined') {
            return next();
        }
        try {
            const updatedUser = await ObjectManagers_1.ObjectManagers.getInstance().UserManager.updateSettings(parseInt(req.params.id, 10), req.body.settings);
            // If the current session user was changed, recreate the session context
            if (req.session?.context?.user?.id === updatedUser.id) {
                const user = Utils_1.Utils.clone(await ObjectManagers_1.ObjectManagers.getInstance().UserManager.findOne({
                    id: updatedUser.id
                }));
                req.session.context = await ObjectManagers_1.ObjectManagers.getInstance().SessionManager.buildContext(user);
                //clean up after a change
                await ObjectManagers_1.ObjectManagers.getInstance().ProjectedCacheManager.cleanupNonExistingProjections();
            }
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Can\'t update user settings', err));
        }
    }
    static async listUsers(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.USER_MANAGEMENT_DISABLED));
        }
        try {
            let result = await ObjectManagers_1.ObjectManagers.getInstance().UserManager.find({});
            result = Utils_1.Utils.clone(result);
            for (const item of result) {
                item.password = '';
            }
            req.resultPipe = result;
            next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, null, err));
        }
    }
}
exports.UserMWs = UserMWs;

//# sourceMappingURL=UserMWs.js.map
