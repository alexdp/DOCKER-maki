"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthenticationMWs = void 0;
const Error_1 = require("../../../common/entities/Error");
const UserDTO_1 = require("../../../common/entities/UserDTO");
const ObjectManagers_1 = require("../../model/ObjectManagers");
const Config_1 = require("../../../common/config/private/Config");
const PasswordHelper_1 = require("../../model/PasswordHelper");
const Utils_1 = require("../../../common/Utils");
const QueryParams_1 = require("../../../common/QueryParams");
const path = require("path");
const Logger_1 = require("../../Logger");
const LOG_TAG = 'AuthenticationMWs';
class AuthenticationMWs {
    static async tryAuthenticate(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            const user = ObjectManagers_1.ObjectManagers.getInstance().UserManager.getUnAuthenticatedUser();
            req.session.context = await ObjectManagers_1.ObjectManagers.getInstance().SessionManager.buildContext(user);
            return next();
        }
        try {
            const user = await AuthenticationMWs.getSharingUser(req);
            if (user) {
                req.session.context = await ObjectManagers_1.ObjectManagers.getInstance().SessionManager.buildContext(user);
                return next();
            }
            // eslint-disable-next-line no-empty
        }
        catch (err) {
        }
        return next();
    }
    static async authenticate(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            const user = ObjectManagers_1.ObjectManagers.getInstance().UserManager.getUnAuthenticatedUser();
            req.session.context = await ObjectManagers_1.ObjectManagers.getInstance().SessionManager.buildContext(user);
            return next();
        }
        // if already authenticated, do not try to use sharing authentication
        if (typeof req.session.context !== 'undefined') {
            // fix context. projectionQuery gets lost in the session between calls
            if (req.session?.context && req.session.context?.user?.projectionKey && (!req.session.context?.projectionQuery || Object.keys(req.session.context?.projectionQuery || {}).length === 0)) {
                req.session.context = await ObjectManagers_1.ObjectManagers.getInstance().SessionManager.buildContext(req.session.context.user);
            }
            return next();
        }
        try {
            const user = await AuthenticationMWs.getSharingUser(req);
            if (user) {
                req.session.context = await ObjectManagers_1.ObjectManagers.getInstance().SessionManager.buildContext(user);
                return next();
            }
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.CREDENTIAL_NOT_FOUND, null, err));
        }
        if (typeof req.session.context === 'undefined') {
            res.status(401);
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.NOT_AUTHENTICATED, 'Not authenticated'));
        }
        return next();
    }
    static normalizePathParam(paramName) {
        return function normalizePathParam(req, res, next) {
            req.params[paramName] = path
                .normalize(req.params[paramName] || path.sep)
                // eslint-disable-next-line no-useless-escape
                .replace(/^(\.\.[\/\\])+/, '');
            return next();
        };
    }
    static authoriseMetaFiles(paramName) {
        return async function authoriseMetaFiles(req, res, next) {
            try {
                const p = req.params[paramName];
                if (!await ObjectManagers_1.ObjectManagers.getInstance().GalleryManager.authoriseMetaFile(req.session.context, p)) {
                    res.sendStatus(403);
                    return;
                }
                return next();
            }
            catch (e) {
                // On error, fail closed to be safe
                Logger_1.Logger.warn(LOG_TAG, 'authoriseMedia error:', e);
                res.sendStatus(403);
                return;
            }
        };
    }
    static authoriseMedia(paramName) {
        return async function authoriseMedia(req, res, next) {
            try {
                const mediaRelPath = req.params[paramName];
                if (!await ObjectManagers_1.ObjectManagers.getInstance().GalleryManager.authoriseMedia(req.session.context, mediaRelPath)) {
                    res.sendStatus(403);
                    return;
                }
                return next();
            }
            catch (e) {
                // On error, fail closed to be safe
                Logger_1.Logger.warn(LOG_TAG, 'authoriseMedia error:', e);
                res.sendStatus(403);
                return;
            }
        };
    }
    static authorise(role) {
        return function authorise(req, res, next) {
            if (req.session.context?.user.role < role) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.NOT_AUTHORISED));
            }
            return next();
        };
    }
    static async shareLogin(req, res, next) {
        if (Config_1.Config.Sharing.enabled === false) {
            return next();
        }
        // not enough parameter
        if (!req.query[QueryParams_1.QueryParams.gallery.sharingKey_query] &&
            !req.params[QueryParams_1.QueryParams.gallery.sharingKey_params]) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'no sharing key provided'));
        }
        try {
            const password = (req.body ? req.body.password : null) || null;
            const sharingKey = req.query[QueryParams_1.QueryParams.gallery.sharingKey_query] ||
                req.params[QueryParams_1.QueryParams.gallery.sharingKey_params];
            const sharing = await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.findOne(sharingKey);
            if (!sharing ||
                sharing.expires < Date.now() ||
                ((Config_1.Config.Sharing.passwordRequired === true ||
                    sharing.password) &&
                    !PasswordHelper_1.PasswordHelper.comparePassword(password, sharing.password))) {
                Logger_1.Logger.warn(LOG_TAG, 'Failed login from IP `' + req.ip + '` with sharing:' + sharing.sharingKey + ', bad password');
                res.status(401);
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.CREDENTIAL_NOT_FOUND));
            }
            const user = {
                name: 'Guest',
                role: UserDTO_1.UserRoles.LimitedGuest,
                usedSharingKey: sharing.sharingKey,
                overrideAllowBlockList: true,
                allowQuery: ObjectManagers_1.ObjectManagers.getInstance().SessionManager.buildAllowListForSharing(sharing)
            };
            req.session.context = await ObjectManagers_1.ObjectManagers.getInstance().SessionManager.buildContext(user);
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, null, err));
        }
    }
    static inverseAuthenticate(req, res, next) {
        if (typeof req.session.context?.user !== 'undefined') {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.ALREADY_AUTHENTICATED));
        }
        return next();
    }
    static async login(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            return res.sendStatus(404);
        }
        // not enough parameters
        if (typeof req.body === 'undefined' ||
            typeof req.body.loginCredential === 'undefined' ||
            typeof req.body.loginCredential.username === 'undefined' ||
            typeof req.body.loginCredential.password === 'undefined') {
            Logger_1.Logger.warn(LOG_TAG, 'Failed login from IP `' + req.ip + '` no user or password provided');
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'not all parameters are included for loginCredential'));
        }
        try {
            // let's find the user
            const user = Utils_1.Utils.clone(await ObjectManagers_1.ObjectManagers.getInstance().UserManager.findOne({
                name: req.body.loginCredential.username,
                password: req.body.loginCredential.password,
            }));
            delete user.password;
            req.session.context = await ObjectManagers_1.ObjectManagers.getInstance().SessionManager.buildContext(user);
            if (req.body.loginCredential.rememberMe) {
                req.sessionOptions.expires = new Date(Date.now() + Config_1.Config.Server.sessionTimeout);
            }
            return next();
        }
        catch (err) {
            Logger_1.Logger.warn(LOG_TAG, 'Failed login from IP `' + req.ip + '` for user:' + req.body.loginCredential.username
                + ', bad password');
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.CREDENTIAL_NOT_FOUND, 'credentials not found during login', err));
        }
    }
    static logout(req, res, next) {
        delete req.session.context;
        return next();
    }
    static async getSharingUser(req) {
        if (Config_1.Config.Sharing.enabled === true &&
            (!!req.query[QueryParams_1.QueryParams.gallery.sharingKey_query] ||
                !!req.params[QueryParams_1.QueryParams.gallery.sharingKey_params])) {
            const sharingKey = req.query[QueryParams_1.QueryParams.gallery.sharingKey_query] ||
                req.params[QueryParams_1.QueryParams.gallery.sharingKey_params];
            const sharing = await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.findOne(sharingKey);
            if (!sharing || sharing.expires < Date.now()) {
                return null;
            }
            // no 'free login' if passwords are required, or it is set
            if (Config_1.Config.Sharing.passwordRequired === true ||
                sharing.password) {
                return null;
            }
            return {
                name: 'Guest',
                role: UserDTO_1.UserRoles.LimitedGuest,
                usedSharingKey: sharing.sharingKey,
                overrideAllowBlockList: true,
                allowQuery: ObjectManagers_1.ObjectManagers.getInstance().SessionManager.buildAllowListForSharing(sharing)
            };
        }
        return null;
    }
}
exports.AuthenticationMWs = AuthenticationMWs;

//# sourceMappingURL=AuthenticationMWs.js.map
