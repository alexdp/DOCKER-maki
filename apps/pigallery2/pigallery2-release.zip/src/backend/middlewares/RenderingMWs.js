"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RenderingMWs = void 0;
const Error_1 = require("../../common/entities/Error");
const Message_1 = require("../../common/entities/Message");
const UserDTO_1 = require("../../common/entities/UserDTO");
const NotifocationManager_1 = require("../model/NotifocationManager");
const Logger_1 = require("../Logger");
const Utils_1 = require("../../common/Utils");
const LoggerRouter_1 = require("../routes/LoggerRouter");
const ExtensionConfigWrapper_1 = require("../model/extension/ExtensionConfigWrapper");
const forcedDebug = process.env['NODE_ENV'] === 'debug';
class RenderingMWs {
    static renderResult(req, res, next) {
        if (typeof req.resultPipe === 'undefined') {
            return next();
        }
        return RenderingMWs.renderMessage(res, req.resultPipe);
    }
    static renderSessionUser(req, res, next) {
        if (!req.session.context?.user) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'User not exists'));
        }
        const user = {
            id: req.session.context.user.id,
            name: req.session.context.user.name,
            role: req.session.context.user.role,
            usedSharingKey: req.session.context.user.usedSharingKey,
            projectionKey: req.session.context.user.projectionKey,
        };
        RenderingMWs.renderMessage(res, user);
    }
    static renderSharing(req, res, next) {
        if (!req.resultPipe) {
            return next();
        }
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { password, creator, ...sharing } = req.resultPipe;
        RenderingMWs.renderMessage(res, sharing);
    }
    static renderSharingList(req, res, next) {
        if (!req.resultPipe) {
            return next();
        }
        const shares = Utils_1.Utils.clone(req.resultPipe);
        shares.forEach((s) => {
            delete s.password;
            delete s.creator.password;
        });
        return RenderingMWs.renderMessage(res, shares);
    }
    static renderFile(req, res, next) {
        if (!req.resultPipe) {
            return next();
        }
        return res.sendFile(req.resultPipe, {
            maxAge: 31536000,
            dotfiles: 'allow',
        });
    }
    static renderOK(req, res) {
        const message = new Message_1.Message(null, 'ok');
        res.json(message);
    }
    static async renderConfig(req, res) {
        const originalConf = await ExtensionConfigWrapper_1.ExtensionConfigWrapper.original();
        // These are sensitive information, do not send to the client side
        originalConf.Server.sessionSecret = null;
        const originalConfJSON = JSON.parse(JSON.stringify(originalConf.toJSON({
            attachState: true,
            attachVolatile: true,
            skipTags: { secret: true }
        })));
        const message = new Message_1.Message(null, originalConfJSON);
        res.json(message);
    }
    static renderError(err, req, res, next) {
        if (err instanceof Error_1.ErrorDTO) {
            if (err.details) {
                const logFn = Logger_1.Logger.logLevelForError(err.code);
                LoggerRouter_1.LoggerRouter.log(logFn, req, res);
                // use separate rendering for detailsStr
                const d = err.detailsStr;
                delete err.detailsStr;
                logFn(err);
                err.detailsStr = d;
                delete err.details; // do not send back error object to the client side
                // hide error details for non developers
                if (!(forcedDebug ||
                    (req.session &&
                        req.session.context?.user &&
                        req.session.context?.user.role >= UserDTO_1.UserRoles.Developer))) {
                    delete err.detailsStr;
                }
            }
            const message = new Message_1.Message(err, null);
            res.json(message);
            return;
        }
        NotifocationManager_1.NotificationManager.error('Unknown server error', err, req);
        return next(err);
    }
    static renderMessage(res, content) {
        const message = new Message_1.Message(null, content);
        res.json(message);
    }
}
exports.RenderingMWs = RenderingMWs;

//# sourceMappingURL=RenderingMWs.js.map
