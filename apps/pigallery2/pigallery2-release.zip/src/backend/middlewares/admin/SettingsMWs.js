"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingsMWs = void 0;
const Error_1 = require("../../../common/entities/Error");
const Config_1 = require("../../../common/config/private/Config");
const ConfigDiagnostics_1 = require("../../model/diagnostics/ConfigDiagnostics");
const node_1 = require("typeconfig/node");
const ObjectManagers_1 = require("../../model/ObjectManagers");
const ExtensionConfigWrapper_1 = require("../../model/extension/ExtensionConfigWrapper");
const LOG_TAG = '[SettingsMWs]';
class SettingsMWs {
    /**
     * General settings updating servcie
     * @param req
     * @param res
     * @param next
     */
    static async updateSettings(req, res, next) {
        if ((typeof req.body === 'undefined')
            || (typeof req.body.settings === 'undefined')
            || (typeof req.body.settingsPath !== 'string')) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'settings is needed'));
        }
        try {
            let settings = req.body.settings; // Top level settings JSON
            const settingsPath = req.body.settingsPath; // Name of the top level settings
            const transformer = await ExtensionConfigWrapper_1.ExtensionConfigWrapper.original();
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            transformer[settingsPath] = settings;
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            settings = node_1.ConfigClassBuilder.attachPrivateInterface(transformer[settingsPath]).toJSON({
                skipTags: { secret: true }
            });
            const original = await ExtensionConfigWrapper_1.ExtensionConfigWrapper.original();
            // only updating explicitly set config (not saving config set by the diagnostics)
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            original[settingsPath] = settings;
            await ConfigDiagnostics_1.ConfigDiagnostics.testConfig(original);
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            Config_1.Config[settingsPath] = settings;
            await original.save();
            await ConfigDiagnostics_1.ConfigDiagnostics.runDiagnostics();
            // restart all schedule timers. In case they have changed
            ObjectManagers_1.ObjectManagers.getInstance().JobManager.runSchedules();
            //  Logger.info(LOG_TAG, 'new config:');
            //  Logger.info(LOG_TAG, JSON.stringify(Config.toJSON({attachDescription: false}), null, '\t'));
            return next();
        }
        catch (err) {
            if (err instanceof Error) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.SETTINGS_ERROR, 'Settings error: ' + err.toString(), err));
            }
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.SETTINGS_ERROR, 'Settings error: ' + JSON.stringify(err, null, '  '), err));
        }
    }
}
exports.SettingsMWs = SettingsMWs;

//# sourceMappingURL=SettingsMWs.js.map
