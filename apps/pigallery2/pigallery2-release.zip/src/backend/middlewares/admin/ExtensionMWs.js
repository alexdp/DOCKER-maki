"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExtensionMWs = void 0;
const Error_1 = require("../../../common/entities/Error");
const ObjectManagers_1 = require("../../model/ObjectManagers");
class ExtensionMWs {
    static async getExtensionList(req, res, next) {
        try {
            // Use the new wrapper function to get extensions with installed status
            req.resultPipe = await ObjectManagers_1.ObjectManagers.getInstance().ExtensionManager.getExtensionListWithInstallStatus();
            return next();
        }
        catch (err) {
            if (err instanceof Error) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Job error: ' + err.toString(), err));
            }
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Job error: ' + JSON.stringify(err, null, '  '), err));
        }
    }
    static async installExtension(req, res, next) {
        try {
            // Extract the extension ID from the request body
            const extensionId = req.body.id;
            if (!extensionId) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'Extension ID is required'));
            }
            // Call the installExtension method on the ExtensionManager
            await ObjectManagers_1.ObjectManagers.getInstance().ExtensionManager.installExtension(extensionId);
            // Set the result to an empty object (success)
            req.resultPipe = { success: true };
            return next();
        }
        catch (err) {
            if (err instanceof Error) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Extension installation error: ' + err.toString(), err));
            }
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Extension installation error: ' + JSON.stringify(err, null, '  '), err));
        }
    }
    static async reloadExtension(req, res, next) {
        try {
            // Extract the config key (folder name) from the request body
            // Note: The request parameter is called 'path' for backwards compatibility,
            // but it represents the config key used in Config.Extensions.extensions
            const configKey = req.body.path;
            if (!configKey) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'Extension config key is required'));
            }
            // Call cleanUp and init on the ExtensionManager
            await ObjectManagers_1.ObjectManagers.getInstance().ExtensionManager.reloadExtension(configKey);
            // Set the result to an empty object (success)
            req.resultPipe = { success: true };
            return next();
        }
        catch (err) {
            if (err instanceof Error) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Extension reload error: ' + err.toString(), err));
            }
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Extension reload error: ' + JSON.stringify(err, null, '  '), err));
        }
    }
    static async deleteExtension(req, res, next) {
        try {
            // Extract the config key (folder name) from the request body
            // Note: The request parameter is called 'path' for backwards compatibility,
            // but it represents the config key used in Config.Extensions.extensions
            const configKey = req.body.path;
            if (!configKey) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'Extension config key is required'));
            }
            // Call deleteExtension on the ExtensionManager to cleanup and remove folder
            await ObjectManagers_1.ObjectManagers.getInstance().ExtensionManager.deleteExtension(configKey);
            // Set the result to an empty object (success)
            req.resultPipe = { success: true };
            return next();
        }
        catch (err) {
            if (err instanceof Error) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Extension deletion error: ' + err.toString(), err));
            }
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Extension deletion error: ' + JSON.stringify(err, null, '  '), err));
        }
    }
}
exports.ExtensionMWs = ExtensionMWs;

//# sourceMappingURL=ExtensionMWs.js.map
