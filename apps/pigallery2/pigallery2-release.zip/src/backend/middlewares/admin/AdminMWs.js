"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminMWs = void 0;
const Error_1 = require("../../../common/entities/Error");
const ObjectManagers_1 = require("../../model/ObjectManagers");
const MessengerRepository_1 = require("../../model/messenger/MessengerRepository");
class AdminMWs {
    static async loadStatistic(req, res, next) {
        const galleryManager = ObjectManagers_1.ObjectManagers.getInstance()
            .GalleryManager;
        const personManager = ObjectManagers_1.ObjectManagers.getInstance()
            .PersonManager;
        try {
            req.resultPipe = {
                directories: await galleryManager.countDirectories(),
                photos: await galleryManager.countPhotos(),
                videos: await galleryManager.countVideos(),
                diskUsage: await galleryManager.countMediaSize(),
                persons: await personManager.countFaces(),
            };
            return next();
        }
        catch (err) {
            if (err instanceof Error) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error while getting statistic: ' + err.toString(), err));
            }
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error while getting statistic', err));
        }
    }
    static async getDuplicates(req, res, next) {
        try {
            req.resultPipe = await ObjectManagers_1.ObjectManagers.getInstance()
                .GalleryManager.getPossibleDuplicates();
            return next();
        }
        catch (err) {
            if (err instanceof Error) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error while getting duplicates: ' + err.toString(), err));
            }
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error while getting duplicates', err));
        }
    }
    static async startJob(req, res, next) {
        try {
            const id = req.params['id'];
            const jobStart = req.body;
            const JobConfig = jobStart.config;
            const soloRun = jobStart.soloRun;
            const allowParallelRun = jobStart.allowParallelRun;
            await ObjectManagers_1.ObjectManagers.getInstance().JobManager.run(id, JobConfig, soloRun, allowParallelRun);
            req.resultPipe = 'ok';
            return next();
        }
        catch (err) {
            if (err instanceof Error) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Job error: ' + err.toString(), err));
            }
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Job error: ' + JSON.stringify(err, null, '  '), err));
        }
    }
    static stopJob(req, res, next) {
        try {
            const id = req.params['id'];
            ObjectManagers_1.ObjectManagers.getInstance().JobManager.stop(id);
            req.resultPipe = 'ok';
            return next();
        }
        catch (err) {
            if (err instanceof Error) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Job error: ' + err.toString(), err));
            }
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Job error: ' + JSON.stringify(err, null, '  '), err));
        }
    }
    static getAvailableMessengers(req, res, next) {
        try {
            req.resultPipe = MessengerRepository_1.MessengerRepository.Instance.getAll().map(msgr => msgr.Name);
            return next();
        }
        catch (err) {
            if (err instanceof Error) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Messenger error: ' + err.toString(), err));
            }
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Messenger error: ' + JSON.stringify(err, null, '  '), err));
        }
    }
    static getAvailableJobs(req, res, next) {
        try {
            req.resultPipe =
                ObjectManagers_1.ObjectManagers.getInstance().JobManager.getAvailableJobs();
            return next();
        }
        catch (err) {
            if (err instanceof Error) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Job error: ' + err.toString(), err));
            }
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Job error: ' + JSON.stringify(err, null, '  '), err));
        }
    }
    static getJobProgresses(req, res, next) {
        try {
            req.resultPipe = ObjectManagers_1.ObjectManagers.getInstance().JobManager.getProgresses();
            return next();
        }
        catch (err) {
            if (err instanceof Error) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Job error: ' + err.toString(), err));
            }
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.JOB_ERROR, 'Job error: ' + JSON.stringify(err, null, '  '), err));
        }
    }
}
exports.AdminMWs = AdminMWs;

//# sourceMappingURL=AdminMWs.js.map
