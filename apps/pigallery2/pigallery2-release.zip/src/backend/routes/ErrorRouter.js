"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorRouter = void 0;
const RenderingMWs_1 = require("../middlewares/RenderingMWs");
const Error_1 = require("../../common/entities/Error");
const Logger_1 = require("../Logger");
const Config_1 = require("../../common/config/private/Config");
class ErrorRouter {
    static route(app) {
        this.addApiErrorHandler(app);
        this.addGenericHandler(app);
    }
    static addApiErrorHandler(app) {
        app.use(Config_1.Config.Server.apiPath + '/*', RenderingMWs_1.RenderingMWs.renderError);
    }
    static addGenericHandler(app) {
        app.use((err, req, res, next) => {
            if (err.name === 'UnauthorizedError') {
                // jwt authentication error
                res.status(401);
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.NOT_AUTHENTICATED, 'Invalid token'));
            }
            console.log(err);
            // Flush out the stack to the console
            Logger_1.Logger.error('Unexpected error:');
            console.error(err);
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.SERVER_ERROR, 'Unknown server side error', err, req));
        }, RenderingMWs_1.RenderingMWs.renderError);
    }
}
exports.ErrorRouter = ErrorRouter;

//# sourceMappingURL=ErrorRouter.js.map
