"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PersonRouter = void 0;
const AuthenticationMWs_1 = require("../middlewares/user/AuthenticationMWs");
const RenderingMWs_1 = require("../middlewares/RenderingMWs");
const PersonMWs_1 = require("../middlewares/PersonMWs");
const ThumbnailGeneratorMWs_1 = require("../middlewares/thumbnail/ThumbnailGeneratorMWs");
const VersionMWs_1 = require("../middlewares/VersionMWs");
const Config_1 = require("../../common/config/private/Config");
const ServerTimingMWs_1 = require("../middlewares/ServerTimingMWs");
class PersonRouter {
    static route(app) {
        this.updatePerson(app);
        this.addGetPersons(app);
        this.getPersonThumbnail(app);
    }
    static updatePerson(app) {
        app.post([Config_1.Config.Server.apiPath + '/person/:name'], 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(Config_1.Config.Faces.writeAccessMinRole), VersionMWs_1.VersionMWs.injectGalleryVersion, 
        // specific part
        PersonMWs_1.PersonMWs.updatePerson, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderResult);
    }
    static addGetPersons(app) {
        app.get([Config_1.Config.Server.apiPath + '/person'], 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(Config_1.Config.Faces.readAccessMinRole), VersionMWs_1.VersionMWs.injectGalleryVersion, 
        // specific part
        PersonMWs_1.PersonMWs.listPersons, 
        // PersonMWs.addSamplePhotoForAll,
        ThumbnailGeneratorMWs_1.ThumbnailGeneratorMWs.addThumbnailInfoForPersons, PersonMWs_1.PersonMWs.cleanUpPersonResults, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderResult);
    }
    static getPersonThumbnail(app) {
        app.get([Config_1.Config.Server.apiPath + '/person/:name/thumbnail'], 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(Config_1.Config.Faces.readAccessMinRole), VersionMWs_1.VersionMWs.injectGalleryVersion, 
        // specific part
        PersonMWs_1.PersonMWs.getPerson, ThumbnailGeneratorMWs_1.ThumbnailGeneratorMWs.generatePersonThumbnail, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderFile);
    }
}
exports.PersonRouter = PersonRouter;

//# sourceMappingURL=PersonRouter.js.map
