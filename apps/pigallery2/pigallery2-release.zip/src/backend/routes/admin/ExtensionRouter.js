"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExtensionRouter = void 0;
const ServerTimingMWs_1 = require("../../middlewares/ServerTimingMWs");
const AuthenticationMWs_1 = require("../../middlewares/user/AuthenticationMWs");
const ExtensionManager_1 = require("../../model/extension/ExtensionManager");
const RenderingMWs_1 = require("../../middlewares/RenderingMWs");
const UserDTO_1 = require("../../../common/entities/UserDTO");
const ExtensionMWs_1 = require("../../middlewares/admin/ExtensionMWs");
class ExtensionRouter {
    static route(app) {
        this.addExtensionList(app);
        this.addExtensionInstall(app);
        this.addExtensionReload(app);
        this.addExtensionDelete(app);
    }
    static addExtensionList(app) {
        app.get([ExtensionManager_1.ExtensionManager.EXTENSION_API_PATH + '/list'], AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Admin), ServerTimingMWs_1.ServerTimingMWs.addServerTiming, ExtensionMWs_1.ExtensionMWs.getExtensionList, RenderingMWs_1.RenderingMWs.renderResult);
    }
    static addExtensionInstall(app) {
        app.post([ExtensionManager_1.ExtensionManager.EXTENSION_API_PATH + '/install'], AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Admin), ServerTimingMWs_1.ServerTimingMWs.addServerTiming, ExtensionMWs_1.ExtensionMWs.installExtension, RenderingMWs_1.RenderingMWs.renderResult);
    }
    static addExtensionReload(app) {
        app.post([ExtensionManager_1.ExtensionManager.EXTENSION_API_PATH + '/reload'], AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Admin), ServerTimingMWs_1.ServerTimingMWs.addServerTiming, ExtensionMWs_1.ExtensionMWs.reloadExtension, RenderingMWs_1.RenderingMWs.renderResult);
    }
    static addExtensionDelete(app) {
        app.post([ExtensionManager_1.ExtensionManager.EXTENSION_API_PATH + '/delete'], AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Admin), ServerTimingMWs_1.ServerTimingMWs.addServerTiming, ExtensionMWs_1.ExtensionMWs.deleteExtension, RenderingMWs_1.RenderingMWs.renderResult);
    }
}
exports.ExtensionRouter = ExtensionRouter;

//# sourceMappingURL=ExtensionRouter.js.map
