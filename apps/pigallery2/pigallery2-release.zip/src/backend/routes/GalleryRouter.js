"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GalleryRouter = void 0;
const AuthenticationMWs_1 = require("../middlewares/user/AuthenticationMWs");
const GalleryMWs_1 = require("../middlewares/GalleryMWs");
const RenderingMWs_1 = require("../middlewares/RenderingMWs");
const ThumbnailGeneratorMWs_1 = require("../middlewares/thumbnail/ThumbnailGeneratorMWs");
const UserDTO_1 = require("../../common/entities/UserDTO");
const PhotoWorker_1 = require("../model/fileaccess/PhotoWorker");
const VersionMWs_1 = require("../middlewares/VersionMWs");
const SupportedFormats_1 = require("../../common/SupportedFormats");
const ServerTimingMWs_1 = require("../middlewares/ServerTimingMWs");
const MetaFileMWs_1 = require("../middlewares/MetaFileMWs");
const Config_1 = require("../../common/config/private/Config");
class GalleryRouter {
    static route(app) {
        this.addGetImageIcon(app);
        this.addGetVideoIcon(app);
        this.addGetResizedPhoto(app);
        this.addGetBestFitVideo(app);
        this.addGetVideoThumbnail(app);
        this.addGetImage(app);
        this.addGetVideo(app);
        this.addGetMetaFile(app);
        this.addGetBestFitMetaFile(app);
        this.addRandom(app);
        this.addDirectoryList(app);
        this.addDirectoryZip(app);
        this.addSearch(app);
        this.addAutoComplete(app);
    }
    static addDirectoryList(app) {
        app.get([Config_1.Config.Server.apiPath + '/gallery/content/:directory(*)', Config_1.Config.Server.apiPath + '/gallery/', Config_1.Config.Server.apiPath + '/gallery//'], 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Guest), //sharing user can only go through search. They can't just wander through the whole gallery
        AuthenticationMWs_1.AuthenticationMWs.normalizePathParam('directory'), VersionMWs_1.VersionMWs.injectGalleryVersion, 
        // specific part
        GalleryMWs_1.GalleryMWs.listDirectory, ThumbnailGeneratorMWs_1.ThumbnailGeneratorMWs.addThumbnailInformation, GalleryMWs_1.GalleryMWs.cleanUpGalleryResults, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderResult);
    }
    static addDirectoryZip(app) {
        app.get([Config_1.Config.Server.apiPath + '/gallery/zip/:searchQueryDTO(*)'], 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.LimitedGuest), 
        // specific part
        GalleryMWs_1.GalleryMWs.parseSearchQuery, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, GalleryMWs_1.GalleryMWs.zipDirectory);
    }
    static addGetImage(app) {
        app.get([
            Config_1.Config.Server.apiPath + '/gallery/content/:mediaPath(*\\.(' +
                SupportedFormats_1.SupportedFormats.Photos.join('|') +
                '))',
        ], 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.normalizePathParam('mediaPath'), AuthenticationMWs_1.AuthenticationMWs.authoriseMedia('mediaPath'), 
        // specific part
        GalleryMWs_1.GalleryMWs.loadFile, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderFile);
    }
    static addGetVideo(app) {
        app.get([
            Config_1.Config.Server.apiPath + '/gallery/content/:mediaPath(*\\.(' +
                SupportedFormats_1.SupportedFormats.Videos.join('|') +
                '))',
        ], 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.normalizePathParam('mediaPath'), AuthenticationMWs_1.AuthenticationMWs.authoriseMedia('mediaPath'), 
        // specific part
        GalleryMWs_1.GalleryMWs.loadFile, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderFile);
    }
    static addGetBestFitVideo(app) {
        app.get([
            Config_1.Config.Server.apiPath + '/gallery/content/:mediaPath(*\\.(' +
                SupportedFormats_1.SupportedFormats.Videos.join('|') +
                '))/bestFit',
        ], 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.normalizePathParam('mediaPath'), AuthenticationMWs_1.AuthenticationMWs.authoriseMedia('mediaPath'), 
        // specific part
        GalleryMWs_1.GalleryMWs.loadFile, GalleryMWs_1.GalleryMWs.loadBestFitVideo, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderFile);
    }
    static addGetMetaFile(app) {
        app.get([
            Config_1.Config.Server.apiPath + '/gallery/content/:mediaPath(*\\.(' +
                SupportedFormats_1.SupportedFormats.MetaFiles.join('|') +
                '))',
        ], 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.normalizePathParam('mediaPath'), AuthenticationMWs_1.AuthenticationMWs.authoriseMetaFiles('mediaPath'), 
        // specific part
        GalleryMWs_1.GalleryMWs.loadFile, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderFile);
    }
    static addGetBestFitMetaFile(app) {
        app.get([
            Config_1.Config.Server.apiPath + '/gallery/content/:mediaPath(*\\.(' +
                SupportedFormats_1.SupportedFormats.MetaFiles.join('|') +
                '))/bestFit',
        ], 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.normalizePathParam('mediaPath'), AuthenticationMWs_1.AuthenticationMWs.authoriseMetaFiles('mediaPath'), 
        // specific part
        GalleryMWs_1.GalleryMWs.loadFile, MetaFileMWs_1.MetaFileMWs.compressGPX, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderFile);
    }
    static addRandom(app) {
        app.get([Config_1.Config.Server.apiPath + '/gallery/random/:searchQueryDTO'], 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.LimitedGuest), VersionMWs_1.VersionMWs.injectGalleryVersion, 
        // specific part
        GalleryMWs_1.GalleryMWs.parseSearchQuery, GalleryMWs_1.GalleryMWs.getRandomImage, GalleryMWs_1.GalleryMWs.loadFile, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderFile);
    }
    /**
     * Used for serving photo thumbnails and previews
     * @param app
     * @protected
     */
    static addGetResizedPhoto(app) {
        app.get(Config_1.Config.Server.apiPath + '/gallery/content/:mediaPath(*\\.(' +
            SupportedFormats_1.SupportedFormats.Photos.join('|') +
            '))/:size', 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.normalizePathParam('mediaPath'), AuthenticationMWs_1.AuthenticationMWs.authoriseMedia('mediaPath'), 
        // specific part
        GalleryMWs_1.GalleryMWs.loadFile, ThumbnailGeneratorMWs_1.ThumbnailGeneratorMWs.generateThumbnailFactory(PhotoWorker_1.ThumbnailSourceType.Photo), ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderFile);
    }
    static addGetVideoThumbnail(app) {
        app.get(Config_1.Config.Server.apiPath + '/gallery/content/:mediaPath(*\\.(' +
            SupportedFormats_1.SupportedFormats.Videos.join('|') +
            '))/:size', 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.normalizePathParam('mediaPath'), AuthenticationMWs_1.AuthenticationMWs.authoriseMedia('mediaPath'), 
        // specific part
        GalleryMWs_1.GalleryMWs.loadFile, ThumbnailGeneratorMWs_1.ThumbnailGeneratorMWs.generateThumbnailFactory(PhotoWorker_1.ThumbnailSourceType.Video), ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderFile);
    }
    static addGetVideoIcon(app) {
        app.get(Config_1.Config.Server.apiPath + '/gallery/content/:mediaPath(*\\.(' +
            SupportedFormats_1.SupportedFormats.Videos.join('|') +
            '))/icon', 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.normalizePathParam('mediaPath'), AuthenticationMWs_1.AuthenticationMWs.authoriseMedia('mediaPath'), 
        // specific part
        GalleryMWs_1.GalleryMWs.loadFile, ThumbnailGeneratorMWs_1.ThumbnailGeneratorMWs.generateIconFactory(PhotoWorker_1.ThumbnailSourceType.Video), ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderFile);
    }
    static addGetImageIcon(app) {
        app.get(Config_1.Config.Server.apiPath + '/gallery/content/:mediaPath(*\\.(' +
            SupportedFormats_1.SupportedFormats.Photos.join('|') +
            '))/icon', 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.normalizePathParam('mediaPath'), AuthenticationMWs_1.AuthenticationMWs.authoriseMedia('mediaPath'), 
        // specific part
        GalleryMWs_1.GalleryMWs.loadFile, ThumbnailGeneratorMWs_1.ThumbnailGeneratorMWs.generateIconFactory(PhotoWorker_1.ThumbnailSourceType.Photo), ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderFile);
    }
    static addSearch(app) {
        app.get(Config_1.Config.Server.apiPath + '/search/:searchQueryDTO(*)', 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.LimitedGuest), VersionMWs_1.VersionMWs.injectGalleryVersion, 
        // specific part
        GalleryMWs_1.GalleryMWs.parseSearchQuery, GalleryMWs_1.GalleryMWs.search, ThumbnailGeneratorMWs_1.ThumbnailGeneratorMWs.addThumbnailInformation, GalleryMWs_1.GalleryMWs.cleanUpGalleryResults, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderResult);
    }
    static addAutoComplete(app) {
        app.get(Config_1.Config.Server.apiPath + '/autocomplete/:text(*)', 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.LimitedGuest), VersionMWs_1.VersionMWs.injectGalleryVersion, 
        // specific part
        GalleryMWs_1.GalleryMWs.autocomplete, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderResult);
    }
}
exports.GalleryRouter = GalleryRouter;

//# sourceMappingURL=GalleryRouter.js.map
