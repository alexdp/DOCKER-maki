"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const server_1 = require("./server");
const ConfigDiagnostics_1 = require("./model/diagnostics/ConfigDiagnostics");
if ((process.argv || []).includes('--run-diagnostics')) {
    console.log('Running diagnostics and exiting.');
    ConfigDiagnostics_1.ConfigDiagnostics.runDiagnostics().catch((e) => {
        console.error(e);
        process.exit(1);
    }).then(() => {
        process.exit(0);
    });
}
else {
    server_1.Server.getInstance();
}

//# sourceMappingURL=index.js.map
